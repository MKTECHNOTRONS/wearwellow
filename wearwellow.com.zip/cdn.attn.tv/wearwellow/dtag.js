! function() {
    'use strict';

    function t() {
        const t = `${e}?t=e&message=${encodeURI('failed to load')}&v=${n}`,
            a = new Image(1, 1);
        return a.src = t, a
    }
    const e = 'https://events.attentivemobile.com/e',
        n = '4-latest_ead96c8085',
        a = 'eyJjb21wYW55Ijoid2VhcndlbGxvdyIsImNlaWQiOiJOTWsiLCJ0YyI6ZmFsc2UsInVhIjpmYWxzZSwiYXAiOnsidHJnIjpbeyJwdCI6InNwcCIsImlkIjoidDAiLCJwdCI6InNwcCIsInBsIjp7ImVuciI6WyJzaGFyZWQiLCJzaHAiLCJsdGMiLCJqbGQiLCJtZXQiXSwidHJuIjpbImRzIl19LCJtdCI6WyJBZGQgdG8gY2FydCIsIkFkZCB0byBCYWciLCJCdXkgTm93IiwiQWRkIiwiI2FkZFRvQ2FydCIsIiNhZGQtdG8tY2FydCIsIiNBZGRUb0NhcnQiLCJPcmRlciBOb3ciLCJCdXkgaXQgbm93IiwiLnByb2R1Y3RfX2FkZC10by1jYXJ0IiwiW25hbWU9XCJhZGRcIl0iLCJbZGF0YS1sYWJlbD1cIkFkZCB0byBDYXJ0XCJdIiwiW2RhdGEtYWRkLXRvLWNhcnRdIiwiI2FkZFRvQ2FydEJ0biIsIlt2YWx1ZT1cIkFkZCB0byBCYWdcIl0iLCJbdmFsdWU9XCJBZGQgdG8gQ2FydFwiXSIsIlt2YWx1ZT1cIkFkZCB0byBPcmRlclwiXSJdLCJlYXRjIjpmYWxzZSwiZXNpdCI6dHJ1ZX0seyJwdCI6InQwIiwiaWQiOiJ0MSIsImNuZCI6W3sidHlwZSI6IndzIiwidHlwZSI6IndzIiwid3MiOiJjYXJ0X2pzb24ifV0sInB0IjoidDAiLCJtdSI6Ii9wdXJjaGFzZS90aGFua3MiLCJtdCI6W10sInRtcyI6MCwidCI6InAiLCJwbCI6eyJlbnIiOlsic2hhcmVkIiwicmVjIiwibHRjIl0sInRybiI6WyJyZSIsImRzIl19fSx7InB0IjoidDAiLCJpZCI6InQyIiwiY25kIjpbeyJ0eXBlIjoid3MiLCJ0eXBlIjoid3MiLCJ3cyI6ImNoRGF0YS5vcmRlciJ9XSwicHQiOiJ0MCIsIm11IjoiL3NlY3VyZS90aGFuay15b3UiLCJtdCI6W10sInRtcyI6MCwidCI6InAiLCJwbCI6eyJlbnIiOlsic2hhcmVkIiwiY2FyIiwibHRjIl0sInRybiI6WyJjaCIsImRzIl19fV0sImVuciI6eyJjYXIiOnsicHQiOiJ3c3AiLCJwdCI6IndzcCIsIm1wIjp7ImVtYWlsIjoiY2hEYXRhLm9yZGVyLmN1c3RvbWVyLmVtYWlsIiwiaXRlbXMiOiJjaERhdGEub3JkZXIubGluZV9pdGVtcyIsInBob25lIjoiY2hEYXRhLm9yZGVyLmJpbGxpbmdfYWRkcmVzcy5waG9uZSIsIm9yZGVySWQiOiJjaERhdGEub3JkZXIub3JkZXJfbnVtYmVyIiwiY2FydFRvdGFsIjoiY2hEYXRhLm9yZGVyLnN1YnRvdGFsX3ByaWNlIn19LCJqbGQiOnsicHQiOiJqbGQiLCJwdCI6ImpsZCIsIm1wIjp7InNrdSI6InNrdSIsIm5hbWUiOiJuYW1lIiwiaW1hZ2UiOiJpbWFnZSJ9fSwibHRjIjp7InB0IjoibHRjIiwicHQiOiJsdGMifSwibWV0Ijp7InB0IjoibWV0IiwicHQiOiJtZXQiLCJtcCI6eyJuYW1lIjoib2c6dGl0bGUiLCJpbWFnZSI6Im9nOmltYWdlIiwicHJpY2UiOiJvZzpwcmljZTphbW91bnQiLCJjdXJyZW5jeSI6Im9nOnByaWNlOmN1cnJlbmN5In19LCJyZWMiOnsicHQiOiJ3c3AiLCJwdCI6IndzcCIsIm1wIjp7ImVtYWlsIjoiY2FydF9qc29uLmVtYWlsIiwiaXRlbXMiOiJjYXJ0X2pzb24ubGluZV9pdGVtcyIsInBob25lIjoiY2FydF9qc29uLnBob25lIiwib3JkZXJJZCI6ImNhcnRfanNvbi5jaGFyZ2VfaWQiLCJjYXJ0VG90YWwiOiJjYXJ0X2pzb24uc3VidG90YWxfcHJpY2UifX0sInNocCI6eyJwdCI6InNocCIsInB0Ijoic2hwIiwidmlkYyI6W3sibXAiOnsic3ViUHJvZHVjdElkIjp7InMiOiJbbmFtZT1pZF0iLCJwcm9wIjoidmFsdWUifX0sInB0IjoiZHNwIiwiY3NrIjoiaXRlbXMifSx7Im1wIjp7InN1YlByb2R1Y3RJZCI6W3sicHQiOiJ3c3AiLCJ3cyI6IlNob3BpZnlBbmFseXRpY3MubWV0YS5zZWxlY3RlZFZhcmlhbnRJZCJ9XX0sInB0IjoiY21wcyJ9LHsibXAiOnsic3ViUHJvZHVjdElkIjpbeyJwdCI6InFwc3AiLCJxcCI6InZhcmlhbnQifV19LCJwdCI6ImNtcHMifV19LCJpbnRsIjp7InB0IjoiY21wcyIsInB0IjoiY21wcyIsIm1wIjp7ImN1cnJlbmN5IjpbeyJwdCI6IndzcCIsInB0Ijoid3NwIiwid3MiOiJTaG9waWZ5LmNoZWNrb3V0LnByZXNlbnRtZW50X2N1cnJlbmN5In0seyJwdCI6IndzcCIsInB0Ijoid3NwIiwid3MiOiJTaG9waWZ5LkNoZWNrb3V0LmN1cnJlbmN5In1dLCJjYXJ0Q3VycmVuY3kiOlt7InB0Ijoid3NwIiwicHQiOiJ3c3AiLCJ3cyI6IlNob3BpZnkuY2hlY2tvdXQucHJlc2VudG1lbnRfY3VycmVuY3kifSx7InB0Ijoid3NwIiwicHQiOiJ3c3AiLCJ3cyI6IlNob3BpZnkuQ2hlY2tvdXQuY3VycmVuY3kifV19fX0sInRybiI6eyJjaCI6eyJwdCI6Im12IiwicHQiOiJtdiIsInB0aCI6WyJjYXIuaXRlbXMiXSwibXAiOnsiaWQiOiJza3UiLCJ0aXRsZSI6Im5hbWUiLCJ2YXJpYW50X2lkIjoic3ViUHJvZHVjdElkIn19LCJkcyI6eyJwdCI6ImRzIiwicHQiOiJkcyIsIm1wIjp7InNrdSI6WyJyZWMiLCJjYXIiLCJzaHAiLCIqIiwiamxkIl0sIm5hbWUiOlsicmVjIiwiY2FyIiwic2hwIiwiKiIsIm1ldCIsImpsZCJdLCJlbWFpbCI6WyJyZWMiLCJjYXIiLCIqIiwibHRjIl0sImltYWdlIjpbInJlYyIsImNhciIsIioiLCJzaHAiLCJtZXQiXSwicGhvbmUiOlsicmVjIiwiY2FyIiwic2hwIiwibHRjIl0sInByaWNlIjpbInJlYyIsImNhciIsInNocCIsIioiLCJtZXQiXSwib3JkZXJJZCI6WyJyZWMiLCJjYXIiLCIqIiwic2hwIl0sImNhdGVnb3J5IjpbIioiLCJzaHAiXSwiY3VycmVuY3kiOlsiaW50bCIsIioiLCJzaHAiLCJtZXQiXSwicXVhbnRpdHkiOlsicmVjIiwiY2FyIiwiKiIsInNocCJdLCJjYXJ0VG90YWwiOlsicmVjIiwiY2FyIiwiKiIsInNocCJdLCJwcm9kdWN0SWQiOlsicmVjIiwiY2FyIiwic2hwIiwiKiIsImpsZCJdLCJjYXJ0Q291cG9uIjpbIioiLCJzaHAiLCJsdGMiXSwiY2FydEN1cnJlbmN5IjpbImludGwiLCIqIiwic2hwIiwibWV0Il0sImNhcnREaXNjb3VudCI6WyIqIiwic2hwIl0sInN1YlByb2R1Y3RJZCI6WyJyZWMiLCJjYXIiLCJzaHAiLCIqIl19fSwicmUiOnsicHQiOiJtdiIsInB0IjoibXYiLCJwdGgiOlsicmVjLml0ZW1zIl0sIm1wIjp7InNrdSI6InByb2R1Y3RJZCIsInRpdGxlIjoibmFtZSIsInByb2R1Y3RfaWQiOiJza3UiLCJ2YXJpYW50X2lkIjoic3ViUHJvZHVjdElkIn19fX0sImNjIjp7Iml0Ijp0cnVlfSwiYmN0dSI6Imh0dHBzOi8vc211bWUud2VhcndlbGxvdy5jb20iLCJpZGMiOnsiZWZqIjpmYWxzZSwiZWZsIjpmYWxzZSwiZW1jIjpmYWxzZX0sImx0YyI6e319',
        o = 'wearwellow.attn.tv',
        i = 'https://cdn.attn.tv/tag';
    const d = '4-latest';
    let c = {};
    try {
        c = JSON.parse(atob(a))
    } catch {
        t()
    }

    function r(t, e, n) {
        const a = document.createElement('script');
        return a.setAttribute('async', 'true'), a.type = 'text/javascript', e && (a.onload = e), n && (a.onerror = n), a.src = t, ((document.getElementsByTagName('head') || [null])[0] || document.getElementsByTagName('script')[0].parentNode).appendChild(a), a
    }

    function _(t) {
        return `${i}/${d}/${t}?v=${n}`
    }

    function s(e = (() => {})) {
        r(_('unified-' + (window.navigator.userAgent.indexOf('MSIE ') > 0 || navigator.userAgent.match(/Trident.*rv:11\./) ? 'tag-ie.js' : 'tag.js')), e, t)
    }! function(e, n) {
        var i;

        function u(t) {
            return function() {
                e.attn_d0x0b_evt.push({
                    func: t,
                    args: arguments
                }), e.dispatchEvent(new Event('attn_queued_sdk_event'))
            }
        }

        function w() {
            ! function() {
                try {
                    const [t] = window.location.hash.split(/\?/);
                    if (t.indexOf('attn') > -1) {
                        const t = window.location.hash.slice(5);
                        sessionStorage.setItem('_d0x0b_', t)
                    }
                    const e = sessionStorage.getItem('_d0x0b_');
                    return !!e && (window.attn_d0x0b_cfg = e, !0)
                } catch (t) {
                    return !1
                }
            }() ? s(): function(e = (() => {})) {
                r(_('tag-debug.js'), e, t)
            }(), n.removeEventListener('DOMContentLoaded', w)
        }
        e.attn_d0x0b_cfg = a, e.__attentive_cfg = JSON.parse('{\"ceid\":\"NMk\",\"klv\":\"1\",\"lt\":\"1\"}'), window.__attentive_domain = o, window.__attentive || (window.__attentive = {
            invoked: !1,
            show: function() {
                window.__attentive.invoked = !0
            }
        }), (null == (i = null == c ? void 0 : c.cc) ? void 0 : i.dap) || function() {
            if (window.__poll_for_path_change) return;
            let t = window.location.pathname;
            const e = () => {
                window.__attentive && window.__attentive.show && window.__attentive.show()
            };
            window.__poll_for_path_change = !0, setInterval((function() {
                if (t !== window.location.pathname) {
                    const n = document.querySelector('#attentive_overlay');
                    null != n && n.parentNode && n.parentNode.removeChild(n), t = window.location.pathname, e()
                }
            }), 500), e()
        }(), e.__attnLoaded || (e.__attnLoaded = !0, e.attn_d0x0b_evt = e.attn_d0x0b_evt || [], e.attentive = {
            version: d,
            analytics: {
                enable: u('enable'),
                disable: u('disable'),
                track: u('track'),
                pageView: u('pageView'),
                addToCart: u('addToCart'),
                productView: u('productView'),
                purchase: u('purchase')
            }
        }, 'loading' === n.readyState ? n.addEventListener('DOMContentLoaded', w) : w())
    }(window, document)
}();