(function() {
    "use strict";
    const t = {
        CUSTOM_EMAIL_LEAD_EVENTS: ({
            email: n,
            creativeId: i
        }) => {
            window.attenCallback2 && window.attenCallback2("email_submit", {
                email: n,
                creativeId: i
            })
        }
    };
    window.__attentive_client_cfg = t
})();