! function(e, t) {
    var define;
    "object" == typeof exports && "object" == typeof module ? module.exports = t() : "function" == typeof define && define.amd ? define([], t) : "object" == typeof exports ? exports.obtp = t() : e.obtp = t()
}(this, (() => (() => {
    "use strict";
    var e, t, n = {},
        o = {};

    function r(e) {
        var t = o[e];
        if (void 0 !== t) return t.exports;
        var i = o[e] = {
            exports: {}
        };
        return n[e](i, i.exports, r), i.exports
    }
    r.m = n, r.d = (e, t) => {
        for (var n in t) r.o(t, n) && !r.o(e, n) && Object.defineProperty(e, n, {
            enumerable: !0,
            get: t[n]
        })
    }, r.f = {}, r.e = e => Promise.all(Object.keys(r.f).reduce(((t, n) => (r.f[n](e, t), t)), [])), r.u = e => e + ".js", r.g = function() {
        if ("object" == typeof globalThis) return globalThis;
        try {
            return this || new Function("return this")()
        } catch (e) {
            if ("object" == typeof window) return window
        }
    }(), r.o = (e, t) => Object.prototype.hasOwnProperty.call(e, t), e = {}, t = "conversion-pixel-tag:", r.l = (n, o, i, a) => {
        if (e[n]) e[n].push(o);
        else {
            var s, c;
            if (void 0 !== i)
                for (var u = document.getElementsByTagName("script"), p = 0; p < u.length; p++) {
                    var l = u[p];
                    if (l.getAttribute("src") == n || l.getAttribute("data-webpack") == t + i) {
                        s = l;
                        break
                    }
                }
            s || (c = !0, (s = document.createElement("script")).charset = "utf-8", s.timeout = 120, r.nc && s.setAttribute("nonce", r.nc), s.setAttribute("data-webpack", t + i), s.src = n), e[n] = [o];
            var d = (t, o) => {
                    s.onerror = s.onload = null, clearTimeout(f);
                    var r = e[n];
                    if (delete e[n], s.parentNode && s.parentNode.removeChild(s), r && r.forEach((e => e(o))), t) return t(o)
                },
                f = setTimeout(d.bind(null, void 0, {
                    type: "timeout",
                    target: s
                }), 12e4);
            s.onerror = d.bind(null, s.onerror), s.onload = d.bind(null, s.onload), c && document.head.appendChild(s)
        }
    }, r.r = e => {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(e, "__esModule", {
            value: !0
        })
    }, (() => {
        var e;
        r.g.importScripts && (e = r.g.location + "");
        var t = r.g.document;
        if (!e && t && (t.currentScript && (e = t.currentScript.src), !e)) {
            var n = t.getElementsByTagName("script");
            n.length && (e = n[n.length - 1].src)
        }
        if (!e) throw new Error("Automatic publicPath is not supported in this browser");
        e = e.replace(/#.*$/, "").replace(/\?.*$/, "").replace(/\/[^\/]+$/, "/"), r.p = e
    })(), (() => {
        var e = {
            881: 0
        };
        r.f.j = (t, n) => {
            var o = r.o(e, t) ? e[t] : void 0;
            if (0 !== o)
                if (o) n.push(o[2]);
                else {
                    var i = new Promise(((n, r) => o = e[t] = [n, r]));
                    n.push(o[2] = i);
                    var a = r.p + r.u(t),
                        s = new Error;
                    r.l(a, (n => {
                        if (r.o(e, t) && (0 !== (o = e[t]) && (e[t] = void 0), o)) {
                            var i = n && ("load" === n.type ? "missing" : n.type),
                                a = n && n.target && n.target.src;
                            s.message = "Loading chunk " + t + " failed.\n(" + i + ": " + a + ")", s.name = "ChunkLoadError", s.type = i, s.request = a, o[1](s)
                        }
                    }), "chunk-" + t, t)
                }
        };
        var t = (t, n) => {
                var o, i, [a, s, c] = n,
                    u = 0;
                if (a.some((t => 0 !== e[t]))) {
                    for (o in s) r.o(s, o) && (r.m[o] = s[o]);
                    c && c(r)
                }
                for (t && t(n); u < a.length; u++) i = a[u], r.o(e, i) && e[i] && e[i][0](), e[i] = 0
            },
            n = this.webpackChunkconversion_pixel_tag = this.webpackChunkconversion_pixel_tag || [];
        n.forEach(t.bind(null, 0)), n.push = t.bind(null, n.push.bind(n))
    })();
    var i = {};

    function a(e) {
        return Array.isArray(e)
    }

    function s(e) {
        return Object.keys(e).map((function(t) {
            return "".concat(t, "=").concat(encodeURIComponent(e[t]))
        })).join("&")
    }
    r.r(i);
    var c = function() {},
        u = function(e, t, n) {
            var o = e[t];
            e[t] = function() {
                var e = o.apply(this, arguments);
                return n.apply(this, arguments), e
            }
        },
        p = function(e, t, n) {
            (window.postMessage || c)({
                action: "log",
                type: e,
                message: t,
                name: n
            }, "*")
        };

    function l(e) {
        if (e) return "string" == typeof e ? e.replace(" ", "").split(",") : a(e) ? e : void 0
    }
    var d, f, h, v = "has_concent_event",
        y = [1, 3, 4];
    ! function(e) {
        e.Default = "all", e.EuZone1 = "euZone1", e.EuZone2 = "euZone2"
    }(d || (d = {})),
    function(e) {
        e.Product = "product"
    }(f || (f = {})),
    function(e) {
        e.Log = "log", e.Warning = "warning", e.Info = "info", e.Error = "error"
    }(h || (h = {}));
    var g = "PAGE_VIEW",
        m = "dicbo",
        w = "dicbo_id",
        b = "dicbo_fetch",
        C = "ob_cvr_pixel_domain",
        k = "obamplify",
        _ = "obtp",
        E = new(function() {
            function e() {
                this.validCurrencies = ["USD", "CAD", "EUR", "GBP", "ILS", "AUD", "MXN", "BRL", "SEK", "SGD", "RUB", "NZD", "INR", "JPY", "PHP", "CHF"], this.validNameRegX = new RegExp("^[A-Za-z0-9]+[A-Za-z0-9- ]*$"), this.validNumber = new RegExp("^[0-9]+[.0-9]*$"), this.validNameLength = 100
            }
            return e.prototype.validate = function(e) {
                return e.content && e.content.id, e.orderValue && !e.currency ? (p(h.Warning, "Order value reported but no currency is declared", e.name), !1) : e.currency && -1 === this.validCurrencies.indexOf(e.currency) ? (p(h.Warning, "Currency not recognized", e.name), !1) : e.orderValue && !this.validNumber.test(e.orderValue) ? (p(h.Warning, "Order value can only be a positive number", e.name), !1) : e.name === g || this.validNameRegX.test(e.name) ? !(e.name !== g && e.name.length > this.validNameLength && (p(h.Warning, "Event name length cannot exceed 100 characters", e.name), 1)) : (p(h.Warning, "Event Name invalid", e.name), !1)
            }, e
        }()),
        O = new(function() {
            function e() {}
            return e.prototype.getParamFromUrl = function(e) {
                var t = this.getLocation();
                t.indexOf("#") > -1 && (t = t.substring(0, t.indexOf("#")));
                for (var n = (t.split("?")[1] || "").split(/&/), o = 0; o < n.length; o++)
                    if (this.startsWith(n[o], e)) return this.getParamValue(n[o]);
                return ""
            }, e.prototype.getLocation = function() {
                var e = "";
                try {
                    e = window.top.location.href || document.location.href
                } catch (t) {
                    e = document.location.href
                }
                return e || ""
            }, e.prototype.startsWith = function(e, t) {
                return 0 === e.indexOf(t + "=")
            }, e.prototype.getParamValue = function(e) {
                return e.split("=")[1].split("#")[0]
            }, e
        }()),
        S = function(e, t, n) {
            if (n || 2 === arguments.length)
                for (var o, r = 0, i = t.length; r < i; r++) !o && r in t || (o || (o = Array.prototype.slice.call(t, 0, r)), o[r] = t[r]);
            return e.concat(o || Array.prototype.slice.call(t))
        },
        P = new(function() {
            function e() {
                this.listeners = {}
            }
            return e.prototype.on = function(e, t) {
                var n = this;
                return -1 === Object.keys(this.listeners).indexOf(e) && (this.listeners[e] = []), this.listeners[e].push(t),
                    function() {
                        n.listeners[e] = n.listeners[e].filter((function(e) {
                            return e != t
                        }))
                    }
            }, e.prototype.dispatch = function(e) {
                for (var t = [], n = 1; n < arguments.length; n++) t[n - 1] = arguments[n]; - 1 !== Object.keys(this.listeners).indexOf(e) && this.listeners[e].forEach((function(e) {
                    return e.call.apply(e, S([null], t, !1))
                }))
            }, e
        }()),
        T = function() {
            return T = Object.assign || function(e) {
                for (var t, n = 1, o = arguments.length; n < o; n++)
                    for (var r in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, r) && (e[r] = t[r]);
                return e
            }, T.apply(this, arguments)
        };

    function I(e, t) {
        (new Image).src = A() + "/log?apiObjVersion=" + t.version + "&obtpVersion=" + t.obtpVersion + "&msg=" + encodeURIComponent('{"error":"LOAD", "apiObjVersion": ' + t.version + ', "marketerID": ' + t.marketerId + ', "referrer": ' + document.URL + ', "extra": {"name":"' + e.name + '","line":"' + (e.lineNumber || e.line) + '","script":"' + (e.fileName || e.sourceURL || e.script) + '","stack":"' + (e.stackTrace || e.stack) + '","message":"' + e.message + '"}}')
    }

    function x(e) {
        return "".concat(A(), "/unifiedPixel")
    }

    function A() {
        return L() ? "//p.teads.tv/obtr" : "//tr.outbrain.com"
    }

    function L() {
        try {
            return !!ce.loadedBy && ("string" != typeof ce.loadedBy ? (I({
                message: "loadedBy - ".concat(ce.loadedBy, " - is not a string")
            }, ce), !1) : "teads" === ce.loadedBy.toLowerCase())
        } catch (e) {
            return I(e, ce), !1
        }
    }
    var N = function() {
            function e(e) {
                this.cookiesToProcess = [];
                var t = this;
                e.on(v, (function(e) {
                    if (t.hasConsent = e, t.hasConsent)
                        for (; t.cookiesToProcess.length;) {
                            var n = t.cookiesToProcess.pop();
                            t.set(n.name, n.value, n.expirationInDays, n.domain)
                        }
                }))
            }
            return e.prototype.set = function(e, t, n, o) {
                if (void 0 === n && (n = 7), this.hasConsent) {
                    var r = this.getAllCookies();
                    r[e] = t;
                    var i = new Date;
                    i.setTime(i.getTime() + 24 * n * 60 * 60 * 1e3);
                    var a = "expires=" + i.toUTCString(),
                        s = "".concat(w, "=").concat(encodeURIComponent(JSON.stringify(r))),
                        c = s + "; " + a + "; path=/;";
                    o && (c += "domain=" + o + ";"), L() ? teads_setOutbrainCookieOnTeads(s) : document.cookie = c
                } else this.cookiesToProcess.push({
                    name: e,
                    value: t,
                    expirationInDays: n,
                    domain: o
                })
            }, e.prototype.get = function(e) {
                try {
                    return this.getAllCookies()[e] || ""
                } catch (e) {
                    return console.error("failed to access cookies", e), ""
                }
            }, e.prototype.getAllCookies = function() {
                var e, t, n = L() ? teads_getOutbrainCookieFromTeads() : document.cookie;
                if (!n) return {};
                var o, r = null === (t = n.split("; ").find((function(e) {
                    return e.startsWith("dicbo_id=")
                }))) || void 0 === t ? void 0 : t.split("=")[1];
                if (!r) return {};
                try {
                    o = JSON.parse(decodeURIComponent(r))
                } catch (t) {
                    (e = {}).dicbo_id = r, o = e
                }
                return o
            }, e
        }(),
        B = new N(P),
        j = new(function() {
            function e() {
                window.addEventListener("UC_UI_CMP_EVENT", function(e) {
                    var t, n = e.detail.type;
                    ["ACCEPT_ALL", "DENY_ALL", "SAVE"].includes(n) && (null === (t = this.cb) || void 0 === t || t.call(this, this.hasConsent()))
                }.bind(this))
            }
            return e.prototype.hasConsentHandler = function() {
                return !!window.UC_UI
            }, e.prototype.handleConsent = function(e) {
                this.cb = e, this.cb(this.hasConsent())
            }, e.prototype.hasConsent = function() {
                var e, t, n = window.UC_UI;
                return n.areAllConsentsAccepted() || !!(null === (t = null === (e = n.getServicesBaseInfo().find((function(e) {
                    return "Outbrain" === e.name
                }))) || void 0 === e ? void 0 : e.consent) || void 0 === t ? void 0 : t.status)
            }, e
        }()),
        U = new(function() {
            function e() {
                this.boundOnAccept = !1
            }
            return e.prototype.hasConsentHandler = function() {
                return !!window.Cookiebot
            }, e.prototype.handleConsent = function(e) {
                var t;
                this.cb = e;
                var n = window.Cookiebot;
                this.boundOnAccept || this.bindOnAccept(), this.cb(null === (t = n.consent) || void 0 === t ? void 0 : t.marketing)
            }, e.prototype.bindOnAccept = function() {
                window.addEventListener("CookiebotOnAccept", this.cb.bind(this, !0), !1), this.boundOnAccept = !0
            }, e
        }()),
        D = new(function() {
            function e() {}
            return e.prototype.hasConsentHandler = function() {
                return !!window.didomiState
            }, e.prototype.handleConsent = function(e) {
                this.cb = e;
                var t = window.didomiState;
                this.cb(t.didomiPurposesConsent.indexOf("cookies") > -1 && t.didomiPurposesConsent.indexOf("measure_ad_performance") > -1)
            }, e
        }()),
        H = function() {
            function e() {}
            return e.prototype.hasConsentHandler = function() {
                return void 0 !== window.OnetrustActiveGroups
            }, e.prototype.handleConsent = function(e) {
                var t = this;
                this.cb = e;
                var n = function() {
                    return window.OnetrustActiveGroups.toUpperCase().indexOf("C0004") > -1
                };
                if (n()) this.cb(!0);
                else if ("OneTrust" in window) window.OneTrust.OnConsentChanged((function() {
                    t.cb(n())
                }));
                else {
                    var o = ce.zone === d.Default;
                    this.cb(o)
                }
            }, e
        }(),
        R = new H,
        V = function() {
            function e() {}
            return e.prototype.hasConsentHandler = function() {
                return !!window.google_tag_data
            }, e.prototype.handleConsent = function(e) {
                var t;
                if (ce.zone !== d.Default) {
                    var n = window.google_tag_data;
                    if (null === (t = null == n ? void 0 : n.ics) || void 0 === t ? void 0 : t.entries) {
                        var o = ["ad_storage", "ad_user_data"],
                            r = function() {
                                return o.every((function(e) {
                                    var t;
                                    return !0 === (null === (t = n.ics.entries[e]) || void 0 === t ? void 0 : t.update)
                                }))
                            };
                        e(r()), !r() && n.ics.addListener && n.ics.addListener(o, (function() {
                            e(r())
                        }))
                    } else e(!1)
                } else e(!0)
            }, e
        }(),
        F = new V,
        z = function() {
            function e() {
                this.cbs = [], this.tcfApiEventListeners = []
            }
            return e.prototype.hasConsentHandler = function() {
                return !!window.__tcfapi || !!this.getTCF2Window()
            }, e.prototype.handleConsent = function(e) {
                if (this.cbs.push(e), window.__tcfapi) {
                    var t = this.onTCFChanges.bind(this);
                    this.tcfApiEventListeners.push(t), window.__tcfapi("addEventListener", 2, t)
                } else {
                    var n = this.getTCF2Window();
                    window.addEventListener ? window.addEventListener("message", this.postMsgCB.bind(this), !1) : window.attachEvent && window.attachEvent("message", this.postMsgCB.bind(this), !1);
                    var o = {
                        __tcfapiCall: {
                            command: "addEventListener",
                            parameter: [164],
                            version: 2,
                            callId: k
                        }
                    };
                    n.postMessage(o, "*")
                }
            }, e.prototype.hasPurposeConsent = function(e) {
                if (!(null == e ? void 0 : e.consents)) return !0;
                var t = e.consents,
                    n = !0;
                return y.forEach((function(e) {
                    t.hasOwnProperty(e) && !1 === t[e] && (n = !1)
                })), n
            }, e.prototype.postMsgCB = function(e) {
                e.data.__tcfapiReturn && e.data.__tcfapiReturn.callId === k && this.onTCFCB(e.data.__tcfapiReturn.returnValue, !0)
            }, e.prototype.onTCFCB = function(e, t) {
                !1 !== e && "cmpuishown" !== e.eventStatus && (t && "tcloaded" === (null == e ? void 0 : e.eventStatus) || "useractioncomplete" === (null == e ? void 0 : e.eventStatus) ? (e && e.vendor && e.vendor.consents && !1 === e.vendor.consents[164] || !e || !this.hasPurposeConsent(e.purpose) ? this.invokeCallBacks(!1) : this.invokeCallBacks(!0), this.removeTcfApiEventListeners()) : this.invokeCallBacks(!0))
            }, e.prototype.invokeCallBacks = function(e) {
                for (; this.cbs.length;) this.cbs.shift()(e)
            }, e.prototype.removeTcfApiEventListeners = function() {
                window.__tcfapi && this.tcfApiEventListeners.forEach((function(e) {
                    window.__tcfapi("removeEventListener", 2, e)
                }))
            }, e.prototype.onTCFChanges = function(e, t) {
                this.onTCFCB(e, t)
            }, e.prototype.getTCF2Window = function() {
                var e = window;
                try {
                    for (; e && !e.frames.__tcfapiLocator;) {
                        if (e === window.top) return;
                        e = e.parent
                    }
                    return e
                } catch (e) {}
            }, e
        }(),
        W = new z,
        M = new(function() {
            function e() {}
            return e.prototype.hasConsentHandler = function() {
                return window.__uspapi && "function" == typeof window.__uspapi
            }, e.prototype.handleConsent = function(e) {
                window.__uspapi("getUSPData", 1, (function(t, n) {
                    if (t.uspString) n && "1YYN" !== t.uspString.toUpperCase() && "1NYN" !== t.uspString.toUpperCase() ? e(!0) : e(!1);
                    else {
                        var o = ce.zone === d.Default;
                        e(o)
                    }
                }))
            }, e
        }()),
        q = function() {
            function e() {
                this.delimiter = "~"
            }
            return e.prototype.hasConsentHandler = function() {
                return !!window.__gpp
            }, e.prototype.handleConsent = function(e) {
                var t = this;
                this.cb = e;
                var n = ce.zone === d.Default;
                window.__gpp("addEventListener", (function(o) {
                    if ("signalStatus" === o.eventName && "ready" === o.data) {
                        var r = o.pingData.gppString;
                        t.parseGppString(r, n, e)
                    }
                }))
            }, e.prototype.parseGppString = function(e, t, n) {
                return o = this, i = void 0, s = function() {
                    var o, i;
                    return function(e, t) {
                        var n, o, r, i, a = {
                            label: 0,
                            sent: function() {
                                if (1 & r[0]) throw r[1];
                                return r[1]
                            },
                            trys: [],
                            ops: []
                        };
                        return i = {
                            next: s(0),
                            throw: s(1),
                            return: s(2)
                        }, "function" == typeof Symbol && (i[Symbol.iterator] = function() {
                            return this
                        }), i;

                        function s(i) {
                            return function(s) {
                                return function(i) {
                                    if (n) throw new TypeError("Generator is already executing.");
                                    for (; a;) try {
                                        if (n = 1, o && (r = 2 & i[0] ? o.return : i[0] ? o.throw || ((r = o.return) && r.call(o), 0) : o.next) && !(r = r.call(o, i[1])).done) return r;
                                        switch (o = 0, r && (i = [2 & i[0], r.value]), i[0]) {
                                            case 0:
                                            case 1:
                                                r = i;
                                                break;
                                            case 4:
                                                return a.label++, {
                                                    value: i[1],
                                                    done: !1
                                                };
                                            case 5:
                                                a.label++, o = i[1], i = [0];
                                                continue;
                                            case 7:
                                                i = a.ops.pop(), a.trys.pop();
                                                continue;
                                            default:
                                                if (!((r = (r = a.trys).length > 0 && r[r.length - 1]) || 6 !== i[0] && 2 !== i[0])) {
                                                    a = 0;
                                                    continue
                                                }
                                                if (3 === i[0] && (!r || i[1] > r[0] && i[1] < r[3])) {
                                                    a.label = i[1];
                                                    break
                                                }
                                                if (6 === i[0] && a.label < r[1]) {
                                                    a.label = r[1], r = i;
                                                    break
                                                }
                                                if (r && a.label < r[2]) {
                                                    a.label = r[2], a.ops.push(i);
                                                    break
                                                }
                                                r[2] && a.ops.pop(), a.trys.pop();
                                                continue
                                        }
                                        i = t.call(e, a)
                                    } catch (e) {
                                        i = [6, e], o = 0
                                    } finally {
                                        n = r = 0
                                    }
                                    if (5 & i[0]) throw i[1];
                                    return {
                                        value: i[0] ? i[1] : void 0,
                                        done: !0
                                    }
                                }([i, s])
                            }
                        }
                    }(this, (function(a) {
                        switch (a.label) {
                            case 0:
                                if (!this.isValidString(e)) return n(t), [2];
                                if (this.iabLib) return [3, 4];
                                a.label = 1;
                            case 1:
                                return a.trys.push([1, 3, , 4]), o = this, [4, r.e(673).then(r.bind(r, 673))];
                            case 2:
                                return o.iabLib = a.sent(), [3, 4];
                            case 3:
                                return I({
                                    message: "Failed to load iab library",
                                    error: a.sent()
                                }, ce), n(t), [2];
                            case 4:
                                return i = this.parseString(e), n(null != i ? i : t), [2]
                        }
                    }))
                }, new((a = void 0) || (a = Promise))((function(e, t) {
                    function n(e) {
                        try {
                            c(s.next(e))
                        } catch (e) {
                            t(e)
                        }
                    }

                    function r(e) {
                        try {
                            c(s.throw(e))
                        } catch (e) {
                            t(e)
                        }
                    }

                    function c(t) {
                        var o;
                        t.done ? e(t.value) : (o = t.value, o instanceof a ? o : new a((function(e) {
                            e(o)
                        }))).then(n, r)
                    }
                    c((s = s.apply(o, i || [])).next())
                }));
                var o, i, a, s
            }, e.prototype.isValidString = function(e) {
                return e.startsWith("C") || e.startsWith("D")
            }, e.prototype.parseString = function(e) {
                try {
                    return this.hasConsent(e)
                } catch (n) {
                    if (e.startsWith("D")) try {
                        var t = e.substring(e.indexOf(this.delimiter) + 1);
                        return this.hasConsent(t)
                    } catch (e) {}
                    return
                }
            }, e.prototype.hasConsent = function(e) {
                var t = this.iabLib.TCString.decode(e);
                if (t.vendorConsents.has(164)) return t.purposeConsents.has(1)
            }, e
        }(),
        G = new q,
        Z = new(function() {
            function e() {}
            return e.prototype.hasConsentHandler = function() {
                var e = decodeURIComponent(document.location.href.toLowerCase());
                return e.includes("gcs=g111") || e.includes("gcs=g11-") || e.includes("gcs=g1-1")
            }, e.prototype.handleConsent = function(e) {
                e(!0)
            }, e
        }()),
        $ = new(function() {
            function e() {}
            return e.prototype.hasConsentHandler = function() {
                return !0
            }, e.prototype.handleConsent = function(e) {
                this.cb = e, this.cb(this.hasConsentSignal())
            }, e.prototype.hasConsentSignal = function() {
                var e = O.getParamFromUrl(m),
                    t = null == e ? void 0 : e.split("-");
                return !(!e || !(null == t ? void 0 : t.length)) && "1" === t[t.length - 1]
            }, e
        }()),
        Y = function() {
            function e() {}
            return e.prototype.hasConsentHandler = function() {
                var e = document.cookie,
                    t = !!e && ["_shopify_ga", "_shopify_y", "_shopify_s", "_shopify_fs", "_shopify_sa_p", "_shopify_sa_t", "_shopify_country", "_shopify_essential"].some((function(t) {
                        return e.includes(t)
                    })),
                    n = document.location.href.toLowerCase().includes("/custom/web-pixel-");
                return t || n
            }, e.prototype.handleConsent = function(e) {
                return t = this, n = void 0, r = function() {
                    var t, n, o, r, i = this;
                    return function(e, t) {
                        var n, o, r, i, a = {
                            label: 0,
                            sent: function() {
                                if (1 & r[0]) throw r[1];
                                return r[1]
                            },
                            trys: [],
                            ops: []
                        };
                        return i = {
                            next: s(0),
                            throw: s(1),
                            return: s(2)
                        }, "function" == typeof Symbol && (i[Symbol.iterator] = function() {
                            return this
                        }), i;

                        function s(i) {
                            return function(s) {
                                return function(i) {
                                    if (n) throw new TypeError("Generator is already executing.");
                                    for (; a;) try {
                                        if (n = 1, o && (r = 2 & i[0] ? o.return : i[0] ? o.throw || ((r = o.return) && r.call(o), 0) : o.next) && !(r = r.call(o, i[1])).done) return r;
                                        switch (o = 0, r && (i = [2 & i[0], r.value]), i[0]) {
                                            case 0:
                                            case 1:
                                                r = i;
                                                break;
                                            case 4:
                                                return a.label++, {
                                                    value: i[1],
                                                    done: !1
                                                };
                                            case 5:
                                                a.label++, o = i[1], i = [0];
                                                continue;
                                            case 7:
                                                i = a.ops.pop(), a.trys.pop();
                                                continue;
                                            default:
                                                if (!((r = (r = a.trys).length > 0 && r[r.length - 1]) || 6 !== i[0] && 2 !== i[0])) {
                                                    a = 0;
                                                    continue
                                                }
                                                if (3 === i[0] && (!r || i[1] > r[0] && i[1] < r[3])) {
                                                    a.label = i[1];
                                                    break
                                                }
                                                if (6 === i[0] && a.label < r[1]) {
                                                    a.label = r[1], r = i;
                                                    break
                                                }
                                                if (r && a.label < r[2]) {
                                                    a.label = r[2], a.ops.push(i);
                                                    break
                                                }
                                                r[2] && a.ops.pop(), a.trys.pop();
                                                continue
                                        }
                                        i = t.call(e, a)
                                    } catch (e) {
                                        i = [6, e], o = 0
                                    } finally {
                                        n = r = 0
                                    }
                                    if (5 & i[0]) throw i[1];
                                    return {
                                        value: i[0] ? i[1] : void 0,
                                        done: !0
                                    }
                                }([i, s])
                            }
                        }
                    }(this, (function(a) {
                        return t = ce.zone === d.Default, n = ce.queue, o = n.length && n.some((function(e) {
                            var t = e[2];
                            return !!(null == t ? void 0 : t.shopifyEvent) && !0 !== (null == t ? void 0 : t.shopifyEvent)
                        })), o ? (r = n.some((function(e) {
                            var t = e[2];
                            return !!t && i.hasConsent(t.shopifyEvent)
                        })), e(r), [2]) : (e(t), [2])
                    }))
                }, new((o = void 0) || (o = Promise))((function(e, i) {
                    function a(e) {
                        try {
                            c(r.next(e))
                        } catch (e) {
                            i(e)
                        }
                    }

                    function s(e) {
                        try {
                            c(r.throw(e))
                        } catch (e) {
                            i(e)
                        }
                    }

                    function c(t) {
                        var n;
                        t.done ? e(t.value) : (n = t.value, n instanceof o ? n : new o((function(e) {
                            e(n)
                        }))).then(a, s)
                    }
                    c((r = r.apply(t, n || [])).next())
                }));
                var t, n, o, r
            }, e.prototype.hasConsent = function(e) {
                var t = e.analyticsProcessingAllowed,
                    n = e.marketingAllowed,
                    o = e.saleOfDataAllowed;
                return t && n && o
            }, e
        }(),
        K = new Y,
        J = function(e) {
            switch (ce.zone) {
                case d.EuZone1:
                    return !0;
                case d.EuZone2:
                    return !["ccpa", "gpp"].includes(e);
                default:
                    return ["ccpa", "gpp", "tcf", "shopify"].includes(e)
            }
        },
        Q = [{
            service: W,
            type: "tcf"
        }, {
            service: j,
            type: "uc"
        }, {
            service: U,
            type: "cb"
        }, {
            service: D,
            type: "di"
        }, {
            service: R,
            type: "ot"
        }, {
            service: M,
            type: "ccpa"
        }, {
            service: G,
            type: "gpp"
        }, {
            service: F,
            type: "gtm"
        }, {
            service: Z,
            type: "g111"
        }, {
            service: K,
            type: "shopify"
        }],
        X = {
            service: $,
            type: "pc"
        },
        ee = function() {
            function e() {
                this.timeouts = [], this.consentHandlerType = void 0
            }
            return e.prototype.checkHasConsent = function(e) {
                var t = this,
                    n = function(n) {
                        for (; t.timeouts.length;) clearTimeout(t.timeouts.shift());
                        e(n, t.consentHandlerType)
                    },
                    o = ce.zone === d.Default;
                try {
                    this.timeouts.push(setTimeout((function() {
                        e(o)
                    }), 500));
                    var r = this.getConsentHandlerService();
                    if (r.length) return void this.handleConsentByCmp(r, n, o);
                    if (this.hasPublisherConsent()) return void this.handleConsentByCmp([X], n, o);
                    this.keepLookingForCmp(n, o), n(o)
                } catch (e) {
                    throw n(o), e
                }
            }, e.prototype.getConsentHandlerService = function() {
                for (var e = [], t = 0, n = Q; t < n.length; t++) {
                    var o = n[t],
                        r = o.service,
                        i = o.type;
                    J(i) && r.hasConsentHandler() && e.push(o)
                }
                return e
            }, e.prototype.handleConsentByCmp = function(e, t, n) {
                var o = this;
                if (0 !== e.length)
                    for (var r = !1, i = function(e, n) {
                            e.handleConsent((function(e) {
                                !r && e && (r = !0, o.consentHandlerType = n, t(!0))
                            }))
                        }, a = 0, s = e; a < s.length; a++) {
                        var c = s[a];
                        i(c.service, c.type)
                    } else t(n)
            }, e.prototype.keepLookingForCmp = function(e, t) {
                var n = this,
                    o = 20,
                    r = setInterval((function() {
                        var i = n.getConsentHandlerService();
                        i.length && (clearInterval(r), n.handleConsentByCmp(i, e, t)), 0 == --o && clearInterval(r)
                    }), 500)
            }, e.prototype.hasPublisherConsent = function() {
                return ce.zone === d.EuZone1 && $.hasConsentSignal()
            }, e
        }(),
        te = new(function() {
            function e() {}
            return e.prototype.isTest = function(e, t) {
                return e.split("").reduce((function(e, t) {
                    return e + t.charCodeAt(0)
                }), 0) % 100 < t
            }, e.prototype.isControl = function(e, t) {
                return !this.isTest(e, t)
            }, e
        }()),
        ne = function(e, t, n) {
            if (n || 2 === arguments.length)
                for (var o, r = 0, i = t.length; r < i; r++) !o && r in t || (o || (o = Array.prototype.slice.call(t, 0, r)), o[r] = t[r]);
            return e.concat(o || Array.prototype.slice.call(t))
        },
        oe = function() {
            return oe = Object.assign || function(e) {
                for (var t, n = 1, o = arguments.length; n < o; n++)
                    for (var r in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, r) && (e[r] = t[r]);
                return e
            }, oe.apply(this, arguments)
        },
        re = function() {
            function e() {
                this.hasConsent = !1, this.isCheckConsentRespond = !1, this.gdprValidatorService = new ee
            }
            return e.prototype.drainQueue = function(e, t) {
                var n = this;
                void 0 === t && (t = null);
                for (var o = !1, r = function() {
                        var r = ce.queue.shift(),
                            i = r[0],
                            a = r[1],
                            s = r[2];
                        if (!a) return I(new Error("Can't dispatch pixel, event name is missing"), ce), "continue";
                        if ("SHOPIFY_PRIVACY" === a) return "continue";
                        if (a === g && !s) {
                            if (o) return "continue";
                            o = !0
                        }! function(e, o) {
                            var r, c;
                            r = e.toString(), c = n.getRequestParams(a, r, s), "track" === i ? (E.validate(c), n.firePixel(c, t)) : p(h.Error, "Command type ".concat(i, " is not recognized."), a)
                        }(e)
                    }; ce.queue.length;) r()
            }, e.prototype.firePixel = function(e, t) {
                void 0 === t && (t = null), !e.cht && this.consentHandlerType && (e.cht = this.consentHandlerType), this.fire(e, this.hasConsent, t)
            }, e.prototype.fire = function(e, t, n) {
                var o;
                if (void 0 === n && (n = null), t) {
                    var r = oe({
                            au: !t,
                            bust: Math.random().toString().replace(".", ""),
                            referrer: document.URL
                        }, e.cht && {
                            cht: e.cht
                        }),
                        i = this.getClickIdCookieCached(),
                        a = oe(oe(oe({}, r), function(e) {
                            e.content, e.contentType;
                            var t = function(e, t) {
                                var n = {};
                                for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && t.indexOf(o) < 0 && (n[o] = e[o]);
                                if (null != e && "function" == typeof Object.getOwnPropertySymbols) {
                                    var r = 0;
                                    for (o = Object.getOwnPropertySymbols(e); r < o.length; r++) t.indexOf(o[r]) < 0 && Object.prototype.propertyIsEnumerable.call(e, o[r]) && (n[o[r]] = e[o[r]])
                                }
                                return n
                            }(e, ["content", "contentType"]);
                            return T(T({}, t), {
                                name: t.name
                            })
                        }(e)), i && ((o = {}).ob_click_id = i, o)),
                        c = e.marketerId;
                    try {
                        window.fetch("".concat(x(), "?").concat(s(a)), {
                            keepalive: !0,
                            method: "GET",
                            mode: "no-cors",
                            credentials: "include",
                            referrerPolicy: "no-referrer-when-downgrade",
                            attributionReporting: {
                                eventSourceEligible: !1,
                                triggerEligible: !0
                            }
                        })
                    } catch (e) {
                        if (I(e, ce), te.isTest(c, 100))(n || navigator).sendBeacon(x() + "?" + s(a));
                        else {
                            var u = new Image;
                            u.referrerPolicy = "no-referrer-when-downgrade", u.src = x() + "?" + s(a)
                        }
                    }
                }
            }, e.prototype.dispatch = function() {
                var e = this.getUniqueMarketers(ce.marketerId);
                this.unifiedDispatch(e)
            }, e.prototype.unifiedDispatch = function(e) {
                if (this.isCheckConsentRespond) this.hasConsent && this.drainQueue(e);
                else {
                    var t = navigator;
                    this.gdprValidatorService.checkHasConsent(function(n, o) {
                        this.isCheckConsentRespond = !0, n && (P.dispatch(v, n), this.hasConsent = n, this.consentHandlerType = o, this.drainQueue(e, t))
                    }.bind(this))
                }
            }, e.prototype.getRequestParams = function(e, t, n) {
                var o, r = function() {
                        var e = ce.variations || [],
                            t = B.get("variations");
                        return t && t.split(",").forEach((function(t) {
                            var n = parseInt(t);
                            isNaN(n) || -1 !== e.indexOf(n) || e.push(n)
                        })), e
                    }(),
                    i = oe(oe({}, n), ((o = {
                        marketerId: t,
                        name: e,
                        dl: O.getLocation(),
                        g: this.hasGtm() ? 1 : 0,
                        zone: ce.zone
                    })["".concat("obApi", "Version")] = ce.version ? ce.version : "-1", o["".concat(_, "Version")] = ce["".concat(_, "Version")], o));
                return "shopifyEvent" in i && delete i.shopifyEvent, r.length && Object.assign(i, {
                    variationId: r.join(",")
                }), Object.keys(i).forEach((function(e) {
                    return void 0 === i[e] && delete i[e]
                })), i
            }, e.prototype.getUniqueMarketersNew = function(e) {
                return e.filter((function(e, t, n) {
                    return n.indexOf(e) === t
                }))
            }, e.prototype.getUniqueMarketers = function(e) {
                for (var t = [], n = {}, o = 0; o < e.length; o++) n[e[o]] || t.push(e[o]), n[e[o]] = !0;
                return t
            }, e.prototype.getClickIdCookieCached = function() {
                var e, t = O.getParamFromUrl(m);
                if (t) {
                    var n = O.getParamFromUrl(C);
                    B.set(w, t, 7, n), e = t
                } else e = B.get(w);
                return e && e.replace(/#/g, "")
            }, e.prototype.hasGtm = function() {
                return !!document.querySelector('script[src*="googletagmanager.com/gtm.js"]')
            }, e
        }();
    const ie = {
        zone: d.Default
    };
    var ae = window.__$$OBGeoZone || ie.zone,
        se = window.__$$loadedBy || void 0,
        ce = new function(e, t, n) {
            var o = window.obApi,
                r = function() {
                    for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
                    r.queue.push(e), r.dispatch.apply(r)
                };
            r.zone = t, r.version = o.version, r.loaded = o.loaded, r.loadedBy = null != n ? n : o.loadedBy, r.marketerId = l(o.marketerId), r.queue = o.queue;
            var i = new re;
            r.dispatch = i.dispatch.bind(i), r.addMarketer = function(e) {
                r.marketerId = r.marketerId.concat(l(e))
            }, r["".concat(_, "Version")] = "2.18.168", e.obApi = r, this.apiObj = r
        }(window, ae, se).apiObj,
        ue = new ee,
        pe = function() {
            function e(e) {
                this.eventBusService = e
            }
            return e.prototype.getCachedClickId = function() {
                var e, t, n, o = document;
                if (!B.get(w) && (n = parseInt(B.get(b)), isNaN(n) || Date.now() - n > 3e5) && !O.getParamFromUrl(m)) {
                    var r = this;
                    ce.setCachedClickId = (e = function() {
                        var e, t = document.createElement("script"),
                            n = "string" == typeof(e = ce.marketerId) ? e : a(e) ? e.join(",") : void 0;
                        t.src = A() + "/cachedClickId?marketerId=" + n, o.body.appendChild(t)
                    }, t = function() {
                        B.set(b, Date.now(), 5 / 1440)
                    }, ue.checkHasConsent((function(t) {
                        t && e()
                    })), r.eventBusService.on(v, (function(t) {
                        t && e()
                    })), function(e) {
                        if ("optout" !== e)
                            if ("NoClickId" === e) ce.zone === d.Default ? t() : (ue.checkHasConsent((function(e) {
                                e && t()
                            })), r.eventBusService.on(v, (function(e) {
                                e && t()
                            })));
                            else {
                                var n = O.getParamFromUrl(C);
                                e && (e = e.replace(/#/g, "")), B.set(w, e, 7, n)
                            }
                    })
                }
            }, e
        }();
    try {
        var le = ce.zone === d.Default;
        ! function(e) {
            e.addVariation = function(t) {
                if (e.variations || (e.variations = []), !(e.variations.indexOf(t) > -1)) {
                    e.variations.push(t);
                    var n = B.get("variations"),
                        o = n ? n.split(",").map((function(e) {
                            return parseInt(e)
                        })) : [];
                    o.indexOf(t) > -1 || B.set("variations", "".concat(ne(ne([], o, !0), [t], !1)))
                }
            }
        }(ce), new function() {
            if (history.pushState && history.replaceState && window.addEventListener) {
                var e = this,
                    t = function(t) {
                        location.href !== e.lastVisited && t && (e.lastVisited = location.href, ce("track", g))
                    };
                u(history, "pushState", t), u(history, "replaceState", t), window.addEventListener("popstate", t, !1)
            }
        }, P.on(v, (function(e) {
            le = e, e && (function() {
                var e, t;

                function n(e) {
                    var t = document.createElement("script");
                    t.async = !0, t.src = e, t.type = "text/javascript";
                    var n = document.getElementsByTagName("script")[0];
                    n.parentNode.insertBefore(t, n)
                }
                var o = function(e) {
                    var t, r;
                    if (["https://my.outbrain.com", "http://localhost:4949", "http://localhost:2109", "https://simsite.outbrain.com"].indexOf(e.origin) > -1 && "SHOW_EVENT_PICKER" === (null === (t = e.data) || void 0 === t ? void 0 : t.message)) {
                        var i = (null === (r = e.data) || void 0 === r ? void 0 : r.content).appName;
                        n("https://my.outbrain.com/events-picker-app?appName=".concat(i || "codeless")), window.opener.postMessage({
                            message: "EVENT_PICKER_CONNECTED"
                        }, e.origin), window.removeEventListener("message", o)
                    }
                };
                window.addEventListener("message", o), null === (t = null === (e = null === top || void 0 === top ? void 0 : top.window.opener) || void 0 === e ? void 0 : e.postMessage) || void 0 === t || t.call(e, {
                    message: "OB_SHOULD_SHOW_PICKER",
                    content: {
                        marketerId: ce.marketerId
                    }
                }, "*");
                try {
                    Array.isArray(ce.marketerId) && ce.marketerId.filter((function(e) {
                        return !!e
                    })).slice(0, 9).forEach((function(e) {
                        return n("".concat(L() ? "https://p.teads.tv/obwave/" : "https://wave.outbrain.com/", "mtWavesBundler/handler/").concat(e.trim()))
                    }))
                } catch (e) {
                    I(e, ce)
                }
            }(), function() {
                if ("browsingTopics" in document && "featurePolicy" in document && window.document.featurePolicy.allowsFeature("browsing-topics")) {
                    var e = L() ? "https://p.teads.tv/obtp/topics" : "https://amplify.outbrain.com/topics";
                    fetch(e, {
                        browsingTopics: !0
                    }).then((function(e) {}))
                }
            }())
        })), ce.dispatch.apply(ce), new pe(P).getCachedClickId()
    } catch (e) {
        le && I(e, ce)
    }
    return i
})()));