var __defProp = Object.defineProperty,
    __defProps = Object.defineProperties,
    __getOwnPropDescs = Object.getOwnPropertyDescriptors,
    __getOwnPropSymbols = Object.getOwnPropertySymbols,
    __hasOwnProp = Object.prototype.hasOwnProperty,
    __propIsEnum = Object.prototype.propertyIsEnumerable,
    __pow = Math.pow,
    __defNormalProp = (e, t, r) => t in e ? __defProp(e, t, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: r
    }) : e[t] = r,
    __spreadValues = (e, t) => {
        for (var r in t || (t = {})) __hasOwnProp.call(t, r) && __defNormalProp(e, r, t[r]);
        if (__getOwnPropSymbols)
            for (var r of __getOwnPropSymbols(t)) __propIsEnum.call(t, r) && __defNormalProp(e, r, t[r]);
        return e
    },
    __spreadProps = (e, t) => __defProps(e, __getOwnPropDescs(t)),
    __objRest = (e, t) => {
        var r = {};
        for (var n in e) __hasOwnProp.call(e, n) && t.indexOf(n) < 0 && (r[n] = e[n]);
        if (null != e && __getOwnPropSymbols)
            for (var n of __getOwnPropSymbols(e)) t.indexOf(n) < 0 && __propIsEnum.call(e, n) && (r[n] = e[n]);
        return r
    },
    __async = (e, t, r) => new Promise(((n, i) => {
        var o = e => {
                try {
                    l(r.next(e))
                } catch (t) {
                    i(t)
                }
            },
            a = e => {
                try {
                    l(r.throw(e))
                } catch (t) {
                    i(t)
                }
            },
            l = e => e.done ? n(e.value) : Promise.resolve(e.value).then(o, a);
        l((r = r.apply(e, t)).next())
    }));
! function() {
    "use strict";
    const e = (e, t = ["userway"]) => {
            const r = __spreadProps(__spreadValues({}, e), {
                isUserWay: !0
            });
            t.forEach((e => {
                let t = window.frames[e];
                if (!t || "function" != typeof t.postMessage) try {
                    t = document.querySelector(`iframe[name=${e}]`), t = t ? t.contentWindow : null
                } catch (n) {
                    console.error(n)
                }
                t && t.postMessage(r, "*")
            }))
        },
        t = (e, t) => {
            if (e === document) return !0;
            const r = e,
                n = getComputedStyle(r),
                i = r.getBoundingClientRect(),
                o = (e => e.top >= 0 && e.left >= 0 && e.bottom <= (window.innerHeight || document.documentElement.clientHeight) && e.right <= (window.innerWidth || document.documentElement.clientWidth))(i),
                a = 0 === i.width || 0 === i.height,
                l = "0" !== n.opacity && "hidden" !== n.visibility && "none" !== n.display && "collapse" !== n.visibility;
            return (r.offsetWidth > 0 || r.offsetHeight > 0 || r.getClientRects().length > 0) && (!t.shouldBeInViewport || o) && !a && l
        },
        r = e => e.nodeType === Node.ELEMENT_NODE,
        n = e => {
            if (!r(e)) return !1;
            const t = e.getAttribute("aria-hidden"),
                n = e.getAttribute("hidden");
            return (e => !!r(e) && "none" === window.getComputedStyle(e).display)(e) || "true" === t || null !== n && "" !== n
        },
        i = e => {
            if (!r(e)) return !1;
            const t = e.getAttribute("aria-hidden"),
                n = e.getAttribute("hidden");
            return "true" === t || null !== n && "" !== n || void 0
        },
        o = ["NOSCRIPT", "SCRIPT", "style"],
        a = (e, t, r = {
            includeTextFromVisuallyHiddenElements: !1
        }) => {
            var l;
            const {
                includeTextFromVisuallyHiddenElements: s
            } = r;
            for (let u = 0; u < e.length; u++) {
                let c = e[u];
                switch (c.nodeType) {
                    case Node.TEXT_NODE:
                        t += " " + (null == (l = c.textContent) ? void 0 : l.trim().replace(/(\n|\r\n)/g, ""));
                        break;
                    case Node.ELEMENT_NODE:
                        if (o.includes(c.tagName) || (s ? i(c) : n(c))) break;
                        const e = c.getAttribute("aria-hidden"),
                            u = c.getAttribute("alt"),
                            d = c.getAttribute("aria-label");
                        if (!e || "false" === e) {
                            if (d) {
                                t += " " + d;
                                break
                            }
                            u && (t += u + " "), "IMG" !== c.tagName && (t = a(c.childNodes, t, r))
                        }
                }
            }
            return t
        },
        l = (e, t = "", r = {
            includeTextFromVisuallyHiddenElements: !1
        }) => {
            let n = t;
            return (t = a(e.childNodes, n, r)).replace(/\s+/g, " ").trim()
        },
        s = e => {
            let t = e.split(" "),
                r = "";
            for (let n = 0; n < t.length; n++) {
                let e = document.getElementById(t[n]);
                e && (r = l(e, r))
            }
            return r
        },
        u = e => e.split(" ").reduce(((e, t) => {
            const r = document.getElementById(t.trim());
            if (!r) return e;
            if ((e => ["noscript", "style", "img", "script", "br", "hr"].includes(e.tagName.toLowerCase()))(r)) return e;
            const n = l(r);
            return n ? e + " " + n : e
        }), "").trim(),
        c = (e, t = {}) => {
            var r, n, i;
            let o = null != (n = null == (r = e.getAttribute("aria-label")) ? void 0 : r.trim()) ? n : "";
            const a = !(null == (i = null == t ? void 0 : t.excludeAttribute) ? void 0 : i.includes("aria-describedby")) && e.getAttribute("aria-describedby");
            if (o += a ? u(a) : "", o) return o.toLowerCase();
            const s = e.getAttribute("aria-labelledby");
            if (s && (o += u(s)), o.trim()) return o.toLowerCase();
            if (o = l(e), o.trim()) return o.toLowerCase();
            if ("INPUT" === e.tagName) {
                const t = e;
                if (o = t.value || "", o.trim() && t.type && ["button", "submit", "reset"].includes(t.type.toLowerCase())) return o.toLowerCase()
            }
            if (!e.hasChildNodes()) return null;
            let c = e.querySelector('img, *[role="img"]');
            return c && (o = d(c) || "", o.trim()) ? o.toLowerCase() : null
        },
        d = e => {
            const t = e.alt;
            if (t && t.trim()) return t.trim();
            const r = e.getAttribute("aria-label");
            if (r && r.trim()) return r.trim();
            const n = e.getAttribute("aria-describedby");
            if (n) {
                const e = u(n);
                if (e) return e
            }
            const i = e.getAttribute("aria-labelledby");
            if (i) {
                let e = u(i);
                if (e) return e
            }
            return null
        },
        p = () => "uw" + (~~(1e8 * Math.random())).toString(16),
        m = (e, t = "") => {
            const r = document.createElement("span");
            return r.textContent = e, r.style = "color: #ffffff!important;background: #000000!important;clip: rect(1px, 1px, 1px, 1px)!important;clip-path: inset(50%)!important;height: 1px!important;width: 1px!important;margin: -1px!important;overflow: hidden!important;padding: 0!important;position: absolute!important;", r.setAttribute("class", t), r.setAttribute("data-uw-reader-element", ""), r.setAttribute("data-uw-rm-ignore", ""), r
        },
        g = (e, t = 0) => {
            let r = 3735928559 ^ t,
                n = 1103547991 ^ t;
            for (let i, o = 0; o < e.length; o++) i = e.charCodeAt(o), r = Math.imul(r ^ i, 2654435761), n = Math.imul(n ^ i, 1597334677);
            return r = Math.imul(r ^ r >>> 16, 2246822507) ^ Math.imul(n ^ n >>> 13, 3266489909), n = Math.imul(n ^ n >>> 16, 2246822507) ^ Math.imul(r ^ r >>> 13, 3266489909), 4294967296 * (2097151 & n) + (r >>> 0)
        },
        f = (e, t = !1) => {
            var r;
            if ("html" === e.nodeName.toLowerCase()) return "/HTML";
            if ("body" === e.nodeName.toLowerCase()) return "/HTML/BODY";
            if ("head" === e.nodeName.toLowerCase()) return "/HTML/HEAD";
            let n = 0;
            const i = null == (r = e.parentElement) ? void 0 : r.children;
            if (!i) return "";
            for (let o = 0; o < i.length; o++) {
                let r = i[o];
                if (r === e) return f(e.parentElement, !0) + `/${e.tagName}[${n+1}]` + (t ? "" : h(e));
                r.tagName === e.tagName && n++
            }
            return ""
        };

    function h(e) {
        const t = {
                s: "src",
                h: "href"
            },
            r = e.innerText ? g(e.innerText) : "";
        return Object.keys(t).reduce(((r, n) => {
            const i = t[n],
                o = e.getAttribute(i) || "";
            return e.hasAttribute && e.hasAttribute(i) && "" !== o ? r + ";" + n + ":" + g(o) : r
        }), "|" + r)
    }
    const b = new RegExp("^(data:)"),
        A = new RegExp("(.)(gif|jpe?g|tiff?|png|webp|bmp)", "i"),
        y = e => {
            if (b.test(e)) return e;
            e && (e = e.replace(/^(http|https)(:\/\/)/, "").replace(/^(www\.)/, ""));
            const t = e.match(A);
            return (null == t ? void 0 : t.index) && (null == t ? void 0 : t.length) ? e.substring(0, t.index + t[0].length) : e.split("?")[0]
        },
        E = e => [].slice.call(document.querySelectorAll(e)),
        v = (e, t, r = !1) => e.reduce(((e, n) => {
            const i = r && n.position ? ":nth-of-type(" + n.position + ")" : "";
            return e += n.tag + i + (n.idx >= t ? ">" : " ")
        }), "").slice(0, -1),
        _ = (e, t) => {
            if (null === t) return !0;
            const r = e.innerText ? g(e.innerText).toString() : "";
            if (t.innerText.toString() !== r) return !1;
            const n = e.hasAttribute("href") ? g(e.getAttribute("href")).toString() : "";
            if (t.href && t.href !== n) return !1;
            const i = e.hasAttribute("src") ? g(e.getAttribute("src")).toString() : "";
            return !t.src || t.src === i
        },
        w = (e, t = null, r) => {
            const n = E(e);
            if (1 === n.length) {
                if (null == r.params) return n[0];
                if (_(n[0], t)) return n[0]
            }
            if (n.length > 1) {
                if (null == r.params) return null;
                const e = n.filter((e => _(e, t)));
                if (1 === e.length) return e[0]
            }
            return null
        };
    var T = (e => (e[e.Strict = 0] = "Strict", e[e.Medium = 1] = "Medium", e[e.Loose = 2] = "Loose", e))(T || {});
    const N = {
            i: "innerText",
            s: "src",
            h: "href"
        },
        x = e => {
            const [t, r] = e.split("|");
            let n = {
                innerText: ""
            };
            if (r) {
                const [e, ...t] = r.split(";");
                n.innerText = e, t.forEach((e => {
                    const [t, r] = e.split(":");
                    n[N[t]] = r
                }))
            }
            return {
                xpath: t,
                params: n
            }
        },
        I = e => {
            if ("/HTML/BODY" === e) return E("html>body")[0];
            const {
                xpath: t,
                params: r
            } = x(e), n = ((e, t) => {
                const r = ("/" === e[0] ? e.slice(1) : e).split("/");
                return r.map(((e, n) => {
                    const i = e.toLowerCase(),
                        [, o, a] = i.match(/(\S+)\[(\S+)?\]/) || [, i],
                        l = r.length - 1 === n,
                        s = {
                            idx: n,
                            tag: o
                        };
                    return a && (s.position = +a), l && t && (s.params = t), s
                }))
            })(t, r);
            return ((e, t = 4) => {
                let r = e.length - 2 - t;
                const n = e[e.length - 1];
                let i;
                const o = n.params;
                if (r < 0) {
                    i = v(e, 0, !0);
                    return w(i, o, n) || (i = v(e, 0), w(i, o, n))
                }
                const a = a => {
                        for (r = e.length - 2 - t; r >= 0; r--) {
                            i = a === T.Loose ? v(e.slice(0, 2).concat(...e.slice(-r - t)), e.length - t) : v(e, e.length - t - r - 1, a === T.Strict);
                            const l = w(i, o, n);
                            if (l) return l
                        }
                    },
                    l = [T.Strict, T.Medium, T.Loose];
                for (let s = 0; s < l.length; s++) {
                    const e = a(l[s]);
                    if (e) return e
                }
                return null
            })(n)
        },
        L = e => {
            const {
                xpath: t,
                params: r
            } = x(e), n = document.evaluate(t, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
            return n && _(n, r) ? n : null
        },
        S = e => {
            let t = e.closest("label"),
                r = "";
            if (t) {
                for (let e of t.childNodes) e.nodeType === Node.TEXT_NODE && (r += e.textContent);
                if (r.trim()) return r.trim()
            }
            if (e.id) {
                let t = (e => {
                    for (const t of document.querySelectorAll("label"))
                        if (t.htmlFor === e) return t;
                    return null
                })(e.id);
                if (t) return l(t, "")
            }
            const n = e.getAttribute("aria-label"),
                i = e.getAttribute("aria-labelledby");
            if (n) return n;
            if (i) return s(i);
            const o = e.getAttribute("title");
            if (o) return o;
            return l(e, "") || ""
        },
        C = ["script", "noscript", "style", "meta", "link", "path", "circle", "rect", "ellipse", "line", "polygon", "polyline", "g"],
        O = [".uwy", ".uwy *", ".uw-sl *"],
        R = ["data-uw-ignore", "data-uw-rm-ignore"],
        k = (e, t = 3) => {
            const r = (e, t) => {
                if (t < 1) return "";
                const n = e.childElementCount;
                let i = "";
                return n || (i += e.textContent), !i && e.length && (i += e.nodeValue), n && e.childNodes.length && (i += [...e.childNodes].map((e => r(e, t - 1))).join(" ")), i
            };
            return r(e, t)
        },
        D = e => e.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;"),
        M = e => {
            try {
                const t = new URL(e);
                return ["http:", "https:"].includes(t.protocol)
            } catch (t) {
                return !1
            }
        },
        P = ["untitled", "test", "page", "default"],
        U = e => {
            if (!(e.length >= 3)) return !1;
            if (/^\d+$/.test(e)) return !1;
            if (!(e => {
                    const t = e.trim().toLowerCase();
                    return !P.includes(t) && t.split(" ").some((e => !P.includes(e)))
                })(e)) return !1;
            const t = new RegExp("(.)\\1{3,}").test(e),
                r = 1 === e.split(" ").length;
            return !t || !r
        },
        W = e => !(e instanceof HTMLElement) || R.some((t => e.hasAttribute(t))) || O.some((t => e.classList.contains(t))) || C.includes(e.nodeName.toLowerCase()),
        B = (e, t) => {
            try {
                if ("childList" === t) {
                    const t = [...e.addedNodes].reduce(((e, t) => {
                        if (t instanceof HTMLElement) {
                            const r = [...t.getElementsByTagName("*")];
                            return [...e, ...r]
                        }
                        return e
                    }), []);
                    return [].filter.call([...e.addedNodes, ...t], (e => !W(e)))
                }
                return "attributes" === t ? W(e.target) ? [] : [e.target] : []
            } catch (r) {
                return []
            }
        },
        $ = {
            AriaEditorValues: [],
            BrokenLink: [],
            Contrast: [],
            EmptyControls: [],
            ExternalLink: [],
            Forms: [],
            Headings: [],
            Language: [],
            MissingAlts: [],
            Pdfs: [],
            VagueLinks: []
        },
        H = e => __async(this, null, (function*() {
            const t = yield fetch(e), r = yield t.json();
            return __spreadValues(__spreadValues({}, $), r)
        })),
        j = UserWayWidgetApp.ContextHolder.config.remediation,
        V = UserWayWidgetApp.ContextHolder.config.tunings,
        F = UserWayWidgetApp.ContextHolder.config.services,
        X = UserWayWidgetApp.ContextHolder.config.imageAlt,
        q = UserWayWidgetApp.ContextHolder.config.settings,
        {
            isMobile: G,
            language: z
        } = UserWayWidgetApp.ContextHolder.config;
    let K = {};

    function Z(e) {
        K = __spreadValues({}, e)
    }

    function Y() {
        return K
    }
    const Q = () => __async(this, null, (function*() {
            if (null == j ? void 0 : j.consolidated) {
                const e = yield H(j.consolidated);
                return e.MissingAlts.reverse(), void Z(e)
            }
            Z($)
        })),
        J = "https://api.userway.org/api/",
        ee = "https://cdn77.api.userway.org/";
    var te = (e => (e.Remediation = "remediation", e.AriaEditor = "aria-editor", e))(te || {}),
        re = (e => (e.KeyboardNavEnabled = "app-key-nav-enabled", e))(re || {});
    const ne = e => {
            const t = UserWayWidgetApp.getLib("util"),
                {
                    registerPostMessageListener: r
                } = t;
            return r((t => {
                var r;
                (null == (r = null == t ? void 0 : t.data) ? void 0 : r.isUserWay) && e(t)
            }))
        },
        ie = document.documentElement,
        oe = {
            attributes: !0,
            attributeFilter: ["aria-label", "alt"],
            childList: !0,
            subtree: !0
        },
        ae = new Set,
        le = e => {
            ae.add(e)
        },
        se = new MutationObserver((e => {
            const t = (e => {
                const t = [];
                for (const r of e) t.push(...B(r, r.type));
                return t
            })(e);
            t.length && ae.forEach((e => e(t)))
        })),
        ue = [{
            src: "wave.min.js",
            name: "Wave"
        }, {
            src: "axe.min.js",
            name: "BrowserStack"
        }],
        ce = [{
            url: "wave.webaim.org",
            name: "Wave"
        }],
        de = (e, t) => {
            try {
                const r = [];
                return "childList" === t && e.addedNodes.length && e.addedNodes.forEach((e => {
                    const t = (e => {
                        if ("script" === e.nodeName.toLowerCase()) {
                            const t = ue.find((t => e.src.includes(t.src)));
                            if (t) return t
                        }
                        return "iframe" === e.nodeName.toLowerCase() && e.title.toLowerCase().includes("equalweb") ? {
                            name: "EqualWeb"
                        } : null
                    })(e);
                    t && r.push(t)
                })), r
            } catch (r) {
                return []
            }
        },
        pe = (e, t) => __async(this, null, (function*() {
            const {
                account: r
            } = UserWayWidgetApp.ContextHolder.config, n = {
                date: (new Date).toISOString(),
                url: window.location.href,
                scannerName: e,
                a11yScore: t
            };
            yield fetch(`${J}scaner-activity/${r}`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(n)
            }).catch((e => {
                console.log(e)
            }))
        })),
        me = e => {
            try {
                UserWayWidgetApp.getLib("scan_manager").accessibilityScore().then((t => {
                    pe(e, t)
                }))
            } catch (t) {
                console.log(t)
            }
        },
        ge = document.documentElement,
        fe = {
            childList: !0,
            subtree: !0
        },
        he = new MutationObserver((e => {
            const t = (e => {
                const t = [];
                for (const r of e) t.push(...de(r, r.type));
                return t
            })(e)[0];
            t && me(t.name)
        }));
    var be = "object" == typeof global && global && global.Object === Object && global,
        Ae = "object" == typeof self && self && self.Object === Object && self,
        ye = be || Ae || Function("return this")(),
        Ee = ye.Symbol,
        ve = Object.prototype,
        _e = ve.hasOwnProperty,
        we = ve.toString,
        Te = Ee ? Ee.toStringTag : void 0;
    var Ne = Object.prototype.toString;
    var xe = Ee ? Ee.toStringTag : void 0;

    function Ie(e) {
        return null == e ? void 0 === e ? "[object Undefined]" : "[object Null]" : xe && xe in Object(e) ? function(e) {
            var t = _e.call(e, Te),
                r = e[Te];
            try {
                e[Te] = void 0;
                var n = !0
            } catch (o) {}
            var i = we.call(e);
            return n && (t ? e[Te] = r : delete e[Te]), i
        }(e) : function(e) {
            return Ne.call(e)
        }(e)
    }
    var Le = /\s/;
    var Se = /^\s+/;

    function Ce(e) {
        return e ? e.slice(0, function(e) {
            for (var t = e.length; t-- && Le.test(e.charAt(t)););
            return t
        }(e) + 1).replace(Se, "") : e
    }

    function Oe(e) {
        var t = typeof e;
        return null != e && ("object" == t || "function" == t)
    }
    var Re = /^[-+]0x[0-9a-f]+$/i,
        ke = /^0b[01]+$/i,
        De = /^0o[0-7]+$/i,
        Me = parseInt;

    function Pe(e) {
        if ("number" == typeof e) return e;
        if (function(e) {
                return "symbol" == typeof e || function(e) {
                    return null != e && "object" == typeof e
                }(e) && "[object Symbol]" == Ie(e)
            }(e)) return NaN;
        if (Oe(e)) {
            var t = "function" == typeof e.valueOf ? e.valueOf() : e;
            e = Oe(t) ? t + "" : t
        }
        if ("string" != typeof e) return 0 === e ? e : +e;
        e = Ce(e);
        var r = ke.test(e);
        return r || De.test(e) ? Me(e.slice(2), r ? 2 : 8) : Re.test(e) ? NaN : +e
    }
    var Ue = function() {
            return ye.Date.now()
        },
        We = Math.max,
        Be = Math.min;

    function $e(e, t, r) {
        var n, i, o, a, l, s, u = 0,
            c = !1,
            d = !1,
            p = !0;
        if ("function" != typeof e) throw new TypeError("Expected a function");

        function m(t) {
            var r = n,
                o = i;
            return n = i = void 0, u = t, a = e.apply(o, r)
        }

        function g(e) {
            var r = e - s;
            return void 0 === s || r >= t || r < 0 || d && e - u >= o
        }

        function f() {
            var e = Ue();
            if (g(e)) return h(e);
            l = setTimeout(f, function(e) {
                var r = t - (e - s);
                return d ? Be(r, o - (e - u)) : r
            }(e))
        }

        function h(e) {
            return l = void 0, p && n ? m(e) : (n = i = void 0, a)
        }

        function b() {
            var e = Ue(),
                r = g(e);
            if (n = arguments, i = this, s = e, r) {
                if (void 0 === l) return function(e) {
                    return u = e, l = setTimeout(f, t), c ? m(e) : a
                }(s);
                if (d) return clearTimeout(l), l = setTimeout(f, t), m(s)
            }
            return void 0 === l && (l = setTimeout(f, t)), a
        }
        return t = Pe(t) || 0, Oe(r) && (c = !!r.leading, o = (d = "maxWait" in r) ? We(Pe(r.maxWait) || 0, t) : o, p = "trailing" in r ? !!r.trailing : p), b.cancel = function() {
            void 0 !== l && clearTimeout(l), u = 0, n = s = i = l = void 0
        }, b.flush = function() {
            return void 0 === l ? a : h(Ue())
        }, b
    }
    const He = "AUTO";
    let je = !0;
    const Ve = e => {
        setTimeout((() => {
            je = !1
        }), 2e3);
        const t = function(e, t, r) {
                var n = !0,
                    i = !0;
                if ("function" != typeof e) throw new TypeError("Expected a function");
                return Oe(r) && (n = "leading" in r || n, i = "trailing" in r || i), $e(e, t, {
                    leading: n,
                    maxWait: t,
                    trailing: i
                })
            }(((t, r) => e(t, r)), 300, {
                leading: !0,
                trailing: !0
            }),
            r = $e(((t, r) => e(t, r)), 500, {
                maxWait: 2e3,
                leading: !0,
                trailing: !0
            });
        return {
            run: (e, n) => je ? t(e, n) : r(e, n)
        }
    };
    var Fe = (e => (e.TABINDEX = "tabindex", e.ROLE = "role", e.TYPE = "type", e.SRC = "src", e.ARIA_LEVEL = "ariaLevel", e.ORIGINAL_ALT = "originalAlt", e))(Fe || {}),
        Xe = (e => (e.UNKNOWN = "UNKNOWN", e.NOT_ALLOWED = "NOT_ALLOWED", e.TEXT_NODE = "TEXT_NODE", e.LANDMARK = "LANDMARK", e.CONTROL = "CONTROL", e.HEADING = "HEADING", e.HAS_ALT_DESCRIPTION = "HAS_ALT_DESCRIPTION", e.COMPOSED_TEXT_NODES = "COMPOSED_TEXT_NODES", e.IFRAME = "IFRAME", e.HIDDEN_FOR_READER = "HIDDEN_FOR_READER", e))(Xe || {}),
        qe = (e => (e.UNKNOWN = "unknown", e.TEXT = "text", e.IMAGE = "image", e.HEADING = "heading", e.FOOTER = "footer", e.HEADER = "header", e.NAV = "nav", e.MAIN = "main", e.FORM = "form", e.LANDMARK = "landmark", e.LINK = "link", e.BUTTON = "button", e.CHECKBOX = "checkbox", e.RADIOBUTTON = "radiobutton", e.INPUT = "input", e.TEXTAREA = "textarea", e.SELECT = "select", e.ABBR = "abbr", e.LIST_ITEM = "list item", e))(qe || {});
    const Ge = "accessibility-tree-observer",
        ze = ["uw-sl", "uwy", "uw-s10-reading-guide", "uw-s12-tooltip"],
        Ke = (e, t) => t.ariaLabel ? t.ariaLabel : t.ariaLabelledBy ? s(t.ariaLabelledBy) : l(e, ""),
        Ze = {},
        Ye = UserWayWidgetApp.getLib("accessibility_tree_walker");
    let Qe, Je = [],
        et = 1;
    const tt = (e, t) => {
            var r;
            if (Je = [], (e => {
                    const t = 3 === e.nodeType;
                    return ze.some((t => !!e.closest && e.closest(`.${t}`))) || !t && e.hasAttribute("data-uw-rm-ignore")
                })(e) && !t) return null;
            const n = {
                    node: e,
                    type: Ye.identifyElementType(e)
                },
                i = (e => {
                    if (!e || !e.type) return {};
                    const {
                        node: t
                    } = e;
                    return [Xe.UNKNOWN, Xe.NOT_ALLOWED, Xe.TEXT_NODE].includes(e.type) ? {
                        uwAtoId: t.uwAtoId
                    } : {
                        tagName: t.tagName,
                        tabindex: t.getAttribute("tabindex") || "",
                        role: t.getAttribute("role") || "",
                        ariaLevel: t.getAttribute("aria-level") || "",
                        ariaLabel: t.getAttribute("aria-label") || "",
                        ariaLabelledBy: t.getAttribute("aria-labelledby") || "",
                        type: t.getAttribute("type") || "",
                        uwAtoId: t.uwAtoId
                    }
                })(n);
            Qe = Ye.identifyElementType(e);
            const o = Qe === Xe.HIDDEN_FOR_READER;
            let a, u;
            switch (Je = (e => (e.tabindex && Je.push({
                name: Fe.TABINDEX,
                value: e.tabindex
            }), e.role && Je.push({
                name: Fe.ROLE,
                value: e.role
            }), e.type && Je.push({
                name: Fe.TYPE,
                value: e.type
            }), e.ariaLevel && Je.push({
                name: Fe.ARIA_LEVEL,
                value: e.ariaLevel
            }), Je))(i), o && ((e, t) => {
                const r = e.cloneNode(!0);
                r.removeAttribute("aria-hidden"), Qe = Ye.identifyElementType(r), Qe !== Xe.UNKNOWN || "IMG" !== t.tagName && "img" !== t.role || (Qe = Xe.HAS_ALT_DESCRIPTION)
            })(e, i), Qe) {
                case Xe.TEXT_NODE:
                    a = (e => {
                        const t = qe.TEXT;
                        let r = "";
                        e.textContent && (r = e.textContent.trim().replace(/(\n|\r\n)/g, "").replace(/\s+/g, " "));
                        const n = {};
                        return e.parentElement && (n.parentXpath = f(e.parentElement)), {
                            semanticType: t,
                            textToRead: r,
                            additionalParams: n
                        }
                    })(e), Ze.parentXpath = null == (r = a.additionalParams) ? void 0 : r.parentXpath;
                    break;
                case Xe.COMPOSED_TEXT_NODES:
                    a = ((e, t) => ({
                        semanticType: "LI" === t.tagName ? qe.LIST_ITEM : qe.TEXT,
                        textToRead: t.ariaLabel || l(e, "")
                    }))(e, i);
                    break;
                case Xe.HIDDEN_FOR_READER:
                    a = {
                        semanticType: qe.UNKNOWN,
                        textToRead: ""
                    };
                    break;
                case Xe.HEADING:
                    a = ((e, t) => ({
                        semanticType: qe.HEADING,
                        textToRead: t.ariaLabel || l(e, "")
                    }))(e, i);
                    break;
                case Xe.LANDMARK:
                    a = (e => {
                        let t, r = "";
                        e.ariaLabel ? r = e.ariaLabel : e.ariaLabelledBy && (r = s(e.ariaLabelledBy));
                        const {
                            tagName: n
                        } = e, {
                            role: i
                        } = e;
                        return t = "FOOTER" === n || "contentinfo" === i ? qe.FOOTER : "HEADER" === n || "banner" === i ? qe.HEADER : "FORM" === n || "form" === i ? qe.FORM : "MAIN" === n || "main" === i ? qe.MAIN : "NAV" === n || "navigation" === i ? qe.NAV : qe.LANDMARK, {
                            semanticType: t,
                            textToRead: r
                        }
                    })(i);
                    break;
                case Xe.CONTROL:
                    a = ((e, t) => {
                        const {
                            tagName: r,
                            role: n,
                            type: i,
                            ariaLabel: o,
                            ariaLabelledBy: a
                        } = t;
                        let l = !1,
                            u = "",
                            c = qe.TEXT;
                        return "menuitem" === n || "option" === n ? (u = Ke(e, t), l = !0) : "link" === n || "A" === r && !n ? (c = qe.LINK, u = Ke(e, t), l = !0) : "button" === n || "BUTTON" === r ? (c = qe.BUTTON, u = Ke(e, t), l = !0) : "INPUT" !== r || "button" !== i && "submit" !== i && "reset" !== i || (c = qe.BUTTON, o ? u = o : a && (u = s(a)), l = !0), l || (u = S(e), "checkbox" === n || "INPUT" === r && "checkbox" === i ? c = qe.CHECKBOX : "radio" === n || "INPUT" === r && "radio" === i ? c = qe.RADIOBUTTON : "INPUT" === r && (c = qe.INPUT), "TEXTAREA" === r && (c = qe.TEXTAREA), "SELECT" === r && (c = qe.SELECT)), {
                            semanticType: c,
                            textToRead: u
                        }
                    })(e, i);
                    break;
                case Xe.HAS_ALT_DESCRIPTION:
                    a = ((e, t, r) => {
                        const {
                            tagName: n,
                            role: i,
                            ariaLabel: o
                        } = t, a = e.getAttribute("alt") || "", l = e.getAttribute("title") || "", s = e.getAttribute("data-uw-rm-ima-original") || "";
                        let u = "",
                            c = qe.TEXT;
                        const d = r;
                        return "IMG" !== n && "img" !== i || (c = qe.IMAGE, d.push({
                            name: Fe.SRC,
                            value: e.src
                        }), d.push({
                            name: Fe.ORIGINAL_ALT,
                            value: s
                        }), u = o || a || s || u), "ABBR" === n && (c = qe.ABBR, u = l), {
                            semanticType: c,
                            textToRead: u,
                            attributesToReturn: d
                        }
                    })(e, i, Je), a.attributesToReturn && (Je = a.attributesToReturn);
                    break;
                case Xe.UNKNOWN:
                    a = ((e, t) => {
                        let r = qe.TEXT;
                        return "DIV" !== t.tagName || e.innerHTML || (r = qe.LANDMARK), {
                            semanticType: r,
                            textToRead: ""
                        }
                    })(e, i);
                    break;
                default:
                    a = {
                        textToRead: "",
                        semanticType: qe.TEXT
                    }
            }
            return i.uwAtoId ? u = i.uwAtoId : (u = et, et += 1, n.node.uwAtoId = u), __spreadValues({
                id: u,
                xpath: f(e),
                label: a.textToRead.replace(/\|/g, "").trim(),
                tagName: i.tagName || "",
                type: a.semanticType,
                hidden: o,
                attributes: Je,
                el: n.node
            }, Ze)
        },
        rt = UserWayWidgetApp.getLib("accessibility_tree_walker");
    let nt = [];
    const it = () => {
            let t = null;
            nt = [];
            do {
                const e = rt.getNextAccessibilityTreeNode(t);
                if (!e) break;
                const r = tt(e.node);
                r && nt.push(r), t = e.node
            } while (t);
            nt = nt.map((e => {
                const t = e,
                    {
                        el: r
                    } = t;
                return __objRest(t, ["el"])
            })), e({
                action: Ge,
                type: "userway:ato-output:get",
                data: {
                    nodes: nt,
                    version: Date.now()
                }
            }, ["uwAccessibilityEditor"])
        },
        ot = () => nt,
        at = {
            enabled: !1
        },
        lt = {
            "userway:ato-input:enable": () => {
                at.enabled || (at.enabled = !0, le(it), it())
            },
            "userway:ato-input:disable": () => {
                var e;
                at.enabled && (at.enabled = !1, e = it, ae.delete(e))
            },
            "userway:ato-input:get": it
        },
        st = "REMEDIATION_EXTERNAL_LINK_TARGETS",
        ut = "data-uw-rm-ext-link",
        ct = "REMEDIATION_SKIP_NAVIGATION_LINK",
        dt = ["A", "BUTTON", "SELECT", "TEXTAREA", "INPUT"],
        pt = ["skip", "pass", "jump"],
        mt = "REMEDIATION_VAGUE_LINK",
        gt = "data-uw-rm-vglnk",
        ft = ["here", "click here", "clicking", "clicking here", "download", "download now", "click", "click this", "this", "link", "more", "read more", "please click here", "continue reading", "learn more", "more details"],
        ht = {
            automaticcoupons: /automaticcoupons/,
            "shopping.yahoo": /shopping\.yahoo/,
            shopperapproved: /shopperapproved/,
            rakuten: /rakuten/,
            "translate.google": /translate\.google/,
            "maps.googleapis.com": /maps\.googleapis\.com/,
            "s.w.org": /s\.w\.org/,
            avatar: /avatar/,
            companylogos: /companylogos/,
            favicon: /favicon/,
            activecampaign: /lt\.php(.*)?l=open/,
            aweber: /openrate\.aweber\.com/,
            bananatag: /bl-1\.com/,
            boomerang: /mailstat\.us\/tr/,
            "campaign monitor": /cmail(\d+)\.com\/t\//,
            "cirrus insight": /tracking\.cirrusinsight\.com/,
            close: /close\.com\/email_opened/,
            "constant contact": /rs6\.net\/on\.jsp/,
            contactmonkey: /contactmonkey\.com\/api\/v1\/tracker/,
            convertkit: /convertkit-mail\.com\/o/,
            "critical impact": /portal\.criticalimpact\.com\/c2\//,
            emarsys: /emarsys\.com\/e2t\/o/,
            gem: /zen\.sr\/o/,
            getnotify: /email81\.com\/case/,
            getresponse: /getresponse\.com\/open\.html/,
            growthdot: /growthdot\.com\/api\/mail-tracking/,
            front: /app\.frontapp\.com\/(.*)?\/seen/,
            hubspot: /t\.(hubspotemail|hubspotfree|signaux|senal|sidekickopen|sigopn)/,
            icontact: /click\.icptrack\.com\/icp/,
            intercom: /(via\.intercom\.io\/o)|(intercom-mail\.com\/via\/o)/,
            litmus: /emltrk\.com/,
            mailchimp: /list-manage\.com\/track/,
            mailgun: /email\.(mailgun|mg)(.*)?\/o/,
            mailjet: /mjt\.lu\/oo/,
            mailspring: /getmailspring\.com\/open/,
            mailtrack: /(mailtrack\.io\/trace)|(mltrk\.io\/pixel)/,
            mandrill: /mandrillapp\.com\/track/,
            marketo: /resources\.marketo\.com\/trk/,
            mixmax: /(email|track)\.mixmax\.com/,
            mixpanel: /api\.mixpanel\.com\/track/,
            nethunt: /nethunt\.co(.*)?\/pixel\.gif/,
            newton: /tr\.cloudmagic\.com/,
            outreach: /api\/mailings\/opened/,
            phplist: /phplist\.com\/lists\/ut\.php/,
            polymail: /polymail\.io/,
            postmark: /pstmrk\.it\/open/,
            "return path": /returnpath\.net\/pixel\.gif/,
            sailthru: /sailthru\.com\/trk/,
            salesforce: /nova\.collect\.igodigital\.com/,
            sendgrid: /wf\/open\?upn/,
            sendy: /sendy\/t\//,
            streak: /mailfoogae\.appspot\.com/,
            superhuman: /r\.superhuman\.com/,
            thunderhead: /na5\.thunderhead\.com/,
            tinyletter: /tinyletterapp\.com.*open\.gif/,
            yamm: /yamm-track\.appspot/,
            yesware: /t\.yesware\.com/,
            "zendesk sell": /futuresimple\.com\/api\/v1\/sprite\.png/,
            bing: /bat\.bing\.com/,
            teads: /cm\.teads\.tv/
        },
        bt = ["icon", "cart", "logo"],
        At = ["h1", "h2", "h3", "h4", "h5", "h6", "span", "a", "p", "figcaption", "caption", "div"],
        yt = ["heading"],
        Et = new RegExp("^(data:)"),
        vt = new RegExp(/\.svg(\?.*)?$/, "i"),
        _t = new RegExp(/^[!@#$%^&*()_+{}[\]`:;<>,.?~\\|\-="'/]+$/, "u");
    var wt = (e => (e.EXCLUDED_SRC = "EXCLUDED_SRC", e.HIDDEN_FROM_SCREEN_READER = "HIDDEN_FROM_SCREEN_READER", e.BASE64 = "BASE64", e.SVG = "SVG", e.SMALL_SIZE = "SMALL_SIZE", e.MICRO_SIZE = "MICRO_SIZE", e.WRONG_SRC = "WRONG_SRC", e.ASPECT_RATIO = "ASPECT_RATIO", e.CUSTOM_CONFIG = "CUSTOM_CONFIG", e.NOT_LOADED = "NOT_LOADED", e))(wt || {});
    const Tt = ["SVG", "SMALL_SIZE", "HIDDEN_FROM_SCREEN_READER"],
        Nt = "data-uw-rm-alt-original",
        xt = "REMEDIATION_IMAGE_MISSING_ALT",
        It = "data-uw-rm-alt",
        Lt = ["jpg", "jpeg", "png", "gif", "bmp", "tiff", "tif", "svg", "webp", "ico", "apng", "heif", "heic", "avif", "eps", "raw", "cr2", "nef", "orf", "sr2"];
    var St = (e => (e.CorrectAlt = "ALT", e.Reverted = "RT", e.Backend = "BE", e.Excluded = "EX", e.Hidden = "HD", e.Base64 = "BS64", e.Svg = "SVG", e.Small = "SM", e.Micro = "MC", e.InvalidSrc = "SRC", e.AspectRatio = "AR", e.AI = "AI", e.AIQuotaExceed = "QU", e.ClosestText = "CT", e.CustomConfig = "CC", e.NotLoaded = "NL", e))(St || {});
    const Ct = "data-uw-rm-heading",
        Ot = "uwAccessibilityEditor",
        Rt = F.editorBuildUrl,
        kt = "aria-editor",
        Dt = "data-uw-rm-ae",
        Mt = "aria-editor",
        Pt = "REMEDIATION_EMPTY_CONTROLS",
        Ut = "data-uw-rm-empty-ctrl",
        Wt = ["facebook", "youtube", "whatsapp", "instagram", "twitter", "reddit", "linkedin", "viber", "pinterest", "telegram", "search", "cart", "home"],
        Bt = {
            prev: "Get previous item",
            next: "Get next item",
            scroll: "Activate for scroll",
            top: "Move to top",
            bottom: "Move to bottom",
            expand: "Expand this block",
            collapse: "Collapse this block",
            close: "Close this option"
        },
        $t = [{
            re: /(fa-)(.+)/,
            replacer: "$2"
        }],
        Ht = "REMEDIATION_FORM_LABEL",
        jt = "data-uw-rm-form",
        Vt = ["INPUT", "TEXTAREA", "SELECT"],
        Ft = "data-uw-hidden-control",
        Xt = "hidden-control-element",
        qt = {
            text: "Text field",
            radio: "Radio button",
            checkbox: "Checkbox field",
            email: "Please enter email address",
            url: "Please enter url",
            tel: "Please enter a phone number",
            password: "Password field",
            search: "Search field",
            date: "Date field",
            time: "Time field",
            image: "Image field",
            file: "File field",
            number: "Number",
            range: "Select range",
            submit: "Submit button",
            color: "Select color",
            datetime_local: "Date and time field",
            month: "Month field",
            week: "Week field",
            button: "Button",
            reset: "Reset button"
        },
        Gt = new Map([
            ["Name", /(name)/],
            ["Age", /(age)/],
            ["Search", /(search|srch)/],
            ["Quantity", /(qua|qty|quantity)/],
            ["Count", /(count|cnt)/]
        ]),
        zt = new Map([
            ["Search", /(search|srch)/],
            ["Select name", /(name)/]
        ]),
        Kt = "REMEDIATION_BROKEN_LINK",
        Zt = "data-uw-rm-brl",
        Yt = "data-uw-original-href";
    var Qt = (e => (e.Processed = "PR", e.BackEndContributed = "BE", e.Fixed = "FX", e.FixedByCorrection = "CR", e))(Qt || {});
    const Jt = ["localhost", "userway.dev", "linkedin.com", "youtube.com"],
        er = "REMEDIATION_META_VIEWPORT",
        tr = "uw-rm-meta-viewport",
        rr = 'meta[name="viewport"][content*="maximum-scale"], meta[name="viewport"][content*="user-scalable=0"], meta[name="viewport"][content*="user-scalable=no"]',
        nr = "REMEDIATION_HEADING",
        ir = "data-uw-rm-heading",
        or = "Empty heading",
        ar = "REMEDIATION_PDF_DOCUMENTS",
        lr = "data-uw-pdf-doc",
        sr = "data-uw-pdf-doc-original",
        ur = "data-uw-pdf-br";
    var cr = (e => (e.INVALID_LINK = "0", e.VALID_LINK = "1", e.IN_PROCESSING_OR_QUOTA_EXCEEDED = "2", e))(cr || {});
    const dr = "data-uw-rm-title",
        pr = "REMEDIATION_HEADER_TITLE",
        mr = "un",
        gr = "gn",
        fr = e => e.filter((e => {
            var t, r;
            const n = (e => {
                switch (e) {
                    case xt:
                        return "alt";
                    case kt:
                        return "ariaEditor";
                    case Pt:
                        return "emptyControls";
                    case Ht:
                        return "forms";
                    case Kt:
                        return "brokenLinks";
                    case er:
                        return "metaViewport";
                    case st:
                        return "externalLinks";
                    case ct:
                        return "skipLinks";
                    case mt:
                        return "vagueLinks";
                    case nr:
                        return "headings";
                    case ar:
                        return "pdf";
                    case pr:
                        return "title";
                    default:
                        return null
                }
            })(e.ruleId);
            if (!n || !F.paidAi) return !0;
            const i = j[n];
            if (!i) return !0;
            const o = !1 !== (null == (r = null == (t = i.config) ? void 0 : t.mobile) ? void 0 : r.enabled);
            return i.enabled && (!G || o)
        })),
        hr = (e, t) => {
            if (0 === e.length) return Promise.resolve();
            const r = e[0];
            return Promise.all(r.map((e => e(t)))).then((() => hr(e.slice(1), t)))
        },
        br = "REMEDIATION_PER_SITE",
        Ar = () => {
            var e, t;
            try {
                const r = UserWayWidgetApp.getLib("util");
                (null == (e = null == j ? void 0 : j.perSiteRemediation) ? void 0 : e.enabled) && (null == (t = null == j ? void 0 : j.perSiteRemediation) ? void 0 : t.resources) && r.execJs(j.perSiteRemediation.resources).finally((() => {
                    r.fireUserWayLifeCycleEvent("userway:remediation_csr_loaded")
                }))
            } catch (r) {
                console.info("CSR", r)
            }
        };
    Ar.id = br;
    const yr = [Ar],
        Er = e => e.filter((e => {
            var t, r;
            const n = e.id === br ? "perSiteRemediation" : null;
            if (!n || !F.paidAi) return !1;
            const i = j[n];
            if (!i) return !0;
            const o = !1 !== (null == (r = null == (t = i.config) ? void 0 : t.mobile) ? void 0 : r.enabled);
            return i.enabled && (!G || o)
        })),
        vr = Object.freeze({
            isInitialRun: !1
        }),
        _r = (() => {
            let e, t, r = !1,
                n = [],
                i = null;
            const o = (a, l = vr) => {
                    const {
                        isInitialRun: s
                    } = l;
                    if (!a.length) return;
                    if (r) return i && clearTimeout(i), void(i = setTimeout((() => {
                        o(n), i = null
                    }), 800));
                    r = !0;
                    const u = () => {
                        r = !1
                    };
                    ((e, t) => {
                        const r = e.map((e => e.map((e => e.run))));
                        return hr(r, t)
                    })(s ? [...e, ...t] : e, a).then(u).catch(u).finally((() => {
                        if (s) {
                            Er(yr).forEach((e => {
                                e.id === br ? "v2" === V.csrVersion && e() : e()
                            }))
                        }
                    })), n = []
                },
                {
                    run: a
                } = Ve(o),
                l = e => {
                    n.push(...e), a(n)
                },
                s = () => {
                    const e = (() => {
                        const e = C.join(","),
                            t = R.map((e => `[${e}]`)).join(","),
                            r = `${e},${t}`;
                        return [...document.body.querySelectorAll(`*:not(${r})`), document.documentElement].filter((e => !e.closest(t))).map((e => e))
                    })();
                    a([...e], {
                        isInitialRun: !0
                    }), ne((e => {
                        if (!e.data) return;
                        const {
                            data: {
                                action: t,
                                type: r
                            }
                        } = e;
                        t === Ge && lt[r] && lt[r]()
                    })), le(l)
                };
            return {
                run: a,
                init: () => __async(this, null, (function*() {
                    if ((() => {
                            var e;
                            if ((null == (e = window.location) ? void 0 : e.pathname.indexOf("wp-admin")) > -1) return !0;
                            if (!(null == j ? void 0 : j.commonSettings)) return !1;
                            const {
                                mobile: t,
                                disabledPages: r
                            } = j.commonSettings.config;
                            return !(!G || !t || t.enabled) || !!(null == r ? void 0 : r.some((e => {
                                var t;
                                return (null == (t = window.location) ? void 0 : t.href.indexOf(e)) > -1
                            })))
                        })()) return;
                    let r;
                    r = yield Promise.resolve().then((() => Pa)), e = r.RulesGroups.map((e => fr(e))), t = r.RulesGroupsOnce.map((e => fr(e))), V.tech_rem_on_tab || s();
                    const n = ne((e => {
                        var t;
                        (null == (t = null == e ? void 0 : e.data) ? void 0 : t.type) === re.KeyboardNavEnabled && (s(), n())
                    }))
                })),
                onDomUpdates: l
            }
        })();
    (() => {
        __async(this, null, (function*() {
            var e;
            yield Q();
            const t = null != (e = V.tech_rem_in_throttle_ms) ? e : 500;
            setTimeout((() => {
                _r.init(), ((e = ie, t = oe) => {
                    V.tech_rem_on_tab || se.observe(e, t);
                    const r = ne((n => {
                        var i;
                        (null == (i = null == n ? void 0 : n.data) ? void 0 : i.type) === re.KeyboardNavEnabled && (se.observe(e, t), r())
                    }))
                })()
            }), t)
        }))
    })(), he.observe(ge, fe), (() => {
        const e = ce.find((e => e.url.includes(window.location.origin)));
        e && me(e.name)
    })();
    const wr = ({
            ruleId: e,
            isTargetElement: t,
            rule: r,
            postMessageApi: n,
            forceRun: i
        }) => (n && ne((e => {
            const t = null == e ? void 0 : e.data;
            if (!t) return;
            const {
                type: r,
                action: i
            } = t;
            i !== te.Remediation && i !== te.AriaEditor || n[r] && n[r](t.data ? t.data : t)
        })), {
            run: n => __async(this, null, (function*() {
                try {
                    if (!t) return void(yield r({
                        context: {
                            elements: n
                        }
                    }));
                    const o = n.filter((r => !r.hasAttribute(`uw-ignore-${e}`) && t(r)));
                    if (!o.length) return void(i && (yield r({
                        context: {
                            elements: []
                        }
                    })));
                    yield r({
                        context: {
                            elements: o
                        }
                    })
                } catch (o) {
                    console.warn(o)
                }
            })),
            stop: () => {},
            rerun: () => {},
            ruleId: e
        }),
        Tr = e => {
            if (!e) return null;
            const t = e.split("|")[0];
            return document.evaluate(t, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue
        },
        Nr = e => !!["input", "select", "button", "textarea", "a"].includes(e.tagName.toLowerCase()) || ["button", "checkbox", "link", "option"].includes((e.getAttribute("role") || "").toLowerCase()),
        xr = e => {
            const t = e.getAttribute("tabindex");
            if (null !== t) {
                const e = parseInt(t, 10);
                if (!Number.isNaN(e)) return e
            }
        },
        Ir = e => {
            if (Nr(e)) return !0;
            const t = xr(e);
            return void 0 !== t && !Number.isNaN(t) && t >= 0
        },
        Lr = e => !!C.includes(e.toLowerCase()),
        Sr = (e, t) => ("img" === e ? t.getAttribute("alt") : t.getAttribute("aria-label")) || null,
        Cr = e => e.getAttribute("role") || null,
        Or = e => e.getAttribute("aria-level") || null,
        Rr = (e, t) => "img" === e ? t.getAttribute("src") : null,
        kr = e => {
            if (null == e ? void 0 : e.nextElementSibling) {
                const t = e.nextElementSibling;
                return Lr(t.tagName) ? kr(t) : t
            }
            return null
        },
        Dr = e => {
            if (null == e ? void 0 : e.previousElementSibling) {
                const t = e.previousElementSibling;
                return Lr(t.tagName) ? Dr(t) : t
            }
            return null
        },
        Mr = e => {
            var t;
            return null != (t = e.uwAtoId) ? t : null
        },
        Pr = e => {
            if (!e.parentElement) return null;
            const {
                parentElement: t
            } = e, r = f(t);
            return ot().find((e => e.xpath === r)) ? r : Pr(t)
        },
        Ur = e => {
            const t = Array.from(e.childNodes).find((e => e.uwAtoId));
            if (t) {
                const e = f(t);
                return ot().find((t => t.xpath === e)) ? e : null
            }
            return null
        },
        Wr = (e, t) => {
            if (!e) return;
            const r = e,
                {
                    tabindex: n,
                    el: i
                } = r,
                o = __objRest(r, ["tabindex", "el"]),
                a = e.el ? [...e.el.children] : [],
                l = t.filter((e => a.includes(e.el)));
            if (l.length) {
                const e = l.map((e => Wr(e, t)));
                return __spreadProps(__spreadValues({}, o), {
                    children: e
                })
            }
            return o
        },
        Br = (t, r = "") => {
            const n = [t];
            t.parentElement && n.push(t.parentElement);
            let i = 0;
            const o = (null == t ? void 0 : t.children) ? [...t.children].filter((e => !Lr(e.tagName))).reverse() : [];
            o.length && (n.unshift(...o), i += o.length);
            const a = kr(t);
            a && !n.includes(a) && (n.splice(i, 0, a), i += 1);
            const l = Dr(t);
            l && !n.includes(l) && n.splice(i + 1, 0, l);
            const s = n.map((e => {
                const r = e.tagName.toLowerCase(),
                    n = tt(e, !0);
                if (!n) return null;
                const {
                    type: i,
                    label: o,
                    id: a
                } = n, l = "function" == typeof e.getAttribute ? {
                    label: Sr(r, e),
                    isHidden: (s = e, "true" === s.getAttribute("aria-hidden") || "presentation" === s.getAttribute("role")),
                    role: Cr(e),
                    ariaLevel: Or(e),
                    src: Rr(r, e),
                    isControl: Nr(e),
                    focusable: Ir(e),
                    tabindex: xr(e)
                } : {};
                var s;
                return __spreadValues({
                    tagName: r,
                    text: [...e.childNodes].filter((e => e.nodeType === Node.TEXT_NODE)).map((e => {
                        var t;
                        return null == (t = e.textContent) ? void 0 : t.trim()
                    })).join(" ").trim(),
                    id: a,
                    xpath: f(e),
                    selected: e === t,
                    el: e,
                    semanticType: i,
                    textToRead: o,
                    uwAtoId: Mr(e),
                    accessibleParentXpath: Pr(e),
                    accessibleChildXpath: Ur(e)
                }, l)
            })).filter(Boolean).reverse();
            if (s) {
                const t = Wr(s[0], s);
                t && e({
                    action: Mt,
                    type: "elements-selected",
                    data: {
                        tree: t,
                        source: r
                    }
                }, [Ot])
            }
        };
    let $r, Hr;
    let jr;
    const Vr = (e, t) => {
            const r = "img" === (null == e ? void 0 : e.tagName.toLowerCase());
            t && !r && e.setAttribute("aria-label", t)
        },
        Fr = (e, t) => {
            const {
                tabindex: r,
                role: n,
                ariaLevel: i
            } = t;
            r && e.setAttribute("tabindex", r), n && "no role" !== n ? e.setAttribute("role", n) : n && "no role" !== n || e.removeAttribute("role"), i && e.setAttribute("aria-level", i)
        },
        Xr = wr({
            ruleId: kt,
            rule: () => {
                if (j.ariaEditor.enabled && (jr = (() => {
                        let e = Y().AriaEditorValues;
                        const t = `${g(window.location.pathname)}`;
                        return e = e.filter((e => !e.page || e.page === t)), e
                    })(), jr))
                    for (const e of jr) {
                        const t = Tr(e.xpath);
                        if (!t) continue;
                        const r = t.nodeType === Node.ELEMENT_NODE,
                            n = t.hasAttribute(Dt) && e.processed;
                        if (!r || n) continue;
                        const {
                            hidden: i,
                            correction: o
                        } = e;
                        i && t.setAttribute("aria-hidden", "true"), Vr(t, o), Fr(t, e), t.setAttribute(Dt, ""), e.processed = !0
                    }
            },
            postMessageApi: {
                "add-aria-editor": () => {
                    Hr = document.querySelector(`iframe[name=${Ot}]`), Hr || ($r = new Promise((e => {
                        const t = {
                            class: "userway_iframe_aria_editor",
                            name: "uwAccessibilityEditor",
                            title: "Aria Editor",
                            src: Rt
                        };
                        Hr = document.createElement("iframe"), Object.entries(t).forEach((([e, t]) => {
                            null == Hr || Hr.setAttribute(e, t)
                        })), Hr.style = "\n            z-index: 2147483647;\n            position: fixed;\n            left: 0;\n            top: 0;\n            width: 100%!important;\n            max-width: 100%!important;\n            height: 100%!important;\n            max-height: 100%!important;\n            visibility: hidden;\n            opacity: 0!important;\n            border: none;\n            display: block;\n          ", Hr.onload = () => {
                            e()
                        }, Hr && document.body.appendChild(Hr)
                    })))
                },
                "open-aria-editor": () => {
                    $r.then((() => {
                        window.parent.postMessage({
                            action: "close",
                            isUserWay: !0
                        }), window.parent.postMessage({
                            action: "manageIconVisibility",
                            isUserWay: !0,
                            type: "hidden"
                        }), Hr && (Hr.style.visibility = "visible", Hr.style.opacity = "1"), e({
                            action: Mt,
                            type: "aria-editor-open-request"
                        }, [Ot])
                    }))
                },
                "close-aria-editor": () => {
                    window.parent.postMessage({
                        action: "open",
                        isUserWay: !0
                    }), window.parent.postMessage({
                        action: "manageIconVisibility",
                        isUserWay: !0,
                        type: "visible"
                    }), Hr && (Hr.style.visibility = "hidden", Hr.style.opacity = "0"), e({
                        action: Mt,
                        type: "aria-editor-closed"
                    }, [Ot])
                },
                "editor-init": () => {
                    const t = F,
                        r = !(!t || !t.CUSTOM_BRANDING && !t.WHITE_LABEL);
                    e({
                        action: Mt,
                        type: "open-aria-editor",
                        data: {
                            siteId: F.siteId,
                            showTutorial: !0,
                            whiteLabel: r,
                            hash: g(window.location.pathname)
                        }
                    }, [Ot])
                },
                "update-aria-hidden": e => {
                    const {
                        xpath: t,
                        hidden: r
                    } = e;
                    if (!t) return;
                    const n = L(t);
                    (null == n ? void 0 : n.nodeType) === Node.ELEMENT_NODE && (r ? n.setAttribute("aria-hidden", "true") : n.removeAttribute("aria-hidden"), n.setAttribute(Dt, ""))
                },
                "update-tabindex": e => {
                    const {
                        xpath: t,
                        focusable: r,
                        isControl: n
                    } = e;
                    if (!t) return;
                    const i = L(t);
                    (null == i ? void 0 : i.nodeType) === Node.ELEMENT_NODE && (n ? i[r ? "removeAttribute" : "setAttribute"]("tabindex", "-1") : i[r ? "setAttribute" : "removeAttribute"]("tabindex", "0"), i.setAttribute(Dt, ""))
                },
                "update-aria-label": e => {
                    const {
                        xpath: t,
                        label: r
                    } = e;
                    if (!t || null == r) return;
                    const n = L(t);
                    (null == n ? void 0 : n.nodeType) === Node.ELEMENT_NODE && (n.setAttribute("aria-label", e.label), n.setAttribute(Dt, ""))
                },
                "update-aria-level": e => {
                    const {
                        xpath: t,
                        ariaLevel: r
                    } = e;
                    if (!t) return;
                    const n = L(t);
                    (null == n ? void 0 : n.nodeType) === Node.ELEMENT_NODE && (r ? n.setAttribute("aria-level", r) : n.removeAttribute("aria-level"), n.setAttribute(Dt, ""))
                },
                "update-role": e => {
                    const {
                        xpath: t,
                        role: r
                    } = e;
                    if (!t) return;
                    const n = L(t);
                    if ((null == n ? void 0 : n.nodeType) === Node.ELEMENT_NODE) {
                        r && "no role" !== r ? n.setAttribute("role", r) : n.removeAttribute("role"), n.setAttribute(Dt, "")
                    }
                },
                "select-elements-by-xpath": e => {
                    const {
                        xpath: t,
                        source: r
                    } = e;
                    if (!t) return;
                    const n = L(t);
                    n && Br(n, r)
                },
                "select-elements-at-point": e => {
                    const {
                        position: {
                            x: t,
                            y: r
                        }
                    } = e;
                    let n = document.elementsFromPoint(t, r);
                    const i = n.findIndex((e => e.getAttribute("name") === Ot)); - 1 !== i && n.splice(i, 1), n = n.filter((e => !["HTML", "BODY"].includes(e.tagName))).slice(0, 2), n.length && Br(n[0])
                },
                "update-aria-editor-config": e => {
                    const {
                        page: t = "",
                        xpath: r = ""
                    } = e, n = Y().AriaEditorValues.findIndex((e => e.page === t && e.xpath === r)), i = Y().AriaEditorValues[n], o = __spreadValues(__spreadValues({}, i), (e => __spreadProps(__spreadValues({}, e), {
                        hidden: e.isHidden
                    }))(e)); - 1 !== n ? Y().AriaEditorValues[n] = o : Y().AriaEditorValues.push(o)
                }
            }
        }),
        qr = ({
            currentSrc: e,
            src: t
        }) => e || t,
        Gr = (e, t) => {
            try {
                const r = e.getAttribute("height"),
                    n = e.getAttribute("width"),
                    {
                        width: i,
                        height: o
                    } = window.getComputedStyle(e);
                return parseInt(n || i, 10) > t && parseInt(r || o, 10) > t
            } catch (r) {
                return !1
            }
        },
        zr = (e, {
            decorative: t,
            approved: r,
            fixedByUserWay: n,
            loadingFromMS: i
        }) => {
            var o;
            return {
                src: qr(e),
                alt: e.alt,
                originalAlt: null != (o = e.getAttribute(Nt)) ? o : "",
                decorative: t,
                approved: r,
                fixedByUserWay: n,
                loadingFromMS: i
            }
        },
        Kr = e => {
            e.setAttribute("role", "presentation"), e.removeAttribute("aria-hidden"), e.setAttribute("alt", "")
        },
        Zr = e => {
            if (!e) return "";
            try {
                const {
                    hostname: t
                } = new URL(e);
                return t.replace(/^https?:\/\//, "").replace(/^www\./, "").replace(/\.[a-zA-Z0-9]*$/, "")
            } catch (t) {
                return ""
            }
        },
        Yr = e => {
            const t = qr(e);
            return Et.test(t)
        },
        Qr = e => {
            const t = e.trim();
            if (new RegExp(`\\.(${Lt.join("|")})$`, "i").test(t)) return !0;
            if (t.length > 500) return !0;
            if (!t) return !0;
            const r = t.split(/\s+/).length;
            if (/[0-9]{5,}/.test(t) && 1 === r) return !0;
            return !!_t.test(t)
        },
        {
            enabled: Jr,
            config: en
        } = (null == j ? void 0 : j.alt) || {
            enabled: !1,
            config: {}
        },
        tn = null == en ? void 0 : en.decorative,
        rn = (e, t = "selectors") => {
            if (!tn || !Jr) return !1;
            const r = tn[t];
            return !!Array.isArray(r) && r.some((t => e.matches(t)))
        },
        nn = (e, t) => {
            const r = t.alt.trim(),
                n = qr(t),
                i = e.find((e => y(e.src).toLowerCase() === y(n).toLowerCase()));
            if (!i || null === i.alt) return null;
            const {
                decorative: o,
                alt: a,
                approved: l,
                reverted: s
            } = i;
            if (s && !o) return t.setAttribute(It, St.Reverted), zr(t, {
                approved: !0,
                decorative: !r,
                fixedByUserWay: !1,
                loadingFromMS: !1
            });
            const u = !(!j || "AUTO" === j.strategy) && !l;
            !o || u || rn(t, "ignoreSelectors") || Kr(t);
            const c = l || !r || Qr(r);
            a && !u && c && !o && t.setAttribute("alt", a), t.setAttribute(It, St.Backend);
            const d = zr(t, {
                approved: l,
                decorative: o,
                fixedByUserWay: !0,
                loadingFromMS: !1
            });
            return u && (d.alt = a), d
        },
        on = e => {
            if ("string" != typeof e) return !1;
            for (const t of Object.values(ht)) {
                const r = new RegExp(t, "i");
                if (e.match(r)) return !0
            }
            return !1
        },
        an = e => {
            const t = e.getAttribute("width"),
                r = e.getAttribute("height");
            if (t && parseFloat(t) > 0 && r && parseFloat(r) > 0) return !0;
            const {
                width: n,
                height: i
            } = window.getComputedStyle(e);
            try {
                if (0 === parseFloat(n) && 0 === parseFloat(i)) return !1
            } catch (s) {
                return !1
            }
            const o = /^\d*px?/i,
                a = o.test(n),
                l = o.test(i);
            return !(!a || !l)
        },
        ln = e => {
            if (rn(e)) return wt.CUSTOM_CONFIG;
            const t = qr(e),
                r = Qr(e.alt),
                n = an(e);
            var i;
            if (!(i = t) || !i.match(Et) && ![/^https?:\/\/.{1,256}\.[a-z]{2,63}\/.+$/gim, /^https?:\/\/[^:\/\s]{1,256}:\d{1,5}\/.+$/gim].some((e => e.test(i)))) return wt.WRONG_SRC;
            if (on(t)) return wt.EXCLUDED_SRC;
            if (!!n && !Gr(e, 10) && r) return wt.MICRO_SIZE;
            if (!!n && (e => {
                    try {
                        const {
                            width: t,
                            height: r
                        } = window.getComputedStyle(e), n = parseInt(t, 10), i = parseInt(r, 10);
                        return !!(n <= 20 && i >= 10 * n || i <= 20 && n >= 10 * i)
                    } catch (t) {
                        return !1
                    }
                })(e)) return wt.ASPECT_RATIO;
            if (Yr(e) && r) return wt.BASE64;
            if ("true" === e.getAttribute("aria-hidden") || "presentation" === e.getAttribute("role") || "none" === e.getAttribute("role")) return wt.HIDDEN_FROM_SCREEN_READER;
            if (vt.test(t) && r) return wt.SVG;
            return !(!n || Gr(e, 50)) && r ? wt.SMALL_SIZE : null
        },
        sn = e => {
            switch (e) {
                case wt.ASPECT_RATIO:
                    return St.AspectRatio;
                case wt.BASE64:
                    return St.Base64;
                case wt.EXCLUDED_SRC:
                    return St.Excluded;
                case wt.SVG:
                    return St.Svg;
                case wt.MICRO_SIZE:
                    return St.Micro;
                case wt.SMALL_SIZE:
                    return St.Small;
                case wt.WRONG_SRC:
                    return St.InvalidSrc;
                case wt.CUSTOM_CONFIG:
                    return St.CustomConfig;
                case wt.NOT_LOADED:
                    return St.NotLoaded;
                case wt.HIDDEN_FROM_SCREEN_READER:
                default:
                    return St.Hidden
            }
        },
        un = (e, t, r, n, i) => {
            const o = UserWayWidgetApp.getLib("remediation_manager"),
                a = UserWayWidgetApp.getLib("remediation_helper_outcome");
            if (!a.of) return;
            const l = a.of(e, t ? {
                items: t
            } : null, null != i ? i : null, r, n);
            o.HelperCallbackAggregator.onHelperRemediationCompleted(l)
        },
        cn = new Map,
        dn = (e, t) => {
            const r = f(e);
            cn.set(r, t)
        },
        pn = e => {
            const t = f(e);
            return cn.get(t) || null
        },
        mn = e => un(xt, e, e.filter((e => e.fixedByUserWay)).length, e.filter((e => !e.approved)).length),
        gn = e => {
            e.hasAttribute(Nt) || e.setAttribute(Nt, e.alt)
        },
        fn = (e, t = []) => {
            if (0 === e.length) return;
            const {
                paidAi: r
            } = F, n = [];
            for (const i of e) {
                const e = i,
                    o = Qr(e.alt),
                    a = qr(e),
                    l = pn(e),
                    s = rn(e, "ignoreSelectors");
                gn(e), vt.test(a) && r && e.setAttribute("role", "img");
                const u = nn(t, e);
                if (u) {
                    n.push(u);
                    continue
                }
                if (s) {
                    e.setAttribute(It, sn(wt.CUSTOM_CONFIG));
                    continue
                }
                if (!r) continue;
                const c = null == l ? void 0 : l.shouldBeDecorativeReason;
                if (!o && !c) {
                    e.setAttribute(It, St.CorrectAlt), n.push(zr(e, {
                        approved: !0,
                        decorative: !1,
                        fixedByUserWay: !1
                    }));
                    continue
                }
                if (void 0 !== c) {
                    Kr(e), e.setAttribute(It, sn(c)), c && Tt.includes(c) && n.push(zr(e, {
                        approved: !1,
                        decorative: !0,
                        fixedByUserWay: !0
                    }));
                    continue
                }
                const d = null == l ? void 0 : l.relevantText;
                if (d) {
                    e.setAttribute("alt", d), e.setAttribute(It, St.ClosestText), n.push(zr(e, {
                        approved: !1,
                        decorative: !1,
                        fixedByUserWay: !0
                    }));
                    continue
                }
                const {
                    quota: p,
                    usage: m
                } = X;
                m >= p ? (e.setAttribute(It, St.AIQuotaExceed), n.push(zr(e, {
                    approved: !1,
                    decorative: !1,
                    fixedByUserWay: !0
                }))) : (e.setAttribute(It, St.AI), n.push(zr(e, {
                    approved: !1,
                    decorative: !1,
                    fixedByUserWay: !0,
                    loadingFromMS: !0
                })))
            }
            mn(n)
        },
        hn = e => {
            const t = e.replace(/^https?:\/\//, "");
            return document.querySelectorAll(`img[src*="${t}" i],img[srcset*="${t}" i]`)
        },
        bn = e => __async(this, null, (function*() {
            const {
                account: t
            } = UserWayWidgetApp.ContextHolder.config, {
                siteId: r
            } = F, {
                resourceHash: n
            } = X, i = encodeURIComponent(e), o = yield fetch(`${ee}api/img-dscr/v2/${t}/${r}/${n}/alts.json?dto=${i}`, {
                method: "GET",
                headers: {
                    "Content-Type": "application/json"
                }
            });
            return (yield o.json()).payload
        })),
        An = e => {
            const t = `(.*\\.(${Lt.join("|")}))\\?.*$`,
                r = new RegExp(t),
                n = e.match(r);
            if (!n) {
                const t = new URL(e),
                    r = [];
                let n = !1;
                return t.searchParams.forEach(((e, t) => {
                    Lt.some((t => e.endsWith(t))) ? n = !0 : r.push(t)
                })), n && r.forEach((e => t.searchParams.delete(e))), n ? t.toString() : e
            }
            return n && n[1] ? n[1] : e
        };
    var yn = (e => (e.RO = "RO", e))(yn || {});
    const En = (e, t) => e.src.localeCompare(t.src),
        vn = (e, t = 1) => {
            if (t >= 15) return console.warn("Max split level exceed"), [];
            const r = ((e, t) => {
                    const r = Math.ceil(e.length / t),
                        n = [];
                    for (let i = 0; i < e.length; i += r) n.push(e.slice(i, i + r));
                    return n
                })(e, t),
                n = [];
            for (const i of r) {
                const r = {
                        sorted: i,
                        tier: X.tier,
                        pageUrl: window.location.href
                    },
                    o = JSON.stringify(r);
                if (encodeURIComponent(o).length / 1024 > 8) return vn(e, t + 1);
                n.push(o)
            }
            return n
        },
        _n = e => e ? e.replace(/\n/g, "").replace(/ {2,}/g, " ").trim() : "",
        wn = (e, t) => {
            if (!e) return null;
            const r = "next" === t.type ? e.nextSibling : e.previousSibling;
            if ((null == r ? void 0 : r.nodeType) === Node.TEXT_NODE) {
                if (!_n(r.nodeValue)) return wn(r, {
                    type: t.type
                })
            }
            return r
        },
        Tn = e => {
            const t = e.nodeType === Node.ELEMENT_NODE,
                r = e instanceof Element && "hide" === e.getAttribute(Ct);
            if (e.nodeType === Node.TEXT_NODE) return !0;
            if (t && !r) {
                const t = At.some((t => t === e.nodeName.toLowerCase())),
                    r = yt.some((t => {
                        var r;
                        return t === (null == (r = e.getAttribute("role")) ? void 0 : r.toLowerCase())
                    }));
                return t || r
            }
            return !1
        },
        Nn = Array.from(new Set([...At, "a", "span", "strong", "em", "b", "i", "q", "mark"])),
        xn = e => {
            if ((null == e ? void 0 : e.nodeType) === Node.TEXT_NODE) {
                const t = _n(e.nodeValue);
                if (t && !Qr(t)) return t
            }
            if ((null == e ? void 0 : e.nodeType) === Node.ELEMENT_NODE && Nn.includes(e.tagName.toLowerCase()))
                for (const t of e.childNodes) {
                    const e = xn(t);
                    if (e) return e
                }
            return null
        },
        In = e => {
            const t = e.nodeType === Node.ELEMENT_NODE,
                r = e.nodeType === Node.TEXT_NODE;
            if (!r && !t) return !1;
            if (t && "img" === e.nodeName.toLowerCase()) return !0;
            if (r) return !!_n(e.textContent);
            const n = At.some((t => t === e.nodeName.toLowerCase())),
                i = yt.some((t => {
                    var r;
                    return t === (null == (r = e.getAttribute("role")) ? void 0 : r.toLowerCase())
                }));
            return n || i
        };
    let Ln = 0;
    const Sn = e => {
            const t = e.parentElement;
            if (!t) return null;
            if (t.getElementsByTagName("img").length > 1) return Ln = 0, null;
            if (1 === [].slice.call(t.childNodes).filter(In).length) return Sn(t);
            const r = (e => {
                let t = wn(e, {
                        type: "next"
                    }),
                    r = wn(e, {
                        type: "prev"
                    }),
                    n = null,
                    i = null;
                for (; t || r;) {
                    t && Tn(t) && (n = xn(t)), r && Tn(r) && (i = xn(r));
                    const e = n || i;
                    if (e) return e;
                    t = wn(t, {
                        type: "next"
                    }), r = wn(r, {
                        type: "prev"
                    })
                }
                return null
            })(e);
            return r ? (Ln = 0, r) : (Ln += 1, "body" === t.tagName.toLowerCase() ? (Ln = 0, null) : Ln < 2 ? Sn(t) : (Ln = 0, null))
        },
        Cn = e => {
            const t = e.closest("figure");
            if (t) {
                const e = Array.from(t.children).find((e => "figcaption" === e.tagName.toLowerCase()));
                if (e) {
                    const t = _n(e.textContent);
                    if (t && !Qr(t)) return t
                }
            }
            const r = [].slice.call(e.classList).join(" "),
                n = e.id || "",
                i = (o = r + n).trim() && bt.find((e => o.includes(e))) || null;
            var o;
            if (i) return i;
            const a = Sn(e);
            return a || null
        },
        On = (e, t) => {
            if (!an(e)) return !1;
            const r = qr(e);
            return Zr(r) !== t && !Gr(e, 20)
        },
        Rn = (e, t) => {
            Kr(e), e.setAttribute(It, sn(t))
        },
        kn = ["data-lazy-src", "data-src", "data-lazy"],
        Dn = e => "lazy" === e.loading || (e => kn.some((t => e.hasAttribute(t))))(e),
        Mn = (e, t, r) => {
            e.addEventListener("load", (() => {
                t()
            })), e.addEventListener("error", (() => {
                Rn(e, wt.NOT_LOADED), r()
            }))
        },
        Pn = e => (t, r) => {
            if ((e => e.complete && 0 !== e.naturalHeight)(e)) return void t(e);
            if (Dn(e)) return void Mn(e, (() => t(e)), (() => r(e)));
            const n = new Image;
            Mn(n, (() => t(e)), (() => r(e))), n.src = e.src
        },
        Un = e => {
            const t = (e => {
                const t = e.cloneNode(!0);
                var r;
                return t.setAttribute(It, ""), (r = t) && (r.style.setProperty("display", "block", "important"), r.style.setProperty("opacity", "0", "important"), r.style.setProperty("visibility", "hidden", "important"), r.style.setProperty("position", "absolute", "important"), r.style.setProperty("pointer-events", "none", "important"), r.style.setProperty("z-index", "-999", "important"), r.style.setProperty("bottom", "0", "important")), t
            })(e);
            return new Promise(((r, n) => {
                t.addEventListener("load", (() => {
                    const i = ln(t);
                    i ? (Rn(e, i), n()) : new Promise(Pn(e)).then((e => r(e))).catch((e => n(e))), t.remove()
                })), document.body.appendChild(t)
            }))
        },
        Wn = e => e.reduce(((e, t) => {
            const r = (e => on(e.src) ? (Rn(e, wt.EXCLUDED_SRC), Promise.reject(e)) : e.getAttribute("src") || e.getAttribute("srcset") || Dn(e) ? "none" !== e.style.display || Dn(e) ? new Promise(Pn(e)) : Un(e) : (Rn(e, wt.WRONG_SRC), Promise.reject(e)))(t);
            return r ? [...e, r] : e
        }), []),
        Bn = [],
        $n = (e, t) => {
            if (!X) return;
            const {
                state: r
            } = X;
            if ("ALTS_OFF" === r) return;
            const n = (e => {
                    var t, r;
                    const n = [];
                    for (const i of e) {
                        const e = qr(i),
                            t = Zr(e);
                        if (t) {
                            let e = n.find((e => e.name === t));
                            e || (e = {
                                name: t,
                                weight: 0
                            }, n.push(e)), e.weight += 1
                        }
                    }
                    return null != (r = null == (t = n.sort(((e, t) => e.weight < t.weight ? 1 : -1))[0]) ? void 0 : t.name) ? r : ""
                })(e),
                i = [],
                o = [];
            for (const l of e) {
                const e = l,
                    t = On(e, n),
                    r = ln(e),
                    a = Qr(e.alt),
                    s = r && !Tt.includes(r) || t || Yr(e) || rn(e, "ignoreSelectors"),
                    u = {};
                if (r && (u.shouldBeDecorativeReason = r), s) o.push(e);
                else {
                    if (a) {
                        const t = Cn(e);
                        t && (u.relevantText = t)
                    }
                    i.push(e)
                }
                Object.keys(u).length && dn(e, u)
            }
            try {
                const e = (e => {
                        const t = e,
                            r = t.filter(((e, r) => r === t.findIndex((t => qr(e) === qr(t))))).map((e => {
                                const t = e,
                                    r = t.alt.trim(),
                                    n = r && !Qr(r),
                                    i = qr(t),
                                    o = pn(t);
                                return {
                                    src: An(i),
                                    alt: t.alt.trim(),
                                    dir: n || ln(t) || (null == o ? void 0 : o.relevantText) ? yn.RO : void 0
                                }
                            }));
                        return r.sort(En), r
                    })(i),
                    r = vn(e);
                if (r.length)
                    for (const n of r) bn(n).then((e => {
                        if (!e) return void t();
                        const {
                            missingAlts: r
                        } = e, n = i.filter((e => r.find((t => y(t.src) === y(qr(e))))));
                        fn(n, r), t()
                    })).catch((e => {
                        console.error("Get missing alts error: ", e), t()
                    }));
                fn(o), Bn.length = 0, r.length || t()
            } catch (a) {
                console.error(a)
            }
        },
        Hn = $e(((e, t) => $n(e, t)), 1e3, {
            maxWait: 2e3,
            leading: !1,
            trailing: !0
        }),
        jn = wr({
            ruleId: xt,
            rule: ({
                context: {
                    elements: e
                }
            }) => new Promise((t => {
                const r = Wn(e);
                let n = 0;
                const i = r.map((e => e.then((e => {
                    Bn.push(e), Hn(Bn, t)
                })).catch((e => {
                    Kr(e), e.setAttribute(It, St.InvalidSrc), n++
                }))));
                Promise.all(i).then((() => {
                    r.length === n && t()
                }))
            })),
            isTargetElement: e => {
                const t = "img" === e.tagName.toLowerCase(),
                    r = e.hasAttribute(It);
                return !(!t || r)
            },
            postMessageApi: {
                "image-alt-update": ({
                    src: e,
                    decorative: t,
                    alt: r,
                    role: n
                }) => {
                    const i = hn(e);
                    if (i.length) {
                        for (const e of i) e.setAttribute("alt", null != r ? r : ""), t ? Kr(e) : ("presentation" !== e.getAttribute("role") && "none" !== e.getAttribute("role") || e.removeAttribute("role"), e.hasAttribute("aria-hidden") && e.removeAttribute("aria-hidden")), ["link", "button", "heading"].includes(n) && e.setAttribute("aria-label", r);
                        mn([zr(i[0], {
                            approved: !0,
                            decorative: t,
                            fixedByUserWay: !1
                        })])
                    }
                },
                "image-alt-revert": ({
                    src: e
                }) => {
                    const t = hn(e);
                    for (const r of t) {
                        const e = r.getAttribute(Nt);
                        null !== e && r.setAttribute("alt", e)
                    }
                }
            }
        }),
        Vn = e => {
            const {
                tagName: t
            } = e;
            return "SELECT" === t || "TEXTAREA" === t ? t.toLowerCase() : "text"
        },
        Fn = e => {
            const t = e.getAttribute("id");
            if (!t) return null;
            try {
                return document.querySelector(`label[for='${t}']`)
            } catch (r) {
                return null
            }
        },
        Xn = e => {
            const t = "string" == typeof e ? e : e.textContent;
            return t && t.replace(/\r\n|\r|\n|\t/g, " ").replace(/( )+/g, " ").trim()
        },
        qn = (e, t) => {
            for (const [r, n] of t)
                if (n.test(e)) return r;
            return ""
        },
        Gn = e => {
            let t = "";
            const r = e.getAttribute("placeholder"),
                n = e.getAttribute("title");
            if (r && r.trim()) return r;
            if (n && n.trim()) return n;
            const {
                classList: i,
                name: o,
                tagName: a,
                type: l
            } = e, s = `${[...i].join(" ")||""} ${o||""}`.trim();
            return "text" === l && (t = qn(s, Gt)), "SELECT" === a && (t = qn(s, zt)), t || (e => {
                const {
                    tagName: t,
                    type: r
                } = e;
                return "SELECT" === t ? "select-multiple" === r ? "Multiple select" : "Single select" : "TEXTAREA" === t ? "Text area" : "INPUT" === t && r && qt[r.replace("-", "_")] ? qt[r.replace("-", "_")] : ""
            })(e)
        },
        zn = e => {
            if (e.parentElement) {
                const t = [...e.parentElement.querySelectorAll("label")];
                if (1 === t.length && (e => {
                        const t = "LABEL" === e.tagName,
                            r = e.getAttribute("for");
                        return t && (!(null == r ? void 0 : r.trim()) || !document.getElementById(r))
                    })(t[0])) return t[0].textContent
            }
            return null
        },
        Kn = e => {
            const t = e.previousElementSibling;
            return t && (e => {
                var t;
                return ["DIV", "SPAN", "P"].includes(e.tagName) && Boolean(null == (t = e.textContent) ? void 0 : t.trim())
            })(t) ? (j.strategy === He && ((e, t) => {
                const r = t.getAttribute("id") || p();
                t.setAttribute("id", r), e.setAttribute("aria-labelledby", r)
            })(e, t), t.textContent) : null
        },
        Zn = ({
            element: e,
            accessibleName: t,
            isRequired: r,
            isAutoStrategy: n = !0
        }) => {
            if (!n) return;
            const i = e.closest("label"),
                o = Fn(e);
            r ? (e.setAttribute("required", ""), e.setAttribute("aria-required", "true")) : (e.removeAttribute("required"), e.removeAttribute("aria-required"));
            const a = i || o;
            if (a) {
                const e = a.querySelector("span[data-uw-reader-element]");
                if (e) e.textContent = t;
                else {
                    const e = m(t);
                    a.appendChild(e)
                }
            } else e.hasAttribute("aria-labelledby") || e.setAttribute("aria-label", t)
        },
        Yn = e => {
            const t = e.getAttribute("aria-labelledby");
            if (t) {
                const e = (e => {
                    var t;
                    const r = e.split(" "),
                        n = [];
                    for (const i of r) {
                        const e = null == (t = document.getElementById(i)) ? void 0 : t.textContent;
                        e && n.push(e)
                    }
                    return n.join(" ")
                })(t);
                if (e) {
                    const t = Xn(e);
                    if (t) return t
                }
            }
            const r = e.getAttribute("aria-label");
            if (r) {
                const e = Xn(r);
                if (e) return e
            }
            const n = e.closest("label");
            if (n) {
                const e = (e => {
                    let t = e.textContent || "";
                    const r = e.querySelector("select");
                    if (r) {
                        const e = r.textContent || "";
                        t = t.replace(e, "")
                    }
                    return t.trim()
                })(n);
                if (e) return Xn(e)
            }
            const i = Fn(e);
            if (i) {
                const e = Xn(i);
                if (e) return e
            }
            return null
        },
        Qn = (e, t, r, n) => {
            const {
                Forms: i
            } = Y(), o = Yn(e), a = i.find((({
                xpath: e,
                approved: t
            }) => t && +e === g(r)));
            return o && (e => {
                const t = Fn(e);
                if (!t) return !1;
                const {
                    display: r,
                    visibility: n
                } = getComputedStyle(t);
                return "none" === r || "hidden" === n
            })(e) && e.setAttribute("aria-label", o), a ? (Zn({
                element: e,
                accessibleName: a.correction,
                isRequired: a.required
            }), {
                type: a.type,
                xpath: r,
                required: a.required,
                correction: a.correction,
                approved: a.approved,
                xpathHash: g(r),
                label: o
            }) : o ? (e.setAttribute(jt, "nfx"), {
                type: t,
                xpath: r,
                correction: o,
                approved: !0,
                xpathHash: g(r),
                label: o,
                required: n
            }) : null
        },
        Jn = e => {
            ((e, r = {}) => {
                var n, i;
                const o = {
                    skipParentCheck: null != (n = r.skipParentCheck) && n,
                    shouldBeInViewport: null == (i = r.shouldBeInViewport) || i
                };
                let a = e,
                    l = t(a, o);
                if (!o.skipParentCheck)
                    for (; l && a.parentNode && a.parentNode !== document;) t(a.parentNode, {
                        shouldBeInViewport: !1
                    }) ? a = a.parentNode : l = !1;
                return l
            })(e, {
                shouldBeInViewport: !1
            }) || (e.setAttribute("aria-label", Xt), e.setAttribute(Ft, Xt), ((e, t) => {
                new IntersectionObserver(((r, n) => {
                    for (const i of r) i.intersectionRatio > 0 && (t(e), n.disconnect())
                })).observe(e)
            })(e, (() => {
                e.hasAttribute(Ft) && e.hasAttribute("aria-label") && e.getAttribute(Ft) === e.getAttribute("aria-label") && (e.removeAttribute(Ft), e.removeAttribute("aria-label"))
            })));
            const r = zn(e);
            if (r) return r;
            const n = Kn(e);
            if (n) return n;
            const i = Gn(e);
            return i || null
        },
        ei = wr({
            ruleId: Ht,
            rule: ({
                context: {
                    elements: e
                }
            }) => {
                const t = [];
                for (const r of e) {
                    r.setAttribute(jt, "fx");
                    const e = r.hasAttribute("required"),
                        n = j.strategy === He,
                        i = f(r),
                        o = Vn(r),
                        a = Qn(r, o, i, e);
                    if (a) {
                        t.push(a);
                        continue
                    }
                    const l = Jn(r);
                    l ? (Zn({
                        element: r,
                        accessibleName: l,
                        isRequired: e,
                        isAutoStrategy: n
                    }), t.push({
                        type: o,
                        xpath: i,
                        correction: l,
                        approved: !1,
                        xpathHash: g(i),
                        label: null,
                        required: e
                    })) : t.push({
                        type: o,
                        xpath: i,
                        correction: null,
                        approved: !1,
                        xpathHash: g(i),
                        label: null,
                        required: e
                    })
                }
                un(Ht, t, t.filter((e => e.approved)).length, t.filter((e => !e.approved)).length)
            },
            isTargetElement: e => {
                const t = Vt.includes(e.tagName);
                if (e.hasAttribute(jt) || !t) return !1;
                const r = e.getAttribute("type");
                return !("SELECT" !== e.tagName && "TEXTAREA" !== e.tagName && ("INPUT" !== e.tagName || "hidden" === r))
            },
            postMessageApi: {
                "form-label-update": ({
                    correction: e,
                    required: t,
                    xpath: r
                }) => {
                    const n = L(r.toString());
                    n && (e && (n.setAttribute("aria-label", e), n.removeAttribute("aria-labelledby")), t ? (n.setAttribute("required", ""), n.setAttribute("aria-required", "true")) : (n.removeAttribute("required"), n.removeAttribute("aria-required")))
                }
            }
        }),
        ti = e => {
            const t = e.tagName.toLowerCase(),
                r = null == e ? void 0 : e.type,
                n = e.getAttribute("role");
            return ["a", "button"].includes(t) ? "a" === t ? "<link>" : "<button>" : "input" === t && ["button", "submit", "reset"].includes(r) ? "<input>" : "link" === n ? "<link> (role)" : "<button> (role)"
        },
        ri = [],
        ni = (e, t, r = !1) => {
            const n = !(null == j ? void 0 : j.strategy) || "AUTO" === j.strategy;
            var i;
            return (r || n) && e.setAttribute("aria-label", t), e.setAttribute(Ut, ""), i = {
                correction: t,
                approved: r,
                xpath: f(e),
                name: ti(e)
            }, ri.push(i), !0
        },
        ii = (e, t) => {
            var r;
            const n = t || e,
                i = Wt.find((e => "a" === n.tagName.toLowerCase() && n.href.includes(e)));
            if (i) return ni(e, i);
            const o = (e => {
                const t = Array.from(e.children);
                t.push(e);
                let r = [];
                for (const n of t) r = r.concat(Array.from(n.classList).map((e => e.toLowerCase())));
                return r
            })(n);
            let a = Wt.find((e => o.find((t => t.includes(e)))));
            if (a || $t.find((e => o.find((t => {
                    const r = e.re.test(t) && t.replace(e.re, e.replacer);
                    return !!r && (a = r, !0)
                })))), a) return ni(e, a);
            const s = null == (r = window.getComputedStyle(n).backgroundImage) ? void 0 : r.toLowerCase(),
                u = Wt.find((e => s.includes(e)));
            if (u) return ni(e, u);
            const c = Object.keys(Bt).find((e => o.find((t => t.includes(e))))),
                d = c ? Bt[c] : null;
            if (d) return ni(e, d);
            const p = l(n, "", {
                includeTextFromVisuallyHiddenElements: !0
            });
            return !!p && ni(e, p)
        },
        oi = e => {
            if (!e.hasAttribute("href")) return null;
            const t = e.getAttribute("href").toLowerCase().match(/^https?:\/\/(?:www\.)?([^/?#]+)/);
            return t ? t[1] : null
        },
        ai = {},
        li = e => {
            __spreadValues({}, ai)[g(e.xpath)] = e;
            const t = I(e.xpath);
            t && ni(t, e.correction)
        },
        si = wr({
            ruleId: Pt,
            rule: ({
                context: {
                    elements: e
                }
            }) => {
                const {
                    EmptyControls: t
                } = Y(), r = (e => {
                    if (!(null == e ? void 0 : e.length)) return null;
                    for (const t of e) {
                        const e = g(t.xpath),
                            r = ai[e],
                            n = t.page;
                        (!r || r && n) && (ai[e] = t)
                    }
                    return __spreadValues({}, ai)
                })(t);
                for (const i of e) {
                    const e = i.getAttribute("href");
                    if (("a" === i.tagName.toLowerCase() || "link" === i.getAttribute("role")) && "" === e && i.setAttribute("href", "#"), r) {
                        const e = r[g(f(i))];
                        if (e) {
                            ni(i, e.correction, !0);
                            continue
                        }
                    }
                    if (!ii(i)) {
                        const e = i.getAttribute("role"),
                            t = i.tagName.toLowerCase(),
                            r = i.getAttribute("type"),
                            n = i.getAttribute("alt"),
                            o = i.getAttribute(Nt);
                        if (Array.from(i.children).filter((e => !W(e))).find((e => ii(i, e)))) continue;
                        const a = oi(i);
                        if (a) {
                            ni(i, a);
                            continue
                        }
                        if ((n || o) && "img" === t && e && ["link", "button"].includes(e)) {
                            ni(i, n || o);
                            continue
                        }
                        if ("button" === t || "button" === e || "input" === t && "button" === r) {
                            ni(i, "button");
                            continue
                        }
                        if ("input" === t && "submit" === r) {
                            ni(i, "submit");
                            continue
                        }
                        if ("input" === t && "reset" === r) {
                            ni(i, "reset");
                            continue
                        }
                        ni(i, "Open this option")
                    }
                }
                const n = [].slice.call(ri);
                un("REMEDIATION_EMPTY_CONTROLS", n, n.length, n.filter((e => !e.approved)).length), ri.length = 0
            },
            isTargetElement: e => {
                if (e.hasAttribute(Ut)) return !1;
                const t = e.tagName.toLowerCase(),
                    r = e.getAttribute("role"),
                    n = null == e ? void 0 : e.type,
                    i = "a" === t || "button" === t,
                    o = "link" === r || "button" === r,
                    a = "input" === t && ["button", "submit", "reset"].includes(n);
                return !(!(i || o || a) || c(e, {
                    excludeAttribute: ["aria-describedby"]
                }))
            },
            postMessageApi: {
                "empty-controls-update": ({
                    data: e
                }) => {
                    var t;
                    (null != (t = null == e ? void 0 : e.xpath) ? t : null == e ? void 0 : e.correction) && li(e)
                }
            }
        }),
        ui = () => {
            const {
                hostname: e,
                pathname: t
            } = window.location, r = e.replace("www.", "").split("."), n = (i = r, i.length > 1 ? i.slice(0, -1) : i).join("-");
            var i;
            const o = t.split("/").filter((e => e)).join(" ").replace(/^\d+|\s\d+/g, "").trim();
            return (o + (o ? " - " : " ") + n).trim()
        },
        ci = (e, t) => {
            e.setAttribute(dr, t ? gr : mr)
        },
        di = wr({
            ruleId: pr,
            rule: ({
                context: {
                    elements: e
                }
            }) => {
                var t, r, n;
                if (e.length && (null == (t = e[0].innerHTML) ? void 0 : t.trim()) && U(e[0].innerHTML.trim())) {
                    const e = document.querySelector(`title[${dr}]`);
                    return void(null == e || e.remove())
                }
                const i = document.head.getElementsByTagName("title")[0];
                try {
                    if (i) {
                        if (!(i.hasAttribute(dr) || (null == (r = i.innerHTML) ? void 0 : r.trim()) && U(null == (n = i.innerHTML) ? void 0 : n.trim()))) {
                            i.setAttribute("data-uw-rm-title-orig", i.innerHTML);
                            const e = ui();
                            i.innerHTML = e, ci(i, e)
                        }
                    } else {
                        const e = document.createElement("title"),
                            t = ui();
                        e.innerHTML = t, ci(e, t), document.head.appendChild(e)
                    }
                } catch (o) {
                    o instanceof Error && console.error(o)
                }
            },
            isTargetElement: e => {
                const t = "title" === e.tagName.toLowerCase(),
                    r = e.hasAttribute(dr);
                return t && !r
            },
            forceRun: !0
        }),
        pi = "data-uw-rm-error-associate",
        mi = [`div[class*="error" i]:not([${pi}])`, `div[class*="message" i]:not([${pi}])`, `span[class*="error" i]:not([${pi}])`, `span[class*="message" i]:not([${pi}])`, `p[class*="error" i]:not([${pi}])`, `p[class*="message" i]:not([${pi}])`],
        gi = [`input:not([${pi}])`, `select:not([${pi}])`, `textarea:not([${pi}])`],
        fi = ["error", "message"],
        hi = e => {
            const t = e.nextElementSibling;
            if (t)
                for (const i of fi)
                    if ([...t.classList].join(" ").includes(i)) return t;
            const r = e.parentElement;
            if (!r) return null;
            if (1 !== r.querySelectorAll(gi.join(",")).length) return null;
            const n = r.querySelectorAll(mi.join(","));
            return 1 !== n.length ? null : n[0]
        },
        bi = (e, t) => {
            if (e.getAttribute(pi)) return;
            const r = "true" === e.getAttribute("aria-invalid"),
                n = e.getAttribute("aria-errormessage"),
                i = e.getAttribute("aria-describedby");
            if (r && n || i) return void e.setAttribute(pi, "nfx");
            const o = t.getAttribute("id");
            if (o) return e.setAttribute("aria-describedby", o), e.setAttribute(pi, "fx"), void t.setAttribute(pi, "fx");
            const a = p();
            t.setAttribute("id", a), t.setAttribute(pi, "fx"), e.setAttribute("aria-describedby", a), e.setAttribute(pi, "fx")
        },
        Ai = e => {
            for (const t of e) {
                const e = hi(t);
                e && bi(t, e)
            }
        },
        yi = (e, t) => {
            const r = e.getBoundingClientRect();
            let n = 1 / 0,
                i = null;
            for (const o of t) {
                const e = o.getBoundingClientRect(),
                    t = e.left - r.left,
                    a = e.bottom - r.top,
                    l = Math.abs(a),
                    s = Math.sqrt(t * t + a * a);
                l <= 100 && s < n && (n = s, i = o)
            }
            return i
        },
        Ei = (e, t) => {
            for (const r of t) {
                const t = yi(r, e);
                t && bi(t, r)
            }
        },
        vi = e => {
            const t = new MutationObserver((t => {
                const r = e.querySelectorAll(gi.join(",")),
                    n = e.querySelectorAll(mi.join(","));
                for (const e of t) "childList" === e.type && (Ai([...r]), Ei([...r], [...n]))
            }));
            t.observe(e, {
                childList: !0,
                subtree: !0
            }), setTimeout((() => {
                t.disconnect()
            }), 15e3)
        },
        _i = wr({
            ruleId: "REMEDIATION_CONTROL_ERROR_ASSOCIATE",
            rule: ({
                context: {
                    elements: e
                }
            }) => {
                if (j.strategy === He)
                    for (const t of e) t.addEventListener("submit", (() => {
                        const e = [...t.querySelectorAll(gi.join(","))],
                            r = t.querySelectorAll(mi.join(","));
                        Ai(e), Ei(e, [...r]), vi(t)
                    }))
            },
            isTargetElement: e => "FORM" === e.tagName && !e.hasAttribute("data-uw-rm-error-associate-ignore")
        }),
        wi = e => {
            const t = e.match(/user-scalable=(0|no)/);
            return t ? e.replace(t[0], "") : e
        },
        Ti = e => e.replace(/\s/g, "").replace(/,+|;+/g, ", ").replace(/\s+$/g, "").replace(/^(,\s*)/, "").replace(/(,\s*)$/, ""),
        Ni = e => {
            const t = e.match(/maximum-scale(?:=([0-9]+(?:\.[0-9]+)?))?/),
                r = e.match(/\bmaximum-scale\b(?!=)/);
            if (t) {
                const n = parseFloat(t[1]);
                if (!Number.isNaN(n) && n < 5 || r) return e.replace(t[0], "maximum-scale=5.0")
            }
            return e
        },
        xi = wr({
            ruleId: er,
            rule: () => {
                const e = document.head.querySelectorAll(rr);
                for (const t of e) {
                    let e = t.getAttribute("content") || "";
                    e = [Ni, wi, Ti].reduce(((e, t) => t(e)), e), t.setAttribute("content", e), t.setAttribute(tr, "")
                }
            },
            isTargetElement: e => !e.hasAttribute(tr) && e.matches(rr),
            forceRun: !0
        }),
        Ii = e => {
            const t = null == e ? void 0 : e.trim();
            return (null == t ? void 0 : t.length) ? t.split("?")[0].split("#")[0] : ""
        };
    var Li = (e => (e.PRESENT = "PRESENT", e.MISSING = "MISSING", e))(Li || {});
    const Si = () => __async(this, null, (function*() {
            const {
                siteId: e
            } = F;
            try {
                const t = yield fetch(`${J}br-links/v0/contribute/${e}`, {
                    method: "GET"
                });
                return (yield t.json()).payload
            } catch (t) {
                return Li.PRESENT
            }
        })),
        Ci = (e, t) => __async(this, null, (function*() {
            const {
                siteId: r,
                userId: n
            } = F, i = {
                userId: n,
                siteId: r,
                links: e,
                page: window.location.pathname,
                fullPage: window.location.href
            };
            yield fetch(`${J}br-links/v0/contribute/${r}`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(i),
                signal: t
            }).catch((() => {}))
        })),
        Oi = () => __async(this, null, (function*() {
            const {
                siteId: e
            } = F;
            try {
                const t = yield fetch(`${J}br-links/v0/links/${e}`, {
                    method: "GET"
                });
                return yield t.json()
            } catch (t) {
                return {
                    thisPageItems: [],
                    totalNumber: 0,
                    lastPageIndex: 0,
                    pageItemType: "BrokenLinkHref"
                }
            }
        })),
        Ri = e => {
            var t;
            const r = null == (t = UserWayWidgetApp.getLib("localization_manager")) ? void 0 : t.translate,
                n = e.getAttribute("aria-label"),
                i = c(e),
                o = null != n ? n : i,
                a = `${r(z,"widget.broken_links.target_site_not_available")}`,
                l = o ? `${o} - ${a}` : a;
            return e.setAttribute("aria-label", l), e.setAttribute(Zt, Qt.Fixed), e.setAttribute(ut, ""), l
        },
        ki = e => {
            var t;
            return {
                originalHref: e.getAttribute(Yt) || "",
                href: Ii(e.href),
                text: null != (t = e.getAttribute("aria-label")) ? t : "",
                pageHash: g(window.location.pathname),
                page: window.location.pathname,
                siteId: F.siteId
            }
        };
    let Di = [];
    const Mi = [],
        Pi = new AbortController,
        Ui = e => {
            e.length && Si().then((t => {
                try {
                    if (t === Li.PRESENT) return void Pi.abort();
                    if (t === Li.MISSING) {
                        const t = e.map((e => {
                                const t = e.getAttribute(Zt);
                                t !== Qt.Fixed && t !== Qt.FixedByCorrection && e.setAttribute(Zt, Qt.BackEndContributed);
                                const r = Ii(e.href);
                                var n;
                                return n = r, Mi.push(n), r
                            })),
                            r = [...new Set(t)];
                        Ci(r, Pi.signal), Di = []
                    }
                } catch (r) {}
            })).catch((e => {}))
        },
        Wi = $e((e => Ui(e)), 3500, {
            maxWait: 3500,
            leading: !1,
            trailing: !0
        }),
        Bi = new RegExp(/https?:\/\/(www\.)?[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-zA-Z0-9()]{1,63}\b([-a-zA-Z0-9()@:%_+.~#?&//=]*)/),
        $i = wr({
            ruleId: Kt,
            rule: ({
                context: {
                    elements: e
                }
            }) => {
                const t = [];
                for (const o of e) o.setAttribute(Zt, Qt.Processed), o.setAttribute(Yt, o.href);
                const r = e.filter((e => {
                        const r = e,
                            n = (e => {
                                const {
                                    BrokenLink: t
                                } = Y(), r = t.find((t => t.href === e.href));
                                if (!r) return !1;
                                const {
                                    href_correction: n,
                                    text_correction: i
                                } = r;
                                if (n && M(n)) {
                                    const t = D(n);
                                    e.setAttribute("href", t)
                                }
                                return i && e.setAttribute("aria-label", i), e.setAttribute(Zt, Qt.FixedByCorrection), !0
                            })(r);
                        n && t.push(ki(r));
                        const i = Bi.test(null == r ? void 0 : r.href);
                        return n || i || (Ri(e), t.push(ki(r))), i && !n
                    })),
                    n = r.filter((e => {
                        const t = e,
                            r = Ii(null == t ? void 0 : t.href);
                        return n = r, !Mi.includes(n) || (t.setAttribute(Zt, Qt.BackEndContributed), !1);
                        var n
                    }));
                var i;
                i = n, Di = [...Di, ...i], Wi([...Di]), Oi().then((({
                    thisPageItems: e
                }) => {
                    for (const n of e) {
                        const e = r.find((e => Ii(e.href) === n.href));
                        if (e) {
                            Ri(e);
                            const r = ki(e);
                            t.push(r)
                        }
                    }
                })).catch((e => {
                    console.log(e)
                })).finally((() => {
                    un(Kt, t, t.length, t.length)
                }))
            },
            isTargetElement: e => {
                if ("a" !== e.tagName.toLowerCase()) return !1;
                const {
                    href: t,
                    hostname: r
                } = e, n = e.hasAttribute(Zt), i = !(null == t ? void 0 : t.trim());
                if (n || i) return !1;
                const o = new URL(t);
                if (!["http:", "https:"].includes(o.protocol)) return !1;
                return ![/\.pdf/, /wp-admin/, /javascript:void/, /^(tel:|mailto:|sms:|ftp:|file:|geo:|news:|irc:|skype:|spotify:|whatsapp:|market:|steam:|git:|svn:|ed2k:|magnet:|gopher:|dict:)/].some((e => e.test(t))) && !Jt.some((e => null == r ? void 0 : r.includes(e)))
            },
            postMessageApi: {
                "update-broken-link": ({
                    correctionHref: e,
                    originalHref: t,
                    label: r
                }) => {
                    const n = document.querySelectorAll(`a[${Yt}*="${t}" i]`);
                    for (const i of n)
                        if (r && i.setAttribute("aria-label", r), e && M(e)) {
                            const t = D(e);
                            i.setAttribute("href", t)
                        }
                }
            }
        }),
        Hi = (e, t) => `${e}$${t}`.toLowerCase().replace(/ /g, ""),
        ji = e => {
            const t = e.getAttribute("aria-label"),
                r = e.getAttribute("aria-labelledby");
            return t || (r ? s(r) : l(e))
        },
        Vi = wr({
            ruleId: st,
            rule: ({
                context: {
                    elements: e
                }
            }) => {
                var t;
                const r = null == (t = UserWayWidgetApp.getLib("localization_manager")) ? void 0 : t.translate,
                    {
                        ExternalLink: n
                    } = Y(),
                    i = (e => {
                        const t = {};
                        for (const r of e) t[Hi(r.href, r.term)] = r;
                        return t
                    })(n),
                    o = [];
                for (const a of e) {
                    const e = ji(a),
                        t = Hi(a.href, e);
                    let n;
                    if (!e || e.includes("new window") || e.includes("new tab")) a.setAttribute(ut, "na");
                    else {
                        if (i[t]) n = i[t].correction, o.push(Object.assign(i[t], {
                            id: t
                        }));
                        else {
                            const i = ` - ${r(z,"widget.new_tab")}`;
                            n = (a.hasAttribute("aria-label") ? a.getAttribute("aria-label") : e) + i, o.push({
                                href: a.href,
                                term: e,
                                correction: n,
                                id: t
                            })
                        }
                        a.setAttribute("aria-label", n), a.setAttribute(ut, ""), a.setAttribute("uw-rm-external-link-id", t)
                    }
                }
                un(st, o, o.length, 0)
            },
            isTargetElement: e => {
                if ("a" !== e.tagName.toLowerCase()) return !1;
                const t = e;
                if (t.hasAttribute(ut)) return !1;
                const {
                    href: r,
                    target: n
                } = t, i = /^(http|https):/.test(r);
                return !!((null == r ? void 0 : r.trim()) && i && n && "_blank" === n)
            }
        }),
        Fi = "REMEDIATION_AUTO_PLAY_VIDEO",
        Xi = "data-uw-rm-av",
        qi = ["IFRAME", "VIDEO"],
        Gi = ["youtube.com", "vimeo.com"],
        zi = ["autoplay=1", "autoplay=true"],
        Ki = ["mute=1", "mute=true"],
        Zi = wr({
            ruleId: Fi,
            rule: ({
                context: {
                    elements: e
                }
            }) => {
                for (const t of e) "IFRAME" === t.nodeName ? t.setAttribute(Xi, "if") : "VIDEO" === t.nodeName && t.setAttribute(Xi, "vi");
                un(Fi, [], e.length, 0)
            },
            isTargetElement: e => {
                if (!qi.includes(e.nodeName) || e.hasAttribute(Xi)) return !1;
                if ("IFRAME" === e.nodeName) {
                    const t = e.getAttribute("src");
                    if (!(t && Gi.some((e => t.includes(e))) && zi.some((e => t.includes(e))) && Ki.some((e => t.includes(e))))) return !1
                }
                const t = e.hasAttribute("autoplay"),
                    r = e.hasAttribute("muted");
                return !!("VIDEO" !== e.nodeName || t && r)
            }
        }),
        Yi = e => {
            if (!e) return "";
            return e.trim().replace(/(\n|\r\n)/g, "").replace(/\s+/g, " ").replace(/\u200B/g, "")
        },
        Qi = e => {
            const t = e.textContent ? e.textContent : null,
                r = /tel:(.+)/,
                n = /mailto:(.+)/,
                i = /sms:(.+)/,
                o = e.getAttribute("href");
            return o && r.test(o) ? o.replace(r, "call $1") : o && n.test(o) ? o.replace(n, "send an email to $1") : o && i.test(o) ? o.replace(i, "send an sms to $1") : t && t.trim() ? Yi(t.replace(/[^A-Za-z0-9\s]/g, "").replace(/\s{2,}/g, " ").replace(/\n/g, " ").toLowerCase()) : null
        },
        Ji = e => {
            function t(e) {
                if (!e) return null;
                if (-1 !== ["h1", "h2", "h3", "h4", "h5", "h6"].indexOf(e.nodeName.toLowerCase())) return e.textContent;
                const t = "heading" === e.getAttribute("role"),
                    r = e.getAttribute("aria-level") || "";
                if (t && ["1", "2", "3", "4", "5", "6"].includes(r)) return e.textContent;
                const n = Array.from(e.querySelectorAll('h1,h2,h3,h4,h5,h6,[role="heading"][aria-level="1"],[role="heading"][aria-level="2"],[role="heading"][aria-level="3"],[role="heading"][aria-level="4"],[role="heading"][aria-level="5"],[role="heading"][aria-level="6"]'));
                return n.length ? n[0].textContent : null
            }
            let r = e.parentElement,
                n = e;
            for (; r && Yi(k(r)) === Yi(e.textContent);) n = r, r = r.parentElement;
            let i = n.previousElementSibling,
                o = t(i);
            for (; i && i.parentElement === r && !o;) i = i.previousElementSibling, o = i ? t(i) : null;
            if (o) return Yi([e.textContent, o].join(" "));
            const a = function(e, t) {
                if (!e) return [];
                const r = [],
                    n = (i = e, null == o && (o = document), o.createTreeWalker(i, NodeFilter.SHOW_TEXT, null));
                var i, o;
                let a = n.nextNode();
                for (; a;) r.push({
                    node: a,
                    target: a.parentElement === t
                }), a = n.nextNode();
                return r
            }(r, e).map((({
                target: e,
                node: t
            }) => ({
                text: Yi(t.textContent),
                target: e
            }))).filter((({
                text: e
            }) => !!e));
            let l = "",
                s = "",
                u = "";
            const c = a.find((({
                    target: e
                }) => e)),
                d = c && a.indexOf(c);
            s = c ? c.text : "";
            let p = [];
            if (void 0 !== d && (d && a[d - 1] && (p = a[d - 1].text.split(/[.!?]+/), l = p.pop(), l = l ? l.trim() : ""), d + 1 < a.length)) {
                u = a[d + 1].text.split(/[.!?]+/).shift(), u = u ? u.trim() : ""
            }
            l || u || (l = p.length ? p.pop() : "");
            return Yi([l, s, u].filter((e => !!e)).join(" "))
        },
        eo = (e, t) => `${e}$${t}`.toLowerCase(),
        to = [],
        ro = e => {
            to.push(e)
        },
        no = {},
        io = {},
        oo = ({
            correction: e,
            approved: t,
            id: r
        }) => {
            const n = io[r];
            const i = !(null == j ? void 0 : j.strategy) || "AUTO" === j.strategy;
            n && e && (t || i) && (n.setAttribute("aria-label", e), n.setAttribute(gt, ""), n.setAttribute("uw-rm-vague-link-id", r))
        },
        ao = (e, t) => {
            if (!e || !t) return !1;
            const r = e.match(/(tel:\+)(.+)/),
                n = e.match(/(sms:\+)(.+)/),
                i = e.match(/(mailto:)(.+)/);
            return !!(r && r[2] && t.includes(r[2])) || (!!(n && n[2] && t.includes(n[2])) || !!(i && i[2] && t.includes(i[2])))
        },
        lo = e => {
            const t = (e => {
                if (!(null == e ? void 0 : e.length)) return no;
                for (const t of e) {
                    const e = eo(t.href, t.term);
                    no[e] || (no[e] = t)
                }
                return __spreadValues({}, no)
            })(Y().VagueLinks);
            for (const i of e) {
                const e = Qi(i);
                if (!e) continue;
                let o;
                const a = i.getAttribute("href");
                if (a && /^tel:|^mailto:|^sms:/.test(a) && !ao(a, i.innerText)) o = e;
                else if (-1 === ft.indexOf(e) || ao(a, i.innerText)) continue;
                const l = eo(i.getAttribute("href") || i.nodeName, e),
                    s = t[l];
                o = (null == s ? void 0 : s.correction) ? null == s ? void 0 : s.correction : o || Ji(i);
                const u = {
                    href: (null == s ? void 0 : s.href) || i.getAttribute("href") || "",
                    term: (null == s ? void 0 : s.term) || e,
                    correction: (null == s ? void 0 : s.correction) || o,
                    approved: (n = null == s ? void 0 : s.approved, null != n && (null == s ? void 0 : s.approved)),
                    id: l
                };
                r = i, io[l] = r, oo(u), ro(u)
            }
            var r, n;
            return [].slice.call(to)
        },
        so = e => "A" === (null == e ? void 0 : e.nodeName),
        uo = wr({
            ruleId: mt,
            rule: ({
                context: {
                    elements: e
                }
            }) => {
                const t = lo(e);
                un(mt, t, t.length, t.filter((({
                    approved: e
                }) => !e)).length), to.length = 0
            },
            isTargetElement: e => {
                if (!(e => (null == e ? void 0 : e.nodeType) === Node.ELEMENT_NODE)(e) || !so(e) && !(e => "link" === (null == e ? void 0 : e.getAttribute("role")))(e)) return !1;
                const t = e.getAttribute("href");
                if (so(e) && (!t || !/(^http|^tel:|^mailto:|^sms:)/.test(t))) return !1;
                const r = e.getAttribute("aria-label");
                if (null == r ? void 0 : r.trim()) return !1;
                const n = e.getAttribute("aria-labelledby");
                return !(null == n ? void 0 : n.trim()) && !e.hasAttribute(gt)
            },
            postMessageApi: {
                "vague-link-update": e => {
                    oo(e)
                }
            }
        }),
        co = e => {
            var t;
            const r = e.getAttribute("aria-label") || e.getAttribute("aria-labelledby") || e.textContent,
                n = null == (t = null == r ? void 0 : r.trim()) ? void 0 : t.toLowerCase();
            return null != n ? n : null
        },
        po = e => {
            const t = dt.includes(e.tagName) || e.hasAttribute("tabindex"),
                r = e.hasAttribute("disabled"),
                n = "hidden" === e.getAttribute("type");
            return t && !r && !n
        },
        mo = e => {
            const t = document.querySelector("main") || document.querySelector('[role="main"]') || document.querySelector("h1");
            if (!t) return !0;
            let r = 0;
            for (const n of e) {
                if (n === t) break;
                if (po(n) && (r++, r <= 3)) {
                    const e = co(n);
                    if (e && "uw-skip-to-main" !== n.id && pt.some((t => e.toLowerCase().includes(t)))) return !0
                }
                if (r > 5) break
            }
            return r <= 5
        },
        go = [],
        fo = wr({
            ruleId: ct,
            rule: ({
                context: {
                    elements: e
                }
            }) => {
                const {
                    pathname: t
                } = window.location;
                let r = 0;
                const n = j.skipLinks,
                    i = [{
                        enabled: n.enabled,
                        selector: n.config.anchorSelector
                    }],
                    o = !mo(e);
                !go.includes(t) && o && (document.body.setAttribute("data-uw-rm-skl", ""), r++), go.push(t), un(ct, i, r, r)
            },
            isTargetElement: e => e.matches("body *") && "userwayAccessibilityIcon" !== e.id,
            postMessageApi: {
                "skip-links-get": t => {
                    const r = j.skipLinks;
                    e(__spreadProps(__spreadValues({}, t), {
                        data: {
                            enabled: r.enabled,
                            selector: r.config.anchorSelector
                        }
                    }))
                }
            }
        }),
        ho = "REMEDIATION_IFRAME_TITLE",
        bo = "data-uw-rm-iframe",
        Ao = "data-correct-title",
        yo = "un",
        Eo = "gn",
        vo = e => {
            const t = e.getAttribute(Ao);
            t && (e.setAttribute("title", t), e.setAttribute(bo, Eo), e.removeAttribute(Ao))
        },
        _o = e => {
            const t = "src",
                r = "class",
                n = "id",
                i = e.getAttribute(t) || "",
                o = e.getAttribute(r) || "",
                a = e.getAttribute(n) || "",
                l = (e => {
                    let t = "";
                    try {
                        const {
                            hostname: r
                        } = new URL(e);
                        t = r.replace("www.", "").split(".").slice(0, -1).join("-")
                    } catch (r) {}
                    return t
                })(i) || (e => e.replace(/\./g, "").split(" ").join("___"))(o) || a;
            l ? (e.setAttribute("title", l), e.setAttribute(bo, Eo)) : e.setAttribute(bo, yo)
        },
        wo = (e, t) => {
            const r = [];
            return t.forEach((t => {
                r.push(e[t])
            })), r
        },
        To = e => {
            const t = (e => {
                    const t = {};
                    let r = [];
                    const n = [];
                    e.forEach(((e, r) => {
                        var n;
                        const i = null == (n = e.getAttribute("src")) ? void 0 : n.trim();
                        i && (t[i] ? t[i].push(r) : t[i] = [r])
                    })), Object.keys(t).filter((e => t[e].length > 1)).forEach((r => {
                        n.push({
                            src: r,
                            elements: wo(e, t[r])
                        })
                    }));
                    for (const i of n) {
                        i.elements.sort(((e, t) => e.title.length - t.title.length));
                        const e = i.elements[i.elements.length - 1].title;
                        e && (i.elements.pop(), i.elements.forEach((t => {
                            t.setAttribute(Ao, e)
                        })), r = r.length ? r.concat(i.elements) : i.elements)
                    }
                    return r
                })(e),
                r = (e => e.filter((e => !(e => !!e.getAttribute("title"))(e))))(e).filter((e => !t.find((t => t === e)))),
                n = [...r, ...t];
            for (const i of n) i.hasAttribute(Ao) ? vo(i) : _o(i);
            return n
        },
        No = wr({
            ruleId: ho,
            rule: ({
                context: {
                    elements: e
                }
            }) => {
                const t = To(e);
                un(ho, [], t.length, 0)
            },
            isTargetElement: e => {
                const t = "iframe" === e.tagName.toLowerCase(),
                    r = e.hasAttribute(bo);
                return t && !r
            }
        }),
        xo = ["aside .filter input[type=checkbox]", ".snize-product-filters-list input[type=checkbox]"],
        Io = "data-uw-rm-accessible-cb",
        Lo = wr({
            ruleId: "REMEDIATION_ACCESSIBLE_CHECKBOX_ID",
            rule: ({
                context: {
                    elements: e
                }
            }) => {
                e.forEach((e => {
                    var t;
                    e.setAttribute(Io, "");
                    const r = e.style,
                        {
                            display: n
                        } = getComputedStyle(e);
                    if ("none" === n && (r.setProperty("height", "0", "important"), r.setProperty("width", "0", "important"), r.setProperty("margin", "0", "important")), r.setProperty("visibility", "visible", "important"), r.setProperty("display", "inline-block", "important"), r.setProperty("opacity", "0", "important"), r.setProperty("pointer-events", "none", "important"), !e.id) return;
                    const i = Fn(e);
                    i && i.textContent && !e.hasAttribute("aria-label") && e.setAttribute("aria-label", null == (t = i.textContent) ? void 0 : t.trim())
                }))
            },
            isTargetElement: e => {
                if (e.hasAttribute(Io)) return !1;
                if (!xo.some((t => e.matches(t)))) return !1;
                const {
                    display: t,
                    visibility: r
                } = window.getComputedStyle(e);
                return "none" === t || "hidden" === r
            }
        }),
        So = "REMEDIATION_SITE_LANGUAGE",
        Co = "data-uw-rm-lang",
        Oo = ["aa", "ab", "af", "am", "ar", "as", "ay", "az", "ba", "be", "bg", "bh", "bi", "bn", "bo", "br", "ca", "ceb", "co", "cs", "cy", "da", "de", "div", "dz", "el", "en", "eo", "es", "et", "eu", "fa", "fi", "fj", "fo", "fr", "fy", "ga", "gd", "gl", "gn", "gu", "ha", "haw", "he", "hi", "hr", "hu", "hy", "ia", "id", "ie", "ik", "id", "is", "it", "iw", "ja", "ji", "jw", "ka", "kk", "kl", "km", "kn", "ko", "kok", "ks", "ku", "ky", "kz", "la", "ln", "lo", "ls", "lt", "lv", "mg", "mi", "mk", "ml", "mn", "mo", "mr", "ms", "mt", "my", "na", "nb-no", "ne", "nl", "nn-no", "no", "oc", "om", "or", "pa", "pl", "ps", "pt", "qu", "rm", "rn", "ro", "ru", "rw", "sa", "sb", "sd", "sg", "sh", "si", "sk", "sl", "sm", "sn", "so", "sq", "sr", "sr-Latn", "ss", "st", "su", "sv", "sw", "sx", "syr", "ta", "te", "tg", "th", "ti", "tk", "tl", "tn", "to", "tr", "ts", "tt", "tw", "uk", "ur", "us", "uz", "vi", "vo", "wo", "xh", "yi", "yo", "zh", "zu", "ilo", "prs", "eu", "hmn", "hy"],
        Ro = e => {
            if (!e || e.length > e.trim().length) return !1;
            let t = e;
            return e.indexOf("-") > -1 && ([t] = e.split("-")), e.indexOf("_") > -1 && ([t] = e.split("_")), Oo.includes(t.toLowerCase())
        },
        ko = wr({
            ruleId: So,
            rule: ({
                context: {
                    elements: e
                }
            }) => {
                const {
                    widgetCorrection: t,
                    fixedItemsNumber: r
                } = (e => {
                    const t = Y().Language,
                        r = `${g(window.location.pathname)}`,
                        n = t.find((e => e.page === r)),
                        i = {
                            fixedItemsNumber: 0,
                            widgetCorrection: {}
                        };
                    return n && document.documentElement.setAttribute("lang", n.correction), e.forEach((e => {
                        let t = e.getAttribute("lang"),
                            r = e.getAttribute("xml:lang"),
                            n = !1;
                        r && !Ro(r) && (e.removeAttribute("xml:lang"), r = null, n = !0), t && !Ro(t) && (e.removeAttribute("lang"), t = null, n = !0), e !== document.documentElement || t || (t = z || "en", e.setAttribute("lang", t), n = !0), t && r && t !== r && (n = !0, e.setAttribute("xml:lang", t)), e.setAttribute(Co, `${n}`), n && i.fixedItemsNumber++
                    })), i.widgetCorrection = {
                        count: i.fixedItemsNumber,
                        lang: n
                    }, i
                })(e);
                un(So, [t], r, 0)
            },
            isTargetElement: e => {
                const t = !!e.getAttribute("lang") || !!e.getAttribute("xml:lang"),
                    r = "HTML" === e.tagName,
                    n = e.hasAttribute(Co);
                return (t || r) && !n
            }
        }),
        Do = e => __async(this, null, (function*() {
            const t = UserWayWidgetApp.getLib("remediation_utils"),
                r = [];
            for (const i of e) !i.hasAttribute(ur) && r.indexOf(i) < 0 && r.push(i);
            if (j.pdf.config.quotaExceeded)
                for (const e of r) e.setAttribute(ur, cr.IN_PROCESSING_OR_QUOTA_EXCEEDED);
            else try {
                const e = yield t.sendBackEnd("/br-links/v0/pdf-links", null, {
                    page: window.location.pathname,
                    fullPage: window.location.href,
                    links: r.map((e => e.href))
                }), n = e && e.response && JSON.parse(e.response);
                for (let t = 0; t < r.length; t++) {
                    const e = r[t],
                        i = `${n.statuses[t]}`;
                    [cr.INVALID_LINK, cr.VALID_LINK, cr.IN_PROCESSING_OR_QUOTA_EXCEEDED].indexOf(i) > -1 && e.setAttribute(ur, `${i}`)
                }
            } catch (n) {}
        })),
        Mo = {},
        Po = e => __async(this, null, (function*() {
            const t = [],
                r = [],
                n = [];
            for (let o = 0; o < e.length; o++) {
                const a = e[o],
                    l = a.href.split("?")[0];
                if (!l) continue;
                const s = `${g(l)}`,
                    u = (i = a.href).substring(i.lastIndexOf("/") + 1),
                    c = a.hasAttribute("data-uw-pdf-rem");
                if (Mo[s]) {
                    const e = Mo[s].rem_url;
                    e && !c && (a.setAttribute(sr, a.href), a.href = "https://cdn.userway.org/" + e), n.indexOf(l) < 0 && (r.push(__spreadProps(__spreadValues({}, Mo[s]), {
                        name: u,
                        pdf_url: l,
                        pdf_link: a.innerText,
                        pdf_isDone: !!e || c
                    })), n.push(l))
                } else {
                    const e = a.hasAttribute(ur) && a.getAttribute(ur) === cr.VALID_LINK,
                        i = a.hasAttribute(ur) && a.getAttribute(ur) === cr.INVALID_LINK;
                    e && !c && t.push({
                        hash: s,
                        url: l
                    }), n.indexOf(l.toLowerCase()) < 0 && (r.push({
                        pdf_url: a.href,
                        pdf_hash: s,
                        pdf_link: a.innerText,
                        name: u,
                        status: c ? "DONE" : null,
                        validityCheckFailed: i,
                        id: `not_created-${o}`,
                        pdf_isDone: c
                    }), n.push(l.toLowerCase()))
                }
                a.setAttribute(lr, "")
            }
            var i;
            return {
                widgetCorrectionsList: r,
                backendCorrectionsList: t
            }
        })),
        Uo = wr({
            ruleId: ar,
            rule: e => __async(this, [e], (function*({
                context: {
                    elements: e
                }
            }) {
                (() => {
                    const e = Y().Pdfs;
                    for (const t of e) Mo[t.pdf_hash] = t
                })(), yield Do(e);
                const {
                    widgetCorrectionsList: t,
                    backendCorrectionsList: r
                } = yield Po(e);
                un(ar, t, t.length, t.length, {
                    items: r,
                    path: "pdf",
                    props: {
                        page: window.location.pathname
                    }
                })
            })),
            isTargetElement: e => {
                var t, r;
                if (!e || e.nodeType !== Node.ELEMENT_NODE || "A" !== e.nodeName) return !1;
                if (e.hasAttribute(lr)) return !1;
                if (e.hasAttribute(sr)) return !1;
                const n = null != (r = null == (t = e.href) ? void 0 : t.split("?")[0]) ? r : null;
                if (!n) return !1;
                const i = null == n ? void 0 : n.match(/\.pdf($|\?)/i);
                let o = !1;
                const a = new URLSearchParams(e.href);
                for (const [, l] of a.entries())(null == l ? void 0 : l.match(/\.pdf($|\?)/i)) && (o = !0);
                return !(!i && !o)
            }
        }),
        Wo = (e, t) => {
            e.setAttribute("role", "heading"), e.setAttribute("aria-level", `${t}`), e.setAttribute(Ct, "level")
        },
        Bo = e => {
            if (/(h\d)/i.test(e.nodeName)) return +e.nodeName.slice(1);
            const t = e.getAttribute("aria-level");
            return t ? +t : 0
        },
        $o = wr({
            ruleId: nr,
            rule: ({
                context: {
                    elements: e
                }
            }) => {
                const t = [];
                if (e.length) {
                    let r, n = 0;
                    for (let i = 0; i < e.length; i++) {
                        const o = e[i];
                        if (o.hasAttribute("data-uw-ignore-rm-heading")) continue;
                        r = Bo(o);
                        const a = l(o);
                        if (1 === r && o.hasAttribute(ir)) {
                            n = 1;
                            continue
                        }
                        const s = {
                            type: "CONTENT",
                            level: r,
                            content: a,
                            approved: !0,
                            xpath: f(o),
                            autofix: !0,
                            previousLevel: 0
                        };
                        if (a && 1 === r && 0 !== i && (o.setAttribute("role", "heading"), o.setAttribute("aria-level", "2"), o.setAttribute(ir, "level"), s.previousLevel = 1, s.approved = !1, s.type = "LEVEL", r = 2, s.level = 2), null == a ? void 0 : a.trim())
                            if (r > n + 1) {
                                s.previousLevel = r;
                                const e = n + 1;
                                s.type = "LEVEL", o.setAttribute(ir, "level"), s.level = e, Wo(o, e), n++, s.approved = !1, t.push(s)
                            } else n = r, t.push(s);
                        else {
                            o.setAttribute("role", "presentation"), o.setAttribute("aria-hidden", "true");
                            const e = m(or, "data-uw-rm-autofix-hide");
                            o.appendChild(e), s.content = or, s.type = "HIDE", s.approved = !1, o.setAttribute(ir, "hide"), t.push(s)
                        }
                    }
                } else {
                    const e = (() => {
                        const e = document.createElement("h1"),
                            t = document.querySelector("main"),
                            r = document.querySelector("[role=main]"),
                            n = t || r;
                        if (n) {
                            const t = document.title;
                            return Wo(e, 1), e.setAttribute("style", "clip: rect(1px, 1px, 1px, 1px)!important;height:1px!important;width:1px!important;overflow:hidden!important;position:absolute!important;top:0!important;left:0!important;z-index:-1!important;opacity:0!important"), e.setAttribute(ir, "h1"), e.setAttribute("id", "userway-h1-heading"), e.setAttribute("data-uw-rm-ignore", ""), e.innerText = t, n.prepend(e), {
                                headerElement: e,
                                correction: {
                                    type: "ADD-H1",
                                    level: 1,
                                    previousLevel: 0,
                                    content: t,
                                    autofix: !0,
                                    approved: !1,
                                    xpath: f(e)
                                }
                            }
                        }
                        return {}
                    })();
                    e.correction && e.headerElement && (t.push(e.correction), ((e, t) => {
                        const r = e,
                            {
                                Headings: n
                            } = Y(),
                            i = n.find((e => e.xpath === t));
                        if (!i) return !1;
                        const {
                            correction: o
                        } = i;
                        o && (r.textContent = o), r.setAttribute(ir, "")
                    })(e.headerElement, f(e.headerElement)))
                }
                un(nr, t, document.querySelectorAll(`[${ir}]`).length, 0)
            },
            isTargetElement: e => e.matches('h1, h2, h3, h4, h5, h6, [role="heading"]') && !e.hasAttribute(ir)
        }),
        Ho = "REMEDIATION_COLOR_CONTRAST",
        jo = "data-uw-rm-color-contrast",
        Vo = {
            AUTOFIX: "afix",
            PARSED: "prs",
            SET: "set"
        },
        Fo = ["SVG", "SCRIPT", "IMG", "STYLE"],
        Xo = ["radio", "checkbox", "hidden"],
        qo = {
            color: "",
            background: ""
        },
        Go = [],
        zo = () => Go;
    let Ko = !1;
    const Zo = () => Ko,
        Yo = e => {
            Ko = e
        };
    let Qo = !1;
    const Jo = e => {
        Qo = e
    };
    let ea = !1;
    const ta = [],
        ra = e => {
            ta.push(...e)
        },
        na = () => ta.map((({
            xpath: e
        }) => e));
    let ia = [];
    const oa = e => {
            ia.push(...e)
        },
        aa = () => ia,
        la = () => {
            ia = ia.filter((({
                xpath: e
            }) => !na().includes(e)))
        };
    let sa = [];
    const ua = e => {
            sa.push(...e)
        },
        ca = () => sa,
        da = e => {
            const t = UserWayWidgetApp.getLib("inlineStyling");
            e.forEach((e => {
                e.setAttribute(jo, Vo.PARSED), t.resetInlineStyles(e, jo, qo)
            }))
        },
        pa = e => {
            if (!e) return ["0", "0", "0", "0", "rgba(0,0,0,0)"];
            const t = e.replace(/[^\d,.]/g, "").split(",");
            return t[3] || (t[3] = "1"), t[4] = e, t
        },
        ma = e => {
            const {
                color: t
            } = getComputedStyle(e);
            return pa(t)
        },
        ga = e => {
            const t = getComputedStyle(e);
            return t.backgroundImage.includes("url") || t.background.includes("url")
        },
        fa = e => e.startsWith("rgba") && e.includes(",") && 0 === parseFloat(e.split(",")[3]) || "transparent" === e,
        ha = e => __async(this, null, (function*() {
            const t = getComputedStyle(e),
                r = document.body === e,
                n = t.background.includes("linear-gradient"),
                i = ga(e),
                o = new RegExp(/rgba?\(((25[0-5]|2[0-4]\d|1\d{1,2}|\d\d?)\s*,\s*?){2}(25[0-5]|2[0-4]\d|1\d{1,2}|\d\d?)\s*,?\s*([01]\.?\d*?)?\)/g);
            if (!r && fa(t.backgroundColor) && !n && !i && e.parentElement) return ha(e.parentElement);
            let a;
            if (n && fa(t.backgroundColor) && (a = (t.background.match(o) || []).find((e => !fa(e)))), i && fa(t.backgroundColor)) {
                if ([".svg"].some((e => t.backgroundImage.includes(e) || t.background.includes(e))) && e.parentElement) return ha(e.parentElement);
                const r = (e => {
                    var t, r;
                    if (null == (t = e.backgroundImage) ? void 0 : t.includes("url")) return e.backgroundImage.slice(4, -1).replace(/['"]/g, "");
                    const n = null == (r = e.background) ? void 0 : r.match(/url\(["']?([^"']*)["']?\)/);
                    return n ? n[1] : null
                })(t);
                try {
                    r && (a = yield(l = r, new Promise(((e, t) => {
                        const r = document.createElement("canvas").getContext("2d");
                        if (!r) return void t(new Error("Unable to get canvas context"));
                        const n = new Image;
                        n.setAttribute("crossOrigin", ""), n.src = l, n.addEventListener("load", (() => {
                            r.imageSmoothingEnabled = !0, r.drawImage(n, 0, 0);
                            const t = r.getImageData(0, 0, 1, 1).data.slice(0, 3);
                            e((e => `rgb(${e.join(",")})`)(t))
                        })), n.addEventListener("error", (e => {
                            console.warn("Image color recognition error:", l), t(e)
                        }))
                    }))))
                } catch (s) {
                    if (e.parentElement) return ha(e.parentElement)
                }
                if ("rgb(0,0,0)" === a && e.parentElement) return ha(e.parentElement)
            }
            var l;
            return a = pa(a || t.backgroundColor), (e => !(parseFloat(e.opacity) < 1 || e.filter && "none" !== e.filter))(t) || (a[3] = ".1"), {
                backgroundColor: a,
                targetElement: e
            }
        })),
        ba = (e, t) => {
            const r = __pow(10, t || 0);
            return Math.round(e * r) / r
        };
    class Aa {
        constructor(e) {
            const t = [...e];
            "0" === t[3] && (t[3] = "1"), this.rgba = t.map((e => ba(Number(e), 3)))
        }
        get rgb() {
            var e;
            return null == (e = this.rgba) ? void 0 : e.slice(0, 3)
        }
        get alpha() {
            return this.rgba[3]
        }
        set alpha(e) {
            this.rgba[3] = e
        }
        get luminance() {
            const e = this.rgba.slice();
            for (let t = 0; t < 3; t++) {
                let r = e[t];
                r /= 255, r < .03928 ? r /= 12.92 : r = __pow((r + .055) / 1.055, 2.4), e[t] = r
            }
            return .2126 * e[0] + .7152 * e[1] + .0722 * e[2]
        }
        clone() {
            return new Aa(this.rgba)
        }
        isLight() {
            const e = (this.luminance + .05) / .05;
            return 1.05 / (this.luminance + .05) < e
        }
        overlayOn(e) {
            const t = this.clone(),
                r = this.alpha;
            if (r >= 1) return t;
            for (let n = 0; n < 3; n++) t.rgba[n] = t.rgba[n] * r + e.rgba[n] * e.rgba[3] * (1 - r);
            return t.rgba[3] = r + e.rgba[3] * (1 - r), t
        }
        contrast(e) {
            const t = {
                ratio: null
            };
            if (this.alpha < 1) return t;
            let r = e;
            e.alpha < 1 && (r = e.overlayOn(this));
            const n = this.luminance + .05,
                i = r.luminance + .05,
                o = n / i;
            return t.ratio = i > n ? 1 / o : o, t
        }
    }
    const ya = e => 72 * Number(e.substring(0, e.length - 2)) / 96,
        Ea = (e, t) => e >= 18 || e >= 14 && ("bold" === t || parseInt(t, 10) >= 700),
        va = e => {
            if (String(e).includes(".")) {
                const t = String(e).split(".");
                return 1 === t.length ? Number(e) : Number(`${t[0]}.${t[1].charAt(0)}${t[1].charAt(1)}`)
            }
            return Number(e)
        },
        _a = (e, t, r, n) => {
            const i = {
                    ratio: null,
                    contrastRatio: null
                },
                o = new Aa(t),
                a = new Aa(r),
                l = o.contrast(a),
                {
                    ratio: s
                } = l;
            if (!s) return;
            i.ratio = Number(s), i.contrastRatio = `${s}:1`;
            const u = window.getComputedStyle(e),
                c = u.getPropertyValue("font-size"),
                d = u.getPropertyValue("font-weight"),
                p = ya(c),
                m = ((e, t) => {
                    if (Zo()) {
                        if (e && t < 4.5) return 4.5;
                        if (t < 7) return 7
                    }
                    return e && t < 3 ? 3 : t < 4.5 ? 4.5 : null
                })(Ea(p, d), s);
            return m ? {
                contrastData: {
                    passRatio: m,
                    ratio: va(i.ratio),
                    foreground: t,
                    background: r,
                    backgroundColorParentElement: n
                },
                isLightFg: o.isLight(),
                isLightBg: a.isLight(),
                expectedRatio: m,
                tagName: e.tagName,
                xpath: f(e),
                fontSize: p
            } : void 0
        },
        wa = e => __async(this, null, (function*() {
            return (yield Promise.all(e.map((e => __async(this, null, (function*() {
                ca().map((({
                    xpath: e
                }) => e)).includes(f(e)) || e.setAttribute(jo, Vo.PARSED);
                const t = ma(e);
                let {
                    backgroundColor: r,
                    targetElement: n
                } = yield ha(e);
                if (t.join("") === r.join("")) return null;
                return "0" === r[3] && (r = ["255", "255", "255", "1", "rgb(255, 255, 255)"]), ga(n) && (n = e), _a(e, t, r, n)
            })))))).filter((e => null != e))
        }));
    class Ta {
        constructor() {
            this.D65 = [95.047, 100, 108.883]
        }
        rgbToXyz(e) {
            const [t, r, n] = e.map((e => e / 255)).map(this.sRGBtoLinearRGB);
            return [.4124 * t + .3576 * r + .1805 * n, .2126 * t + .7152 * r + .0722 * n, .0193 * t + .1192 * r + .9505 * n].map((e => 100 * e))
        }
        sRGBtoLinearRGB(e) {
            return e <= .04045 ? e / 12.92 : __pow((e + .055) / 1.055, 2.4)
        }
        xyzToLab([e, t, r]) {
            const [n, i, o] = [e, t, r].map(((e, t) => {
                const r = e / this.D65[t];
                return r > .008856 ? __pow(r, 1 / 3) : 7.787 * r + 16 / 116
            }));
            return [116 * i - 16, 500 * (n - i), 200 * (i - o)]
        }
        findL(e) {
            return 116 * __pow(e, 1 / 3) - 16
        }
        labToRgb(e) {
            let t, r, n, i = (e[0] + 16) / 116,
                o = e[1] / 500 + i,
                a = i - e[2] / 200;
            return o = .95047 * (o * o * o > .008856 ? o * o * o : (o - 16 / 116) / 7.787), i = 1 * (i * i * i > .008856 ? i * i * i : (i - 16 / 116) / 7.787), a = 1.08883 * (a * a * a > .008856 ? a * a * a : (a - 16 / 116) / 7.787), t = 3.2406 * o + -1.5372 * i + -.4986 * a, r = -.9689 * o + 1.8758 * i + .0415 * a, n = .0557 * o + -.204 * i + 1.057 * a, t = t > .0031308 ? 1.055 * __pow(t, 1 / 2.4) - .055 : 12.92 * t, r = r > .0031308 ? 1.055 * __pow(r, 1 / 2.4) - .055 : 12.92 * r, n = n > .0031308 ? 1.055 * __pow(n, 1 / 2.4) - .055 : 12.92 * n, [255 * Math.max(0, Math.min(1, t)), 255 * Math.max(0, Math.min(1, r)), 255 * Math.max(0, Math.min(1, n))].map((e => ba(e)))
        }
    }
    const Na = (e, t, r, n = !1) => {
            const i = new Ta,
                o = new Aa(e),
                a = new Aa(t),
                l = (() => {
                    const e = o.isLight(),
                        t = a.isLight();
                    if (e && t || !e && !t) {
                        if (o.luminance === a.luminance) {
                            const t = 0 === o.luminance,
                                r = 1 === o.luminance;
                            return !(!t || !n) || (!r || !n) && e
                        }
                        return o.luminance > a.luminance
                    }
                    return e
                })(),
                s = ((e = 4.5, t, r) => {
                    let n, i = 0;
                    return i = r ? (e + .05) * (t + .05) - .05 : (t + .05) / e - .05, n = i < 0 ? 0 : i > 1 ? 1 : i, n
                })(r, a.luminance, l),
                u = e.slice(0, 3).map(Number),
                c = i.rgbToXyz(u),
                [, d, p] = i.xyzToLab(c),
                m = i.findL(s) + (l ? 1 : -1);
            return `rgb(${i.labToRgb([m,d,p]).join(",")})`
        },
        xa = e => {
            let t = [];
            ((e, t) => {
                let r; {
                    const e = t.split(".");
                    r = e.length > 1 ? t => e.reduce(((e, t) => {
                        if (e && "object" == typeof e && t in e) return e[t]
                    }), t) : e => e[t]
                }
                return e.reduce(((e, t) => {
                    const n = r(t),
                        i = e.get(n) || [];
                    return e.set(n, [...i, t]), e
                }), new Map)
            })(e, "contrastData.backgroundColorParentElement").forEach(((e, r) => {
                const [n, ...i] = e;
                !i.length || i.every((e => e.contrastData.foreground[4] === n.contrastData.foreground[4])) ? t.push(__spreadProps(__spreadValues({}, n), {
                    tagName: r.tagName,
                    xpath: f(r),
                    childrenIssues: e.map((e => e.xpath))
                })) : t = t.concat(e)
            }));
            return t.map((e => {
                const {
                    expectedRatio: t,
                    contrastData: {
                        foreground: r,
                        background: n
                    }
                } = e;
                let i = n[4];
                const o = new Aa(n),
                    a = Na(r, n, t),
                    l = pa(a),
                    s = new Aa(l),
                    {
                        ratio: u
                    } = s.contrast(o);
                return u && u < t && (i = Na(n, l, t, !0)), __spreadProps(__spreadValues({}, e), {
                    suggestion: {
                        foreground: a,
                        background: i
                    }
                })
            }))
        },
        Ia = e => e.map((e => __spreadProps(__spreadValues({}, e), {
            contrastData: __spreadProps(__spreadValues({}, e.contrastData), {
                backgroundColorParentElement: null
            })
        }))),
        La = (e, t, r, n = !0) => __async(this, null, (function*() {
            var i;
            const o = UserWayWidgetApp.getLib("inlineStyling"),
                a = null == (i = t.childrenIssues) ? void 0 : i.map((e => I(e))).filter((e => !!e && "boolean" != typeof e)),
                {
                    background: l,
                    foreground: s
                } = t,
                u = aa(),
                c = [];
            if (null == a ? void 0 : a.length) o.applyInlineStyles(e, jo, {
                background: l
            }), e.setAttribute(jo, r ? Vo.AUTOFIX : Vo.SET), a.forEach(((e, n) => {
                o.applyInlineStyles(e, jo, {
                    color: s
                }), null == e || e.setAttribute(jo, r ? Vo.AUTOFIX : Vo.SET), c.push(__spreadProps(__spreadValues({}, t), {
                    xpath: t.childrenIssues ? t.childrenIssues[n] : t.xpath
                }))
            }));
            else {
                const n = {
                    color: s,
                    background: l
                };
                o.applyInlineStyles(e, jo, n), e.setAttribute(jo, r ? Vo.AUTOFIX : Vo.SET), c.push(t)
            }
            if (!r && n) {
                ra(c);
                const e = na(),
                    t = u.filter((({
                        xpath: t
                    }) => e.includes(t)));
                ua(t), la()
            }!Zo() && r && (j.contrast.config.autofix = !0)
        })),
        Sa = (e, t, r) => {
            wa(e).then((e => {
                var r, n;
                if (e) {
                    const i = xa(e);
                    if (oa(i), la(), (() => {
                            var e;
                            if (!(null == (e = null == j ? void 0 : j.contrast) ? void 0 : e.enabled)) return;
                            const t = UserWayWidgetApp.getLib("remediation_manager"),
                                r = UserWayWidgetApp.getLib("remediation_helper_outcome");
                            if (!r.of) return;
                            const n = aa(),
                                i = n.concat(ca()),
                                o = r.of(Ho, {
                                    items: Ia(i),
                                    acceptedFixes: na(),
                                    autofix: j.contrast.config.autofix
                                }, null, n.length, 0);
                            t.HelperCallbackAggregator.onHelperRemediationCompleted(o)
                        })(), t)
                        for (const e of i) {
                            const t = I(e.xpath);
                            if (t) {
                                const i = {
                                    xpath: e.xpath,
                                    background: (null == (r = e.suggestion) ? void 0 : r.background) || "",
                                    foreground: (null == (n = e.suggestion) ? void 0 : n.foreground) || "",
                                    childrenIssues: e.childrenIssues
                                };
                                La(t, i, !0)
                            }
                        }
                }
            }))
        },
        Ca = () => {
            const e = UserWayWidgetApp.getLib("inlineStyling"),
                t = Object.keys(Vo).map((e => Vo[e])).filter((e => e !== Vo.SET)).map((e => `[${jo}=${e}]`)).join(", ");
            [].slice.call(document.querySelectorAll(t)).forEach((t => {
                t.getAttribute(jo) === Vo.AUTOFIX && e.resetInlineStyles(t, jo, qo), t.removeAttribute(jo)
            })), ia = []
        },
        Oa = () => {
            Ca(), Yo(!1), Jo(!1), ca().forEach((e => {
                var t, r;
                const n = L(e.xpath);
                if (n) {
                    const i = {
                        xpath: e.xpath,
                        background: (null == (t = e.suggestion) ? void 0 : t.background) || "",
                        foreground: (null == (r = e.suggestion) ? void 0 : r.foreground) || "",
                        childrenIssues: e.childrenIssues
                    };
                    La(n, i, !1)
                }
            }))
        },
        Ra = (e, t) => __async(this, [e, t], (function*(e, {
            background: t,
            foreground: r,
            xpath: n,
            childrenIssues: i
        }) {
            const o = ma(e),
                {
                    backgroundColor: a,
                    targetElement: l
                } = yield ha(e);
            let s = l;
            ga(s) && (s = e);
            const u = window.getComputedStyle(e),
                c = u.getPropertyValue("font-size"),
                d = u.getPropertyValue("font-weight"),
                p = ya(c),
                m = Ea(p, d) ? 3 : 4.5;
            return {
                contrastData: {
                    passRatio: m,
                    ratio: m,
                    foreground: o,
                    background: a,
                    backgroundColorParentElement: s
                },
                suggestion: {
                    foreground: r,
                    background: t
                },
                expectedRatio: m,
                tagName: e.tagName,
                xpath: n,
                fontSize: p,
                childrenIssues: i
            }
        })),
        ka = () => __async(this, null, (function*() {
            const {
                Contrast: e
            } = Y();
            e.length && !ea && (ea = !0, ra(e), e.map((e => __async(this, null, (function*() {
                const t = e.xpath && I(e.xpath);
                if (!t) return;
                La(t, e, !1, !1);
                const r = yield Ra(t, e);
                ua([r])
            })))))
        })),
        Da = wr({
            ruleId: Ho,
            rule: ({
                context: {
                    elements: e
                }
            }) => {
                var t;
                const {
                    config: r,
                    enabled: n
                } = null != (t = null == j ? void 0 : j.contrast) ? t : {};
                (e => {
                    Go.push(...e)
                })(e);
                const i = Boolean(q["userway-s18"].value);
                Yo(i), n && ka(), ((null == r ? void 0 : r.autofix) && n || i) && (Jo(!0), Sa(e, !0))
            },
            isTargetElement: e => {
                if (e.hasAttribute(jo)) return !1;
                if (e.hasAttribute("data-uw-rm-ignore")) return !1;
                const {
                    tagName: t
                } = e;
                return !Fo.includes(t) && (("INPUT" !== t || !Xo.includes(e.type)) && (e => !!Array.from(e.childNodes).some((({
                    nodeType: e,
                    nodeValue: t
                }) => e === Node.TEXT_NODE && t && -1 === (null == t ? void 0 : t.search(/^\s+$/i)))) || e instanceof HTMLInputElement || e instanceof HTMLSelectElement && e.options.length > 0 || !!(e instanceof HTMLInputElement && ["reset", "submit"].includes(e.type)))(e))
            },
            postMessageApi: {
                "enable-color-contrast": () => {
                    var e;
                    if ((null == (e = null == j ? void 0 : j.contrast) ? void 0 : e.enabled) && (Zo() && Oa(), !Qo)) {
                        Jo(!0);
                        const e = zo();
                        Sa(e, !1)
                    }
                },
                "enable-smart-contrast": () => {
                    Ca(), Yo(!0), Jo(!0), Sa(zo(), !0)
                },
                "disable-smart-contrast": Oa,
                "fix-color-contrast": e => {
                    e.forEach((e => {
                        const t = I(e.xpath);
                        t && La(t, e, !1)
                    }))
                },
                "fix-all-color-contrast": () => {
                    aa().forEach((e => {
                        var t, r;
                        const n = I(e.xpath);
                        n && !(e => {
                            const t = e.getAttribute(jo);
                            return null !== t && [Vo.AUTOFIX, Vo.SET].includes(t)
                        })(n) && La(n, {
                            xpath: e.xpath,
                            background: (null == (t = e.suggestion) ? void 0 : t.background) || "",
                            foreground: (null == (r = e.suggestion) ? void 0 : r.foreground) || "",
                            childrenIssues: e.childrenIssues
                        }, !0)
                    })), j.contrast.config.autofix = !0
                },
                "reset-all": () => {
                    const e = [...document.querySelectorAll(`[${jo}]`)];
                    da(e), ta.length = 0, oa(ca()), sa = []
                },
                "reset-autofixed": () => {
                    j.contrast.config.autofix = !1;
                    const e = [].slice.call(document.querySelectorAll(`[${jo}=${Vo.AUTOFIX}]`));
                    da(e)
                }
            }
        }),
        Ma = [
            [xi, di, ei, _i, jn, Zi, uo, Da, Lo, ko, No],
            [$i, si, Vi, fo, Uo],
            [Xr, $o]
        ],
        Pa = Object.freeze(Object.defineProperty({
            __proto__: null,
            RulesGroups: Ma,
            RulesGroupsOnce: []
        }, Symbol.toStringTag, {
            value: "Module"
        })),
        Ua = [
            [Da]
        ],
        Wa = (Symbol.toStringTag, [jn]),
        Ba = [Wa];
    Symbol.toStringTag
}();