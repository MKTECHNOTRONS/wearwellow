! function() {
    function e(e) {
        setTimeout(function() {
            r.totalProcessed.AUTOFOCUS_ON_LOAD = 0, t(e), window.addEventListener("popstate", t, !1)
        }, 1500)
    }

    function t(e) {
        var t = document.activeElement;
        t && ["INPUT", "TEXTAREA"].includes(t.tagName) ? (t.blur(), t.setAttribute(r.DATA_ATTRIBUTE_NAME, "autofocus"), o = 1) : o = 0, r.totalProcessed.AUTOFOCUS_ON_LOAD = o, 0 !== o && UserWayWidgetApp.ContextHolder.config.services.siteId, e({
            postMessageAppData: o,
            backEndData: null,
            countFixed: o || 0,
            countTodo: o || 0
        })
    }
    var n = UserWayWidgetApp.addLib("REMEDIATION_AUTOFOCUS_ON_LOAD"),
        r = UserWayWidgetApp.getLib("remediation"),
        o = (UserWayWidgetApp.getLib("util"), 0);
    n.filter = function(e) {
        return []
    }, n.awaitForResources = function(e, t) {
        return Promise.resolve()
    }, n.doRemediation = function(t, n) {
        return new Promise(function(t, n) {
            try {
                e(t)
            } catch (e) {
                n(e)
            }
        })
    }
}(),
function() {
    function e() {
        var e = UserWayWidgetApp.ContextHolder.config,
            t = e._userway_config.hasOwnProperty("ai_custom_focus_style_enabled");
        return t ? t && (!0 === e._userway_config.ai_custom_focus_style_enabled || "true" === e._userway_config.ai_custom_focus_style_enabled) : l.enabled
    }

    function t(e) {
        var t = {
            outline: l.outlineWidth + " " + l.outlineStyle + " " + l.outlineColor
        };
        return t["outline-offset"] = "-" + l.outlineWidth, t
    }

    function n(e) {
        if ("function" == typeof e.hasAttribute && e.hasAttribute(c)) {
            var n = window.getComputedStyle(e),
                r = t(n);
            s.resetInlineStyles(e, c, r), e.removeAttribute(c)
        }
    }

    function r(e) {
        e.target && p && u.addStyles(e.target)
    }

    function o(e) {
        var t = e ? "addEventListener" : "removeEventListener";
        document[t]("mousedown", i), document[t]("keydown", a), document[t]("focusin", r), document[t]("focusout", m)
    }

    function i() {
        p = !1
    }

    function a() {
        p = !0
    }
    var u = UserWayWidgetApp.addLib("REMEDIATION_FOCUS_STYLE"),
        l = UserWayWidgetApp.getLib("remediationConfig").customFocus,
        s = UserWayWidgetApp.getLib("inlineStyling"),
        d = UserWayWidgetApp.getLib("remediation_utils"),
        c = "data-uw-rm-outline",
        f = {
            width: "2px",
            color: " #0018FF",
            style: "solid"
        },
        p = !1;
    u.apply = function() {
        var t, n, r, i;
        if (e()) {
            var a = null === (r = null === (n = null === (t = UserWayWidgetApp.ContextHolder) || void 0 === t ? void 0 : t.config) || void 0 === n ? void 0 : n.tunings) || void 0 === r ? void 0 : r.widget_color,
                u = (null === (i = UserWayWidgetApp.getLib("remediationConfig").customFocus.config) || void 0 === i ? void 0 : i.style) ? JSON.parse(UserWayWidgetApp.getLib("remediationConfig").customFocus.config.style) : f;
            l.outlineWidth = u.width, l.outlineColor = u.color || a, l.outlineStyle = u.style, setTimeout(function() {
                o(!0)
            }, 500)
        }
    }, u.getFocusStyle = function() {
        return {
            enabled: e(),
            outlineWidth: l.outlineWidth || f.width,
            outlineColor: l.outlineColor || f.color,
            outlineStyle: l.outlineStyle || f.style
        }
    }, u.updateOutlineStyle = function(e) {
        if (e.data && (e.data.update || null != e.data.enabled)) {
            var t = e.data.update,
                r = e.data.enabled;
            l.outlineWidth = t.width, l.outlineStyle = t.style, l.outlineColor = t.color, l.enabled !== r && (o(l.enabled), [].slice.call(document.querySelectorAll("[" + c + "]")).forEach(function(e) {
                n(e)
            }), l.enabled = r)
        }
    }, u.addStyles = function(e) {
        if (!e.hasAttribute(d.ignoreElementFromHelperProcessingAttr)) {
            var n = window.getComputedStyle(e),
                r = t(n);
            s.applyInlineStyles(e, c, r), e.setAttribute(c, "")
        }
    };
    var m = function(e) {
        e.target && n(e.target)
    }
}();
var __read = this && this.__read || function(e, t) {
        var n = "function" == typeof Symbol && e[Symbol.iterator];
        if (!n) return e;
        var r, o, i = n.call(e),
            a = [];
        try {
            for (;
                (void 0 === t || t-- > 0) && !(r = i.next()).done;) a.push(r.value)
        } catch (e) {
            o = {
                error: e
            }
        } finally {
            try {
                r && !r.done && (n = i.return) && n.call(i)
            } finally {
                if (o) throw o.error
            }
        }
        return a
    },
    __spreadArray = this && this.__spreadArray || function(e, t, n) {
        if (n || 2 === arguments.length)
            for (var r, o = 0, i = t.length; o < i; o++) !r && o in t || (r || (r = Array.prototype.slice.call(t, 0, o)), r[o] = t[o]);
        return e.concat(r || Array.prototype.slice.call(t))
    },
    __values = this && this.__values || function(e) {
        var t = "function" == typeof Symbol && Symbol.iterator,
            n = t && e[t],
            r = 0;
        if (n) return n.call(e);
        if (e && "number" == typeof e.length) return {
            next: function() {
                return e && r >= e.length && (e = void 0), {
                    value: e && e[r++],
                    done: !e
                }
            }
        };
        throw new TypeError(t ? "Object is not iterable." : "Symbol.iterator is not defined.")
    };
! function() {
    function e(e) {
        var t = __spreadArray(__spreadArray(["a"], __read(s), !1), __read(s.map(function(e) {
            return '[role="' + e + '"]'
        })), !1).join(",");
        return e.querySelectorAll(t).length > 0
    }

    function t(t) {
        return t.filter(function(t) {
            var n, r, o, a, m, y, h, g;
            if ("function" == typeof t.hasAttribute && t.hasAttribute(u) || e(t)) return !1;
            if (t.classList && t.classList.contains("betterbot_botInfoText")) return t.setAttribute(u, l.BETTERBOT_CHAT), !0;
            if ("function" == typeof t.getAttribute && s.indexOf(t.getAttribute("role")) > -1 && !t.hasAttribute("tabindex")) return t.setAttribute(u, l.HAS_ROLE_NO_TABINDEX), !0;
            var v = !1,
                b = !1;
            if ("function" == typeof t.hasAttribute) try {
                for (var A = __values(d), _ = A.next(); !_.done; _ = A.next()) {
                    var E = _.value;
                    if (t.hasAttribute(E) && !i.isElementEditable(t)) {
                        b = !1, v = !0;
                        try {
                            for (var w = (o = void 0, __values(c)), S = w.next(); !S.done; S = w.next()) {
                                var O = S.value;
                                t.hasAttribute(O) && (b = !0)
                            }
                        } catch (e) {
                            o = {
                                error: e
                            }
                        } finally {
                            try {
                                S && !S.done && (a = w.return) && a.call(w)
                            } finally {
                                if (o) throw o.error
                            }
                        }
                    }
                }
            } catch (e) {
                n = {
                    error: e
                }
            } finally {
                try {
                    _ && !_.done && (r = A.return) && r.call(A)
                } finally {
                    if (n) throw n.error
                }
            }
            if (v && !b) return t.setAttribute(u, l.HAS_ONCLICK_NO_ONKEYPRESS), !0;
            var x = !1,
                W = !1,
                C = !1,
                N = ["drag-and-drop"];
            if ("function" == typeof t.hasAttribute) {
                C = t.hasAttribute("tabindex");
                try {
                    for (var L = __values(f), R = L.next(); !R.done; R = L.next()) {
                        var E = R.value;
                        if (N.indexOf(t.nodeName.toLowerCase()) < 0 && t.hasAttribute(E) && !i.isElementEditable(t)) {
                            W = !1, x = !0;
                            try {
                                for (var k = (h = void 0, __values(p)), P = k.next(); !P.done; P = k.next()) {
                                    var O = P.value;
                                    t.hasAttribute(O) && (W = !0)
                                }
                            } catch (e) {
                                h = {
                                    error: e
                                }
                            } finally {
                                try {
                                    P && !P.done && (g = k.return) && g.call(k)
                                } finally {
                                    if (h) throw h.error
                                }
                            }
                        }
                    }
                } catch (e) {
                    m = {
                        error: e
                    }
                } finally {
                    try {
                        R && !R.done && (y = L.return) && y.call(L)
                    } finally {
                        if (m) throw m.error
                    }
                }
            }
            return !x || W || C ? !("A" !== t.tagName || t.href || t.hasAttribute("tabindex") || t.hasAttribute("role")) && (t.setAttribute(u, l.ANCHOR_NO_HREF), !0) : (t.setAttribute(u, l.HAS_NGCLICK_NO_NGKEYPRESS), !0)
        })
    }

    function n(e, t, n, r, a) {
        try {
            e.onHelperRemediationStarted("REMEDIATION_KEYBOARD_NAVIGATION");
            var s = 0;
            r.forEach(function(e) {
                var t = e.getAttribute(u);
                if (t) return s++, t === l.BETTERBOT_CHAT ? (e.setAttribute("tabindex", "0"), e.setAttribute("role", "button"), e.setAttribute("aria-label", "Start chat with us"), void i.clickOnEnter(e)) : t === l.HAS_ROLE_NO_TABINDEX ? (e.setAttribute("tabindex", "0"), void i.clickOnEnter(e)) : t === l.OVERFLOW_HELPER ? void e.setAttribute("tabindex", "0") : t === l.HAS_ONCLICK_NO_ONKEYPRESS ? void i.clickOnEnter(e) : t && e.getAttribute(u) === l.HAS_NGCLICK_NO_NGKEYPRESS ? (e.setAttribute("role", "button"), e.setAttribute("tabindex", "0"), void i.clickOnEnter(e)) : t === l.ANCHOR_NO_HREF ? (e.setAttribute("tabindex", "0"), void("pointer" === window.getComputedStyle(e).cursor && i.clickOnEnter(e))) : void 0
            }), e.onHelperRemediationCompleted(o.of("REMEDIATION_KEYBOARD_NAVIGATION", null, null, s, 0)), t()
        } catch (e) {
            n(e)
        }
    }
    var r = UserWayWidgetApp.addLib("REMEDIATION_KEYBOARD_NAVIGATION"),
        o = UserWayWidgetApp.getLib("remediation_helper_outcome"),
        i = UserWayWidgetApp.getLib("remediation_util"),
        a = UserWayWidgetApp.getLib("util"),
        u = "data-uw-rm-kbnav",
        l = {
            BETTERBOT_CHAT: "betterbot",
            HAS_ROLE_NO_TABINDEX: "role",
            HAS_ONCLICK_NO_ONKEYPRESS: "click",
            HAS_NGCLICK_NO_NGKEYPRESS: "ngclick",
            OVERFLOW_HELPER: "scrollTabIndex",
            ANCHOR_NO_HREF: "anohref"
        },
        s = ["link", "button", "menuitem", "checkbox"],
        d = ["onclick"],
        c = ["onkeydown", "onkeyup", "onkeypress"],
        f = ["ng-click"],
        p = ["ng-keypress", "ng-keyup", "ng-keydown"];
    r.filter = function(e, n) {
        return n.reset, t([].concat.apply([], __spreadArray([], __read(e.map(function(e) {
            return [].slice.call(a.findAllElements(e))
        })), !1)))
    }, r.awaitForResources = function(e, t) {
        return Promise.resolve()
    }, r.doRemediation = function(e, t, r) {
        return new Promise(function(o, i) {
            n(e, o, i, t, r)
        })
    }
}();
var __values = this && this.__values || function(e) {
    var t = "function" == typeof Symbol && Symbol.iterator,
        n = t && e[t],
        r = 0;
    if (n) return n.call(e);
    if (e && "number" == typeof e.length) return {
        next: function() {
            return e && r >= e.length && (e = void 0), {
                value: e && e[r++],
                done: !e
            }
        }
    };
    throw new TypeError(t ? "Object is not iterable." : "Symbol.iterator is not defined.")
};
! function() {
    function e(e) {
        window.userwayLabs && window.userwayLabs.remediate(e)
    }
    var t = UserWayWidgetApp.addLib("REMEDIATION_LABS"),
        n = UserWayWidgetApp.getLib("remediationConfig"),
        r = UserWayWidgetApp.getLib("util");
    t.apply = function() {
        var t, o, i;
        try {
            (null === (t = n.labs) || void 0 === t ? void 0 : t.enabled) && Object.keys(null !== (i = null === (o = n.labs) || void 0 === o ? void 0 : o.config) && void 0 !== i ? i : []).length > 0 && r.execJs("https://cdn.userway.org/widgetapp/2025-04-07-09-19-51/bundles/labs-02.js").finally(function() {
                setTimeout(function() {
                    var t, r, o = n.labs.config;
                    try {
                        for (var i = __values(o), a = i.next(); !a.done; a = i.next()) {
                            e(a.value)
                        }
                    } catch (e) {
                        t = {
                            error: e
                        }
                    } finally {
                        try {
                            a && !a.done && (r = i.return) && r.call(i)
                        } finally {
                            if (t) throw t.error
                        }
                    }
                }, 100)
            })
        } catch (e) {
            console.info("LabsRemediationLoader", e)
        }
    }
}(),
function() {
    var e = UserWayWidgetApp.addLib("REMEDIATION_PER_SITE"),
        t = UserWayWidgetApp.getLib("remediationConfig"),
        n = UserWayWidgetApp.getLib("util");
    e.apply = function() {
        var e, r, o, i, a;
        (null === (e = t.perSiteRemediation) || void 0 === e ? void 0 : e.enabled) && "v2" !== (null === (i = null === (o = null === (r = UserWayWidgetApp.ContextHolder) || void 0 === r ? void 0 : r.config) || void 0 === o ? void 0 : o.tunings) || void 0 === i ? void 0 : i.csrVersion) && (null === (a = t.perSiteRemediation) || void 0 === a ? void 0 : a.resources) && n.execJs(t.perSiteRemediation.resources).finally(function() {
            n.fireUserWayLifeCycleEvent(n.LIFE_CYCLE_EVENT.REMEDIATION_CSR_LOADED)
        })
    }
}();
var __read = this && this.__read || function(e, t) {
        var n = "function" == typeof Symbol && e[Symbol.iterator];
        if (!n) return e;
        var r, o, i = n.call(e),
            a = [];
        try {
            for (;
                (void 0 === t || t-- > 0) && !(r = i.next()).done;) a.push(r.value)
        } catch (e) {
            o = {
                error: e
            }
        } finally {
            try {
                r && !r.done && (n = i.return) && n.call(i)
            } finally {
                if (o) throw o.error
            }
        }
        return a
    },
    __values = this && this.__values || function(e) {
        var t = "function" == typeof Symbol && Symbol.iterator,
            n = t && e[t],
            r = 0;
        if (n) return n.call(e);
        if (e && "number" == typeof e.length) return {
            next: function() {
                return e && r >= e.length && (e = void 0), {
                    value: e && e[r++],
                    done: !e
                }
            }
        };
        throw new TypeError(t ? "Object is not iterable." : "Symbol.iterator is not defined.")
    },
    __spreadArray = this && this.__spreadArray || function(e, t, n) {
        if (n || 2 === arguments.length)
            for (var r, o = 0, i = t.length; o < i; o++) !r && o in t || (r || (r = Array.prototype.slice.call(t, 0, o)), r[o] = t[o]);
        return e.concat(r || Array.prototype.slice.call(t))
    };
! function() {
    var e = UserWayWidgetApp.addLib("REMEDIATION_POPUP"),
        t = UserWayWidgetApp.getLib("remediation_util"),
        n = UserWayWidgetApp.getLib("event_emitter"),
        r = UserWayWidgetApp.getLib("util");
    e.apply = function() {
        n.on("UW_CER_POPUP_ON", function(e) {
            var n = __read(e, 2),
                o = n[0],
                i = n[1];
            ! function(e, n) {
                setTimeout(function() {
                    var o, i;
                    t.clickOnEnter(n);
                    var a = Array.from(e.querySelectorAll(t.focusableElementsSelector)).filter(function(e) {
                        return n !== e && t.isElementVisible(e, {
                            skipParentCheck: !0
                        }) && !e.hasAttribute("data-uw-rm-ignore")
                    });
                    try {
                        for (var u = __values(a), l = u.next(); !l.done; l = u.next()) {
                            var s = l.value;
                            s.setAttribute("tabindex", "0"), t.clickOnEnter(s)
                        }
                    } catch (e) {
                        o = {
                            error: e
                        }
                    } finally {
                        try {
                            l && !l.done && (i = u.return) && i.call(u)
                        } finally {
                            if (o) throw o.error
                        }
                    }
                    if (a.length) {
                        null === n || void 0 === n || n.setAttribute("tabindex", "0");
                        var d = n ? __spreadArray([n], __read(a), !1) : a;
                        t.trapFocusPopupElements(d, e)
                    } else n && (n.addEventListener("keydown", function(e) {
                        t.keys.isTab(e) && e.preventDefault()
                    }), n.focus());
                    if (e.addEventListener("keydown", function(e) {
                            t.keys.isEsc(e) && n.click()
                        }), n) {
                        r.customTrim(n.textContent).length < 3 && !n.hasAttribute("aria-label") && !n.hasAttribute("aria-labelledby") && n.setAttribute("aria-label", "Close dialog"), -1 !== ["INPUT", "BUTTON", "A"].indexOf(n.tagName) || n.hasAttribute("role") || (n.setAttribute("role", "button"), n.setAttribute("tabindex", "0"))
                    }
                }, 1e3)
            }(o, i)
        })
    }
}();
var __values = this && this.__values || function(e) {
    var t = "function" == typeof Symbol && Symbol.iterator,
        n = t && e[t],
        r = 0;
    if (n) return n.call(e);
    if (e && "number" == typeof e.length) return {
        next: function() {
            return e && r >= e.length && (e = void 0), {
                value: e && e[r++],
                done: !e
            }
        }
    };
    throw new TypeError(t ? "Object is not iterable." : "Symbol.iterator is not defined.")
};
! function() {
    function e(e) {
        return !!(e.offsetWidth || e.offsetHeight || e.getClientRects().length)
    }

    function t(e) {
        var t = Array.from(e.children),
            n = t.filter(function(e) {
                return "LI" === e.tagName && !e.hasAttribute("role")
            });
        if (n.length) return n;
        var r = t.filter(function(e) {
            return !e.hasAttribute("role") && (["A", "BUTTON"].includes(e.tagName) || e.hasAttribute("tabindex"))
        });
        return r.length ? r : []
    }

    function n() {
        var n, r, o = 0,
            i = Array.from(document.querySelectorAll('*[role="menu"], *[role="menubar"]'));
        try {
            for (var a = __values(i), u = a.next(); !u.done; u = a.next()) {
                var l = u.value;
                ! function(n) {
                    var r, i;
                    if (!n.hasAttribute(m)) {
                        n.setAttribute(m, "");
                        if (!Array.from(n.querySelectorAll('*[role="menuitem"], *[role="menuitemcheckbox"], *[role="menuitemradio"]')).length) {
                            o++;
                            var a = t(n);
                            try {
                                for (var u = (r = void 0, __values(a)), l = u.next(); !l.done; l = u.next()) {
                                    var s = l.value;
                                    s.setAttribute("role", "menuitem"), s.setAttribute(m, "menuitem")
                                }
                            } catch (e) {
                                r = {
                                    error: e
                                }
                            } finally {
                                try {
                                    l && !l.done && (i = u.return) && i.call(u)
                                } finally {
                                    if (r) throw r.error
                                }
                            }
                            if (!a.length && !e(n)) {
                                var d = n.getAttribute("role");
                                n.setAttribute(m + "-role", d), n.removeAttribute("role"), f.onElementVisible(n, function() {
                                    if (n.hasAttribute(m + "-role")) {
                                        var e = n.getAttribute(m + "-role");
                                        n.removeAttribute(m + "-role"), n.setAttribute("role", e)
                                    }
                                })
                            }
                        }
                    }
                }(l)
            }
        } catch (e) {
            n = {
                error: e
            }
        } finally {
            try {
                u && !u.done && (r = a.return) && r.call(a)
            } finally {
                if (n) throw n.error
            }
        }
        return o
    }

    function r() {
        o("aria-labelledby"), o("aria-describedby")
    }

    function o(e) {
        Array.from(document.querySelectorAll("*[" + m + "-" + e + "]")).forEach(function(t) {
            var n = t.getAttribute(m + "-" + e).split(" "),
                r = [],
                o = [];
            n.forEach(function(e) {
                document.getElementById(e) ? r.push(e) : o.push(e)
            }), r.length && t.setAttribute(e, r.join(" ")), o.length ? o.length !== n.length && t.setAttribute(m + "-" + e, o.join(" ")) : t.removeAttribute(m + "-" + e)
        })
    }

    function i() {
        var e = 0;
        return e += a("aria-labelledby"), e += a("aria-describedby")
    }

    function a(e) {
        var t = 0;
        return Array.from(document.querySelectorAll("*[" + e + "]")).forEach(function(n) {
            if (!n.hasAttribute(m)) {
                var r = n.getAttribute(e).split(" "),
                    o = [],
                    i = [];
                r.forEach(function(e) {
                    document.getElementById(e) ? o.push(e) : i.push(e)
                }), i.length && (n.setAttribute(m + "-" + e, i.join(" ")), o.length ? n.setAttribute(e, o.join(" ")) : n.removeAttribute(e)), t += i.length
            }
        }), t
    }

    function u(e) {
        var t = e.tagName.toLowerCase();
        if ("s" === t || "strike" === t || "del" === t) return !0;
        var n = window.getComputedStyle(e);
        if (!!n.getPropertyValue("text-decoration") && n.getPropertyValue("text-decoration").indexOf("line-through") > -1) return !0;
        var r = e.parentElement;
        return !(!r || "BODY" === r.tagName.toUpperCase()) && u(r)
    }

    function l() {
        var e, t, n = 0,
            r = ["NOSCRIPT", "SCRIPT", "style"],
            o = p.ElementsWithText.getElementsWithText(document, !1),
            i = o.filter(function(e) {
                return !r.includes(e.tagName)
            }),
            a = ["CAPTION", "CODE", "EM", "SUP", "SUB", "INS", "P", "STRONG", "B", "MARK", "I", "U", "CITE", "SUGGESTION", "TERM", "TIME", "SPAN", "DIV", "STRIKE", "S", "DEL"],
            l = ["caption", "code", "emphasis", "superscript", "subscript", "insertion", "paragraph", "strong", "mark", "suggestion", "term", "time", "presentation", "none"];
        try {
            for (var s = __values(i), d = s.next(); !d.done; d = s.next()) {
                var c = d.value;
                if (!c.hasAttribute(m)) {
                    var y = f.customTrim(c.innerText),
                        h = y.match(/(?:[\$\xA2-\xA5\u058F\u060B\u09F2\u09F3\u09FB\u0AF1\u0BF9\u0E3F\u17DB\u20A0-\u20BD\uA838\uFDFC\uFE69\uFF04\uFFE0\uFFE1\uFFE5\uFFE6])(?:[^0-9.]*)([\d,.]+)/);
                    y && h && h.length && (c.setAttribute(m, ""), u(c) && (c.setAttribute("aria-label", "Previous price was " + h[0]), function(e) {
                        var t = e.tagName,
                            n = e.getAttribute("role");
                        return a.includes(t) || l.includes(n)
                    }(c) && c.setAttribute("role", "img"), c.setAttribute(m, "price"), n++))
                }
            }
        } catch (t) {
            e = {
                error: t
            }
        } finally {
            try {
                d && !d.done && (t = s.return) && t.call(s)
            } finally {
                if (e) throw e.error
            }
        }
        return n
    }

    function s() {
        [].slice.call(document.querySelectorAll("[" + m + "]")).forEach(function(e) {
            e.removeAttribute(m)
        })
    }
    var d = UserWayWidgetApp.addLib("REMEDIATION_SCREEN_READER_BASIC"),
        c = UserWayWidgetApp.getLib("remediation_helper_outcome"),
        f = UserWayWidgetApp.getLib("util"),
        p = UserWayWidgetApp.getLib("helpers"),
        m = "data-uw-rm-sr";
    d.filter = function(e, t) {
        return t.reset && s(), []
    }, d.awaitForResources = function() {
        return Promise.resolve()
    }, d.doRemediation = function(e) {
        return new Promise(function(t, o) {
            try {
                e.onHelperRemediationStarted("REMEDIATION_SCREEN_READER_BASIC");
                var a = l();
                r();
                var u = i(),
                    s = n();
                e.onHelperRemediationCompleted(c.of("REMEDIATION_SCREEN_READER_BASIC", null, null, a + u + s, 0)), t(!0)
            } catch (e) {
                o(e)
            }
        })
    }
}();
var __read = this && this.__read || function(e, t) {
        var n = "function" == typeof Symbol && e[Symbol.iterator];
        if (!n) return e;
        var r, o, i = n.call(e),
            a = [];
        try {
            for (;
                (void 0 === t || t-- > 0) && !(r = i.next()).done;) a.push(r.value)
        } catch (e) {
            o = {
                error: e
            }
        } finally {
            try {
                r && !r.done && (n = i.return) && n.call(i)
            } finally {
                if (o) throw o.error
            }
        }
        return a
    },
    __spreadArray = this && this.__spreadArray || function(e, t, n) {
        if (n || 2 === arguments.length)
            for (var r, o = 0, i = t.length; o < i; o++) !r && o in t || (r || (r = Array.prototype.slice.call(t, 0, o)), r[o] = t[o]);
        return e.concat(r || Array.prototype.slice.call(t))
    };
! function() {
    function e(e, t) {
        var n = s.config.resources + UserWayWidgetApp.ContextHolder.config.services.siteId + "/" + c.hashString(p);
        c.request({
            method: "GET",
            url: n
        }).then(function(t) {
            if (t && t.response && 404 !== JSON.parse(t.response).code) {
                var n = JSON.parse(t.response);
                y = n.Dictionary, g = n.ContentModeration
            }
            e()
        }, function(e) {
            t(e)
        })
    }

    function t() {
        y = {}, g = [], [].slice.call(document.querySelectorAll("[" + m + "]")).forEach(function(e) {
            e.removeAttribute(m)
        })
    }

    function n(e) {
        return new RegExp("([^A-Za-z0-9_-]|^)" + e.replace(/(\s)/g, "\\s+") + "([^A-Za-z0-9_-]|$)", "gi")
    }

    function r(e) {
        for (var t = Object.keys(y).length; t--;) {
            var n = Object.keys(y)[t],
                r = y[n],
                o = r.t;
            if (e.trim().toLowerCase() === o.trim().toLowerCase()) return n
        }
        throw "Unexpected term: " + e
    }

    function o(e, t, n) {
        for (var r = g.length; r--;) {
            var o = g[r];
            if (o.phraseId + "" === e && o.type === t && o.xpath === n && !o.ignored) return o.correction
        }
        return null
    }

    function i(e, t, n) {
        for (var r = g.length; r--;) {
            var o = g[r];
            if (o.phraseId + "" === e && o.type === t && o.xpath === n && o.ignored) return !0
        }
        return !1
    }

    function a(e, t, a, l, s) {
        try {
            e.onHelperRemediationStarted("REMEDIATION_SOCIAL_SENSITIVITY"), l = l.filter(function(e) {
                var t = e.parentNode;
                return t && "function" != typeof t.hasAttribute || !t.hasAttribute(m)
            });
            var f = 0,
                p = [],
                g = Object.keys(y).map(function(e) {
                    return y[e].t
                });
            l.forEach(function(e) {
                var t = " " + c.customTrim(e.textContent) + " ",
                    a = "INNER_TEXT",
                    l = [];
                if (g.forEach(function(e) {
                        var r = t.match(n(e));
                        r && l.push.apply(l, __spreadArray([], __read(new Array(r.length).fill(e)), !1))
                    }), l && l.length) {
                    f += l.length;
                    for (var s = c.xpath(e.parentElement), d = 0; d < l.length; d++) {
                        for (var y = l[d], v = 0, b = 0; b < d; b++) {
                            l[b].toLowerCase() === y.toLowerCase() && v++
                        }
                        var A = c.hashString(s + y + v) + "",
                            _ = r(y),
                            E = i(_, a, A),
                            w = o(_, a, A),
                            S = !!w || E;
                        S && h++, w && !E && u(e, y, w), e.parentElement.setAttribute(m, ""), p.push({
                            xpath: s,
                            xpathHash: A,
                            type: a,
                            term: y,
                            approved: S,
                            ignored: E,
                            phraseId: _,
                            correction: S ? w : null
                        })
                    }
                }
            }), e.onHelperRemediationCompleted(d.of("REMEDIATION_SOCIAL_SENSITIVITY", {
                items: p
            }, null, f, p.filter(function(e) {
                return !e.correction
            }).length)), t()
        } catch (e) {
            a(e)
        }
    }

    function u(e, t, n) {
        var r = new RegExp(t, "gi"),
            o = e.textContent;
        e.textContent = o.replace(r, n)
    }
    var l = UserWayWidgetApp.addLib("REMEDIATION_SOCIAL_SENSITIVITY"),
        s = UserWayWidgetApp.getLib("remediationConfig").moderator,
        d = UserWayWidgetApp.getLib("remediation_helper_outcome"),
        c = UserWayWidgetApp.getLib("util"),
        f = UserWayWidgetApp.getLib("helpers"),
        p = location.pathname,
        m = "data-uw-rm-mod",
        y = {},
        h = 0,
        g = [];
    l.filter = function(e, n) {
        return s.enabled ? (n.reset && t(), f.ElementsWithText.getTextNodes(document, !1)) : []
    }, l.awaitForResources = function(t, n) {
        return s.enabled && s.config.resources && t.length && n.reset ? new Promise(function(t, n) {
            e(t, n)
        }) : Promise.resolve()
    }, l.doRemediation = function(e, t, n) {
        return new Promise(function(r, o) {
            a(e, r, o, t, n)
        })
    }
}();
var __values = this && this.__values || function(e) {
    var t = "function" == typeof Symbol && Symbol.iterator,
        n = t && e[t],
        r = 0;
    if (n) return n.call(e);
    if (e && "number" == typeof e.length) return {
        next: function() {
            return e && r >= e.length && (e = void 0), {
                value: e && e[r++],
                done: !e
            }
        }
    };
    throw new TypeError(t ? "Object is not iterable." : "Symbol.iterator is not defined.")
};
! function() {
    function e(e) {
        var t = e.checked,
            n = e.readOnly,
            r = e.required,
            o = e.disabled,
            i = e.hidden,
            a = e.getAttribute("aria-checked"),
            u = e.getAttribute("aria-readonly"),
            l = e.getAttribute("aria-required"),
            s = e.getAttribute("aria-disabled"),
            d = e.getAttribute("aria-hidden");
        t && "true" !== a && (e.ariaChecked = !0), t || "false" === a || (e.ariaChecked = !1), n && "true" !== u && (e.ariaReadOnly = !0), n || "false" === u || (e.ariaReadOnly = !1), r && "true" !== l && (e.ariaRequired = !0), r || "false" === l || (e.ariaRequired = !1), o && "true" !== s && (e.ariaDisabled = !0), o || "false" === s || (e.ariaDisabled = !1), i && "true" !== d && (e.ariaHidden = !0), i || "false" === d || (e.ariaHidden = !1)
    }

    function t(t) {
        var n = function(n) {
                var r, o;
                try {
                    for (var i = __values(n), a = i.next(); !a.done; a = i.next()) {
                        "attributes" === a.value.type && e(t)
                    }
                } catch (e) {
                    r = {
                        error: e
                    }
                } finally {
                    try {
                        a && !a.done && (o = i.return) && o.call(i)
                    } finally {
                        if (r) throw r.error
                    }
                }
            },
            r = new MutationObserver(n),
            o = {
                attributes: !0,
                childList: !1,
                subtree: !1
            };
        r.observe(t, o)
    }
    var n = UserWayWidgetApp.addLib("REMEDIATION_ANGULAR_JS_ARIA");
    n.filter = function(e, t) {
        return []
    }, n.awaitForResources = function(e, t) {
        return Promise.resolve()
    }, n.doRemediation = function(n, r, o) {
        var i = document.querySelectorAll("[ng-show], [ng-hide], [ng-value], [ng-checked], [ng-readonly], [ng-required], [ng-model], [ng-disabled]");
        return new Promise(function(n) {
            var r, o;
            try {
                for (var a = __values(Array.from(i)), u = a.next(); !u.done; u = a.next()) {
                    var l = u.value;
                    e(l), t(l)
                }
            } catch (e) {
                r = {
                    error: e
                }
            } finally {
                try {
                    u && !u.done && (o = a.return) && o.call(a)
                } finally {
                    if (r) throw r.error
                }
            }
            n(!0)
        })
    }
}();
var __assign = this && this.__assign || function() {
        return __assign = Object.assign || function(e) {
            for (var t, n = 1, r = arguments.length; n < r; n++) {
                t = arguments[n];
                for (var o in t) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o])
            }
            return e
        }, __assign.apply(this, arguments)
    },
    __values = this && this.__values || function(e) {
        var t = "function" == typeof Symbol && Symbol.iterator,
            n = t && e[t],
            r = 0;
        if (n) return n.call(e);
        if (e && "number" == typeof e.length) return {
            next: function() {
                return e && r >= e.length && (e = void 0), {
                    value: e && e[r++],
                    done: !e
                }
            }
        };
        throw new TypeError(t ? "Object is not iterable." : "Symbol.iterator is not defined.")
    };
! function() {
    var e = UserWayWidgetApp.addLib("remediation_util"),
        t = UserWayWidgetApp.getLib("util");
    e.focusableElementsSelector = "\n    a[href]:not([tabindex='-1']), \n    area[href]:not([tabindex='-1']), \n    audio[controls]:not([tabindex='-1']), \n    button:not([disabled], [tabindex='-1']), \n    details:not([tabindex='-1']) summary:not([tabindex='-1']), \n    input:not([disabled], [type=hidden], [tabindex='-1']), \n    iframe:not([tabindex='-1']), \n    select:not([disabled], [tabindex='-1']), \n    textarea:not([disabled], [tabindex='-1']), \n    video[controls]:not([tabindex='-1']), \n    [tabindex]:not([disabled], [tabindex='-1']), \n    [contenteditable='']:not([disabled], [tabindex='-1']),\n    [contenteditable='true']:not([disabled], [tabindex='-1'])\n  ", e.keys = {
        isRightShift: function(e) {
            return 16 === e.keyCode || "Shift" === e.key || "ShiftRight" === e.code
        },
        isLeftShift: function(e) {
            return 16 === e.keyCode || "Shift" === e.key || "ShiftLeft" === e.code
        },
        isSpace: function(e) {
            return 32 === e.keyCode || " " === e.key || "Space" === e.code
        },
        isEnter: function(e) {
            return 13 === e.keyCode || "Enter" === e.key || "Enter" === e.code
        },
        isEsc: function(e) {
            return 27 === e.keyCode || "Escape" === e.key || "Escape" === e.code
        },
        isTab: function(e) {
            return 9 === e.keyCode || "Tab" === e.key || "Tab" === e.code
        },
        isHome: function(e) {
            return 36 === e.keyCode || "Home" === e.key || "Home" === e.code
        },
        isEnd: function(e) {
            return 35 === e.keyCode || "End" === e.key || "End" === e.code
        },
        isPageUp: function(e) {
            return 33 === e.keyCode || "PageUp" === e.key || "PageUp" === e.code
        },
        isPageDown: function(e) {
            return 34 === e.keyCode || "PageDown" === e.key || "PageDown" === e.code
        },
        isArrowLeft: function(e) {
            return 37 === e.keyCode || "ArrowLeft" === e.key || "ArrowLeft" === e.code
        },
        isArrowUp: function(e) {
            return 38 === e.keyCode || "ArrowUp" === e.key || "ArrowUp" === e.code
        },
        isArrowRight: function(e) {
            return 39 === e.keyCode || "ArrowRight" === e.key || "ArrowRight" === e.code
        },
        isArrowDown: function(e) {
            return 40 === e.keyCode || "ArrowDown" === e.key || "ArrowDown" === e.code
        },
        isPrintableChar: function(e) {
            return 1 === e.key.length && e.key.match(/\S/)
        }
    }, e.log = function(e, t, n) {
        console.warn("UserWay remediation " + e + " - " + t + ": " + n)
    }, e.generateRandomId = t.generateRandomId, e.isElementEditable = function(e) {
        function t(e) {
            var t = e.nodeName.toLowerCase();
            return !!e.hasAttribute("contenteditable") || 1 === e.nodeType && ("textarea" === t || "input" === t && /^(?:text|email|number|search|tel|url|password)$/i.test(e.type))
        }
        var n, r, o = t(e);
        if (o) return !0;
        try {
            for (var i = __values(Array.from(e.querySelectorAll("*"))), a = i.next(); !a.done; a = i.next()) {
                if (o = t(a.value)) break
            }
        } catch (e) {
            n = {
                error: e
            }
        } finally {
            try {
                a && !a.done && (r = i.return) && r.call(i)
            } finally {
                if (n) throw n.error
            }
        }
        return o
    }, e.waitUntil = function(e, t, n, r) {
        void 0 === n && (n = null), void 0 === r && (r = null), n = __assign({
            timeout: 8e3,
            frequency: 1e3
        }, n || {});
        var o = Date.now();
        ! function i() {
            var a = e();
            if (a) return t(a);
            setTimeout(function() {
                if (n.timeout && Date.now() - o > n.timeout) return void(r && r());
                i()
            }, n.frequency)
        }()
    }, e.trapFocusBetweenElements = function(t, n, r) {
        void 0 === r && (r = null);
        var o = !1;
        window.addEventListener("keydown", function(t) {
            e.keys.isLeftShift(t) && (o = !0)
        }), window.addEventListener("keyup", function(t) {
            e.keys.isLeftShift(t) && (o = !1)
        }), t.setAttribute("tabindex", "0"), document.activeElement && r.contains(document.activeElement) || t.focus(), t.addEventListener("keydown", function(t) {
            e.keys.isTab(t) && o && (t.preventDefault(), n.focus())
        }), n.setAttribute("tabindex", "0"), n.addEventListener("keydown", function(n) {
            e.keys.isTab(n) && (o || (n.preventDefault(), t.focus()))
        })
    }, e.trapFocusPopupElements = function(t, n) {
        void 0 === n && (n = null);
        var r = !1;
        window.addEventListener("keydown", function(t) {
            e.keys.isLeftShift(t) && (r = !0)
        }), window.addEventListener("keyup", function(t) {
            e.keys.isLeftShift(t) && (r = !1)
        });
        var o = t[0],
            i = t[t.length - 1];
        document.activeElement && n.contains(document.activeElement) || o.focus(), t.forEach(function(n, a) {
            n.addEventListener("keydown", function(n) {
                e.keys.isTab(n) && (n.preventDefault(), r ? (t[a - 1] ? t[a - 1] : i).focus() : (t[a + 1] ? t[a + 1] : o).focus())
            })
        })
    }, e.trapFocusBetween = function(e) {
        function t(e, t, r) {
            if (9 === r.keyCode) return n ? t && t.focus() : e && e.focus(), r.preventDefault();
            16 === r.keyCode && (n = !0)
        }
        for (var n = !1, r = [], o = 0; o < e.length; o++) {
            var i = document.querySelector(e[o]);
            if (i) {
                i.setAttribute("tabindex", 0);
                var a = document.querySelector(e[o + 1]) || document.querySelector(e[0]),
                    u = document.querySelector(e[o - 1]) || document.querySelector(e[e.length - 1]),
                    l = t.bind(event, a, u);
                r.push(l), i.addEventListener("keydown", l, !1), i.addEventListener("keyup", function(e) {
                    16 === e.keyCode && (n = !1)
                })
            }
        }
        return setTimeout(function() {
            var t = document.querySelector(e[0]);
            t && t.focus()
        }, 100), {
            terminate: function() {
                for (var t = 0; t < e.length; t++) {
                    document.querySelector(e[t]).removeEventListener("keydown", r[t])
                }
            }
        }
    }, e.waitForDocumentReady = function(e) {
        var t = setInterval(function() {
            "complete" === document.readyState && (clearInterval(t), e())
        }, 10)
    }, e.injectStylesheet = function(e) {
        var t = document.createElement("style");
        return t.innerHTML = e, document.head.appendChild(t), t
    }, e.setSrOnly = function(e) {
        if (e.style) {
            var t = {
                overflow: "hidden",
                position: "absolute",
                margin: "0",
                padding: "0",
                width: "1px",
                height: "1px",
                border: "0",
                clip: "rect(1px, 1px, 1px, 1px)",
                "-webkit-clip-path": "inset(50%)",
                "clip-path": "inset(50%)",
                "white-space": "nowrap"
            };
            for (var n in t) e.style.setProperty(n, t[n], "important")
        }
    }, e.createSrOnlyElement = function(t, n) {
        void 0 === t && (t = ""), void 0 === n && (n = "span");
        var r = document.createElement(n);
        return r.textContent = t, e.setSrOnly(r), r
    }, e.isElementVisible = function(e, t) {
        t = t || {}, t.hasOwnProperty("skipParentCheck") || (t.skipParentCheck = !1), t.hasOwnProperty("shouldBeInViewport") || (t.shouldBeInViewport = !0);
        var n = function(e, t) {
                if (!e) return !1;
                if (e === document) return !0;
                var n = getComputedStyle(e),
                    r = e.getBoundingClientRect(),
                    o = r.top >= 0 && r.left >= 0 && r.bottom <= (window.innerHeight || document.documentElement.clientHeight) && r.right <= (window.innerWidth || document.documentElement.clientWidth),
                    i = 0 === r.width || 0 === r.height;
                return (e.offsetWidth > 0 || e.offsetHeight > 0 || e.getClientRects().length > 0) && (!t.shouldBeInViewport || o) && !i && "0" !== n.opacity && "hidden" !== n.visibility && "collapse" !== n.visibility
            },
            r = n(e, t);
        if (!t.skipParentCheck)
            for (; r && e.parentNode && e.parentNode !== document;) n(e.parentNode, {
                shouldBeInViewport: !1
            }) ? e = e.parentNode : r = !1;
        return r
    }, e.fireEvent = function(e, t) {
        if (e.fireEvent) e.fireEvent("on" + t);
        else {
            var n = document.createEvent("Events");
            n.initEvent(t, !0, !1), e.dispatchEvent(n)
        }
    }, e.clickOnEnter = function(t) {
        t && "function" == typeof t.click && !e.isElementEditable(t) && t.addEventListener("keydown", function(n) {
            e.keys.isEnter(n) && (n.preventDefault(), t.click())
        })
    }, e.clickOnSpace = function(t) {
        t && "function" == typeof t.click && !e.isElementEditable(t) && t.addEventListener("keydown", function(n) {
            e.keys.isSpace(n) && (n.preventDefault(), t.click())
        })
    }, e.execOnPage = function(e, t) {
        var n, r, o;
        if (Array.isArray(e)) try {
            for (var i = __values(e), a = i.next(); !a.done; a = i.next()) {
                var u = a.value;
                if (o = new RegExp(u).test(window.location.href)) {
                    t();
                    break
                }
            }
        } catch (e) {
            n = {
                error: e
            }
        } finally {
            try {
                a && !a.done && (r = i.return) && r.call(i)
            } finally {
                if (n) throw n.error
            }
        } else(o = new RegExp(e).test(window.location.href)) && t();
        return o
    }, e.getFocusableElement = function(t, n, r) {
        t = t || "next", r = r || {}, r.childrenOnly = r.childrenOnly || !1, r.canBeHidden = r.canBeHidden || !1;
        var o = Array.from((r.childrenOnly ? n : document).querySelectorAll(e.focusableElementsSelector + (n ? "," + e.getCssPath(n) : "")));
        r.canBeHidden || (o = o.filter(function(e) {
            return !!e.offsetParent
        }));
        var i = o.findIndex(function(e) {
            return !(!n || e !== n) || e === document.activeElement
        });
        return "next" === t ? o[i + 1] || o[0] : "prev" === t ? o[i - 1] || o[o.length - 1] : void 0
    }, e.getCssPath = function(e) {
        for (var t = []; e.parentNode;) {
            if (e.id) {
                t.unshift("#" + e.id);
                break
            }
            if (e == e.ownerDocument.documentElement) t.unshift(e.tagName);
            else {
                for (var n = 1, r = e; r.previousElementSibling; r = r.previousElementSibling, n++);
                t.unshift(e.tagName + ":nth-child(" + n + ")")
            }
            e = e.parentNode
        }
        return t.join(" > ")
    }, e.getElementPosition = function(e) {
        for (var t = 0, n = 0; e;) {
            if ("BODY" == e.tagName) {
                var r = e.scrollLeft || document.documentElement.scrollLeft,
                    o = e.scrollTop || document.documentElement.scrollTop;
                t += e.offsetLeft - r + e.clientLeft, n += e.offsetTop - o + e.clientTop
            } else t += e.offsetLeft - e.scrollLeft + e.clientLeft, n += e.offsetTop - e.scrollTop + e.clientTop;
            e = e.offsetParent
        }
        return {
            x: t,
            y: n
        }
    };
    var n = [];
    e.onHistoryPushState = function(e, t) {
        if (void 0 === t && (t = {}), t = __assign({
                delay: 300
            }, t), n.push(e), 1 === n.length) {
            if (window.history) {
                var r = window.history.pushState;
                window.history.pushState = function(e) {
                    return "function" == typeof window.history.onpushstate && window.history.onpushstate({
                        state: e
                    }), r.apply(window.history, arguments)
                }
            }
            var o;
            window.onpopstate = window.history.onpushstate = function() {
                clearTimeout(o), o = setTimeout(function() {
                    return n.forEach(function(e) {
                        return e()
                    })
                }, t.delay)
            }
        }
    }, e.announce = function(e) {
        var t = document.createElement("div");
        t.setAttribute("aria-live", "assertive"), t.style.width = "0", t.style.height = "0", t.style.overflow = "hidden", document.body.insertAdjacentElement("afterbegin", t), setTimeout(function() {
            t.innerHTML = e
        }, 1e3), setTimeout(function() {
            t.remove()
        }, 1e4)
    }, e.queryXPath = function(e, t) {
        var n;
        void 0 === t && (t = null);
        var r = document.evaluate(e, t || document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null);
        return (null === r || void 0 === r ? void 0 : r.singleNodeValue) && (null === (n = null === r || void 0 === r ? void 0 : r.singleNodeValue) || void 0 === n ? void 0 : n.nodeType) === Node.ELEMENT_NODE ? r.singleNodeValue : null
    }, e.queryXPathAll = function(e, t) {
        void 0 === t && (t = null);
        for (var n = document.evaluate(e, t || document, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null), r = [], o = 0, i = n.snapshotLength; o < i; ++o) r.push(n.snapshotItem(o));
        return r
    }, e.loopThroughElements = function(t, n, r, o) {
        void 0 === r && (r = null), void 0 === o && (o = null), r = __assign({
            ancestor: document,
            useForEach: !0
        }, r || {}), e.waitUntil(function() {
            if (r.ancestor) {
                var n = [];
                try {
                    n = r.ancestor.querySelectorAll(t)
                } catch (o) {
                    try {
                        n = e.queryXPathAll(t, r.ancestor)
                    } catch (e) {
                        throw new Error(t + " is invalid CSS and XPath selector")
                    }
                }
                return (null === n || void 0 === n ? void 0 : n.length) ? n : void 0
            }
        }, function(e) {
            r.useForEach ? e.forEach(n) : n(e)
        }, r, o)
    }, e.waitForElement = function(t, n, r, o) {
        void 0 === r && (r = null), void 0 === o && (o = null), r = __assign({
            ancestor: document
        }, r || {}), e.waitUntil(function() {
            if (r.ancestor) try {
                return r.ancestor.querySelector(t)
            } catch (n) {
                try {
                    return e.queryXPath(t, r.ancestor)
                } catch (e) {
                    throw new Error(t + " is invalid CSS and XPath selector")
                }
            }
        }, n, r, o)
    }
}(),
function() {
    function e(e, t, n, o) {
        -1 === l.indexOf(e) && (l.push(e), r.execJs(a + t, n).then(function() {
            o && window.postMessage({
                isUserWay: !0,
                action: "remediation",
                type: "add-dynamically",
                remediationHelperName: o
            }, "*")
        }))
    }
    var t, n = UserWayWidgetApp.addLib("cpr_patterns_observer"),
        r = UserWayWidgetApp.getLib("util"),
        o = UserWayWidgetApp.getLib("remediation_util"),
        i = UserWayWidgetApp.getLib("remediationConfig"),
        a = (i && i.complex && i.complex, "https://cdn.userway.org/"),
        u = "widgetapp/2025-04-07-09-19-51/remediation/nav_menu_helper_1744017591749.js",
        l = [],
        s = i.labs && i.labs.enabled && Object.keys(null !== (t = i.labs.config) && void 0 !== t ? t : []).length > 0;
    n.apply = function(e) {
        d.filter(function(e) {
            return e.onPageLoad
        }).forEach(function(e) {
            return e.observe()
        })
    }, n.tick = function(e) {
        d.filter(function(e) {
            return e.onDomChanged
        }).forEach(function(e) {
            return e.observe()
        })
    };
    var d = [{
        name: "PayoneerAccountSitesCommon",
        remediationHelperName: "",
        path: "widgetapp/2025-04-07-09-19-51/remediation/payoneer_account_1744017591749.js",
        onPageLoad: !0,
        onDomChanged: !1,
        observe: function() {
            var t = this;
            "m8nhTkGuMw" === UserWayWidgetApp.ContextHolder.config.account && function() {
                e(t.name, t.path, "sha256-NJHPNbXQL8/yvJDyo23NXe1W44QtML+W756pkztQpYM=", t.remediationHelperName)
            }()
        }
    }, {
        name: "SimplexAccountSitesCommon",
        remediationHelperName: "",
        path: "widgetapp/2025-04-07-09-19-51/remediation/simplex_account_1744017591749.js",
        onPageLoad: !0,
        onDomChanged: !1,
        observe: function() {
            var t = this;
            "DBnq3tIKbX" === UserWayWidgetApp.ContextHolder.config.account && function() {
                e(t.name, t.path, "sha256-7a+7Xg3vciW+Mne1lJuwv2A4CANleNvKOmGD12pHInM=", t.remediationHelperName)
            }()
        }
    }, {
        name: "JQueryUiDatepicker",
        remediationHelperName: "",
        path: "widgetapp/2025-04-07-09-19-51/remediation/jqueryui_datepicker_1744017591749.js",
        onPageLoad: !0,
        onDomChanged: !1,
        observe: function() {
            [].slice.call(document.querySelectorAll(".hasDatepicker")).filter(function(e) {
                return !e.getAttribute("data-uw-rm-cpr-jqdp")
            }).length && jQuery && jQuery.ui && jQuery.ui.datepicker && e(this.name, this.path, "sha256-fzY74JVqYIY5N5yNkPCLVyawerLdVlcB7cdjZRcRfKs=", this.remediationHelperName)
        }
    }, {
        name: "AngularJsAria",
        remediationHelperName: "ANGULAR_JS_ARIA",
        path: "widgetapp/2025-04-07-09-19-51/remediation/uw_aria_helper_1744017591749.ts",
        onPageLoad: !0,
        onDomChanged: !1,
        observe: function() {
            var t = this,
                n = function() {
                    e(t.name, t.path, "sha256-skUcGYwV4ch6x37u65wVQrTZMuCIAUdYJOqbNwN54j0=", t.remediationHelperName)
                };
            o.waitUntil(function() {
                return !!document.querySelector("[ng-app]")
            }, n, {
                timeout: 6e4
            })
        }
    }, {
        name: "slickSlider",
        remediationHelperName: "",
        path: "widgetapp/2025-04-07-09-19-51/remediation/slick_slider_1744017591749.js",
        onPageLoad: !0,
        onDomChanged: !1,
        observe: function() {
            document.querySelector(".slick-slider") && e(this.name, this.path, "sha256-HzbaajCSXjYzpdPrxYVWGL41xitmsBp335XXFB2zyNI=", this.remediationHelperName)
        }
    }, {
        name: "NavMenu",
        remediationHelperName: "",
        path: "//",
        onPageLoad: !0,
        onDomChanged: !1,
        observe: function() {
            var t = function() {
                s || (window.jQuery && window.jQuery.ui && window.jQuery.ui.version ? (o.waitUntil(function() {
                    return !!(window.jQuery && window.jQuery.ui && window.jQuery.ui.version && window.jQuery.ui.menu) && !!document.querySelector(".navigation .ui-menu-item")
                }, function() {
                    setTimeout(function() {
                        e("JQueryUiMenu", "widgetapp/2025-04-07-09-19-51/remediation/jqueryui_menu_helper_1744017591749.js", "sha256-vvjYbKhSaii5P+3Ctik4H+LTSHLvHDnybHBFwUSL1uQ=", "")
                    }, 4e3)
                }, {
                    timeout: 1e4
                }), setTimeout(function() {
                    -1 === l.indexOf("JQueryUiMenu") && e("NavMenu", u, "sha256-SO73/mGj4sfIisHGomO9hRtqBTY2B+Uv0r5ORHLUIlU=", "")
                }, 14100)) : -1 === l.indexOf("JQueryUiMenu") && e("NavMenu", u, "sha256-SO73/mGj4sfIisHGomO9hRtqBTY2B+Uv0r5ORHLUIlU=", ""))
            };
            "complete" === document.readyState ? t() : window.addEventListener("load", t, !1)
        }
    }, {
        name: "OwlCarousel",
        remediationHelperName: "",
        path: "widgetapp/2025-04-07-09-19-51/remediation/owl_carousel_1744017591749.js",
        onPageLoad: !0,
        onDomChanged: !1,
        observe: function() {
            document.querySelector(".owl-carousel") && e(this.name, this.path, "sha256-rb1LgLG5AywiZge4c4i5sFyYYqCydrhEB59/RLdR76g=", this.remediationHelperName)
        }
    }, {
        name: "yotpoWidget",
        remediationHelperName: "",
        path: "widgetapp/2025-04-07-09-19-51/remediation/yotpo_widget_1744017591749.js",
        onPageLoad: !0,
        onDomChanged: !1,
        observe: function() {
            document.querySelector(".yotpo") && e(this.name, this.path, "sha256-GIuAq4nuA4gneXSAeZ/QDQug8Z/6Xbz2E9fOLGZV5Eg=", this.remediationHelperName)
        }
    }, {
        name: "judgeMe",
        remediationHelperName: "",
        path: "widgetapp/2025-04-07-09-19-51/remediation/judgeme_widget_1744017591749.js",
        onPageLoad: !0,
        onDomChanged: !1,
        observe: function() {
            document.querySelector(".jdgm-star") && e(this.name, this.path, "sha256-UbU25H+TzYB73LKY1BZpGepuOcR3Zq40WFZ/6Bf9s3s=", this.remediationHelperName)
        }
    }, {
        name: "cycleSliderHelper",
        remediationHelperName: "",
        path: "widgetapp/2025-04-07-09-19-51/remediation/cycle_slider_helper_1744017591749.js",
        onPageLoad: !0,
        onDomChanged: !1,
        observe: function() {
            document.querySelector(".cycle-slide") && e(this.name, this.path, "sha256-7d6M1UDXQDlMngKZI+asQoUOXwa4BMyeRqUCiDYsxas=", this.remediationHelperName)
        }
    }, {
        name: "muiElementsRemediation",
        remediationHelperName: "",
        path: "widgetapp/2025-04-07-09-19-51/remediation/mui_elements_1744017591749.js",
        onPageLoad: !0,
        onDomChanged: !0,
        observe: function() {
            ["mat-expansion-panel.mat-expansion-panel", ".mat-option-text", ".mat-option-ripple", ".mat-form-field-label-wrapper", ".mat-expansion-panel-header-title", ".mat-expansion-indicator", ".mat-autocomplete-panel", ".mat-expansion-panel-header"].some(function(e) {
                return document.querySelector(e)
            }) && e(this.name, this.path, "sha256-yXI4CdhFr5OhbD13f+WFeyHuPTtGa1K47eJRnqTztlI=", this.remediationHelperName)
        }
    }, {
        name: "shortPointHelper",
        remediationHelperName: "",
        path: "widgetapp/2025-04-07-09-19-51/remediation/s_p_1744017591749.js",
        onPageLoad: !0,
        onDomChanged: !1,
        observe: function() {
            ['[data-shortpoint-type="row"]'].some(function(e) {
                return document.querySelector(e)
            }) && e(this.name, this.path, "sha256-wEsvu9mmG0N5053GtFHN4cn5qmr27+xhS3MMUa3MVBM=", this.remediationHelperName)
        }
    }]
}();
var __values = this && this.__values || function(e) {
    var t = "function" == typeof Symbol && Symbol.iterator,
        n = t && e[t],
        r = 0;
    if (n) return n.call(e);
    if (e && "number" == typeof e.length) return {
        next: function() {
            return e && r >= e.length && (e = void 0), {
                value: e && e[r++],
                done: !e
            }
        }
    };
    throw new TypeError(t ? "Object is not iterable." : "Symbol.iterator is not defined.")
};
! function() {
    function e(e) {
        var n = e.alt;
        if (n && n.trim()) return n.trim();
        var r = e.getAttribute("aria-label");
        if (r && r.trim()) return r.trim();
        var o = e.getAttribute("aria-describedby");
        if (o) {
            var i = t(o);
            if (i) return i
        }
        var a = e.getAttribute("aria-labelledby");
        if (a) {
            var i = t(a);
            if (i) return i
        }
        return null
    }

    function t(e) {
        var t = e.split(" "),
            n = "";
        return t.forEach(function(e) {
            e = e.trim();
            var t = document.getElementById(e);
            n += t && t.textContent ? t.textContent : ""
        }), n
    }
    var n, r = UserWayWidgetApp.addLib("remediation_utils");
    r.ignoreElementFromHelperProcessingAttr = "data-uw-rm-ignore";
    var o = UserWayWidgetApp.getLib("util"),
        i = UserWayWidgetApp.getLib("inlineStyling"),
        a = UserWayWidgetApp.getLib("xpath_search");
    r.PROCESS_ATTRIBUTES = {
        CER: {
            popup: {
                wrapper: "data-uw-cer-popup-wrapper",
                close: "data-uw-cer-popup-close"
            }
        }
    };
    var u = {
        attrMarker: "uw-remediation",
        className: "uw-remediation-highlighting",
        styles: (n = {
            border: "dashed 2px #c00"
        }, n["border-radius"] = "3px", n["box-shadow"] = "0 0 0 4px yellow, inset 0 0 0 4px yellow", n)
    };
    r.sendBackEnd = function(e, t, n) {
        var r = {
            method: "POST",
            url: "https://api.userway.org/api" + e,
            header: {
                "Content-Type": "application/json"
            },
            body: {
                userId: UserWayWidgetApp.ContextHolder.config.services.userId,
                siteId: UserWayWidgetApp.ContextHolder.config.services.siteId
            }
        };
        return t && (r.body.elements = t), "object" == typeof n && Object.keys(n).map(function(e) {
            r.body[e] = n[e]
        }), o.request(r)
    }, r.highlightElements = function(e, t, n) {
        var r, o, l, s, d = document.querySelectorAll("." + u.className);
        d.length && d.forEach(function(e) {
            i.resetInlineStyles(e, u.attrMarker, u.styles), e.classList.remove(u.className)
        });
        var c = [];
        switch (e) {
            case "xpath":
                var f = a.recursiveXpathSearch(t);
                c = "boolean" != typeof f ? [f] : [];
                break;
            case "href":
                var p = Array.prototype.slice.call(document.querySelectorAll("[href]"));
                try {
                    for (var m = __values(p), y = m.next(); !y.done; y = m.next()) {
                        var h = y.value;
                        h.href.toLowerCase().indexOf(t) > -1 && c.push(h)
                    }
                } catch (e) {
                    r = {
                        error: e
                    }
                } finally {
                    try {
                        y && !y.done && (o = m.return) && o.call(m)
                    } finally {
                        if (r) throw r.error
                    }
                }
                break;
            case "src":
                var g = Array.prototype.slice.call(document.querySelectorAll("[src]"));
                try {
                    for (var v = __values(g), b = v.next(); !b.done; b = v.next()) {
                        var A = b.value;
                        A.src.toLowerCase().indexOf(t) > -1 && c.push(A)
                    }
                } catch (e) {
                    l = {
                        error: e
                    }
                } finally {
                    try {
                        b && !b.done && (s = v.return) && s.call(v)
                    } finally {
                        if (l) throw l.error
                    }
                }
                break;
            case "attr":
                if (n.attrName) {
                    var _ = document.querySelectorAll("[" + n.attrName + '="' + t + '"]');
                    c = Array.prototype.slice.call(_)
                }
        }
        for (var E = 0; E < c.length; E++) {
            var w = c[E];
            if (w && "function" == typeof w.setAttribute && (w.classList.add(u.className), i.applyInlineStyles(w, u.attrMarker, u.styles), !E && n.scroll)) {
                var S = w.getBoundingClientRect(),
                    O = S.top + window.pageYOffset - document.documentElement.clientTop - window.innerHeight / 2 + S.height;
                window.scrollTo({
                    top: O,
                    behavior: "smooth"
                })
            }
        }
    }, r.getElementAccessibleName = function(n) {
        var r = n.getAttribute("aria-label"),
            o = n.getAttribute("aria-describedby");
        if (o && (r += t(o)), r && r.trim()) return r.trim().toLowerCase();
        var i = n.getAttribute("aria-labelledby");
        if (i && (r += t(i)), r && r.trim()) return r.trim().toLowerCase();
        if ((r = n.textContent ? n.textContent : null) && r.trim()) return r.trim().toLowerCase();
        if ((r = n.value || "") && r.trim() && "INPUT" === n.tagName.toUpperCase() && n.type && -1 !== ["button", "submit", "reset"].indexOf(n.type.toLowerCase())) return r.trim().toLowerCase();
        var a = n.querySelector('img, *[role="img"]');
        return a && (r = e(a)) && r.trim() ? r.trim().toLowerCase() : null
    }
}(),
function() {
    var e = UserWayWidgetApp.addLib("remediation_helper_outcome"),
        t = UserWayWidgetApp.getLib("util");
    e.of = function(e, n, r, o, i) {
        return n = n || {
            items: []
        }, r = r || {
            items: [],
            path: null
        }, {
            helperName: e,
            postMessageAppData: n,
            backEndData: r,
            countFixed: o,
            countTodo: i,
            hash: t.hashString(e + JSON.stringify(n) + o + i)
        }
    }
}();
var __assign = this && this.__assign || function() {
    return __assign = Object.assign || function(e) {
        for (var t, n = 1, r = arguments.length; n < r; n++) {
            t = arguments[n];
            for (var o in t) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o])
        }
        return e
    }, __assign.apply(this, arguments)
};
! function() {
    var e = UserWayWidgetApp.addLib("remediation_results_holder"),
        t = UserWayWidgetApp.getLib("util"),
        n = ["REMEDIATION_COLOR_CONTRAST"];
    e.instance = new function() {
        var e = this,
            r = {};
        e.reset = function() {
            r = {}
        }, e.get = function() {
            return r
        }, e.mergeHelperOutcomes = function(e, r) {
            if (e.helperName !== r.helperName) throw "Inconsistent helpers! Unable to merge " + e.helperName + " with " + r.helperName;
            var o = e.postMessageAppData && -1 === n.indexOf(e.helperName),
                i = -1 === n.indexOf(e.helperName);
            return e.postMessageAppData = o ? {
                items: e.postMessageAppData.items.concat(r.postMessageAppData.items)
            } : __assign({}, r.postMessageAppData), e.backEndData.items = r.backEndData.items, e.countFixed = i ? e.countFixed + r.countFixed : r.countFixed, e.countTodo = e.countTodo + r.countTodo, e.hash = t.hashString(r.hash), e
        }, e.put = function(t) {
            var n = t.helperName,
                o = r[n] ? e.mergeHelperOutcomes(r[n], t) : t;
            r[n] = o
        }, e.getCurrentHash = function() {
            var e = "";
            return Object.keys(r).length ? (Object.keys(r).forEach(function(t) {
                e += r[t].hash
            }), e) : e
        }, e.getHelperPostMessagePayload = function(e) {
            var t = r[e];
            return t ? t.postMessageAppData : {
                items: []
            }
        }, e.getHelpersOutcomeCounters = function() {
            var e = {};
            return Object.keys(r).forEach(function(t) {
                e[t] = r[t].countFixed
            }), e
        }, e.getHelpersTodoOutcomeCounters = function() {
            var e = {};
            return Object.keys(r).forEach(function(t) {
                e[t] = r[t].countTodo
            }), e
        }, e.toString = function() {
            return JSON.stringify(r)
        }
    }
}(),
function() {
    var e = UserWayWidgetApp.addLib("remediation_stopwatch"),
        t = {};
    e.checkPointHelperStart = function(e, n) {
        n.debugMode && (t.hasOwnProperty(e) || (t[e] = {
            start: [],
            "f-start": [],
            "f-end": [],
            "a-start": [],
            "a-end": [],
            "r-start": [],
            "r-end": [],
            end: []
        }), t[e].start.push(performance.now()))
    }, e.checkPointHelperEnd = function(e, n) {
        n.debugMode && t[e].end.push(performance.now())
    }, e.checkPointHelperFilterStart = function(e, n) {
        n.debugMode && t[e]["f-start"].push(performance.now())
    }, e.checkPointHelperFilterEnd = function(e, n) {
        n.debugMode && t[e]["f-end"].push(performance.now())
    }, e.checkPointHelperAwaitForResourcesStart = function(e, n) {
        n.debugMode && t[e]["a-start"].push(performance.now())
    }, e.checkPointHelperAwaitForResourcesEnd = function(e, n) {
        n.debugMode && t[e]["a-end"].push(performance.now())
    }, e.checkPointHelperDoRemediationStart = function(e, n) {
        n.debugMode && t[e]["r-start"].push(performance.now())
    }, e.checkPointHelperDoRemediationEnd = function(e, n) {
        n.debugMode && t[e]["r-end"].push(performance.now())
    }, UserWayWidgetApp.getHelpersPerformance = function() {
        var e = {};
        return Object.keys(t).forEach(function(n) {
            var r = t[n];
            e[n] = {
                "1_filter": [],
                "2_resources": [],
                "3_remediation": [],
                "4_total": []
            };
            for (var o = 0; o < r.start.length; o++) e[n]["1_filter"].push(r["f-end"][o] - r["f-start"][o]), e[n]["2_resources"].push(r["a-end"][o] - r["a-start"][o]), e[n]["3_remediation"].push(r["r-end"][o] - r["r-start"][o]), e[n]["4_total"].push(r.end[o] - r.start[o])
        }), t._aggregated = e, t
    }
}(),
function() {
    function e(e, t, r, o) {
        return new Promise(function(i, a) {
            var u = UserWayWidgetApp.getLib(e);
            n.checkPointHelperStart(u.name, o);
            var l = [];
            n.checkPointHelperFilterStart(u.name, o);
            try {
                l = u.filter ? u.filter(t, o) : null, n.checkPointHelperFilterEnd(u.name, o)
            } catch (e) {
                return n.checkPointHelperFilterEnd(u.name, o), n.checkPointHelperEnd(u.name, o), o.debugMode && console.error(e), i()
            }
            n.checkPointHelperAwaitForResourcesStart(u.name, o), u.awaitForResources(l, o).then(function() {
                n.checkPointHelperAwaitForResourcesEnd(u.name, o), n.checkPointHelperDoRemediationStart(u.name, o), u.doRemediation(r, l, o).then(function() {
                    n.checkPointHelperDoRemediationEnd(u.name, o), n.checkPointHelperEnd(u.name, o), i()
                }).catch(function(e) {
                    n.checkPointHelperDoRemediationEnd(u.name, o), n.checkPointHelperEnd(u.name, o), o.debugMode && console.error(e), i()
                })
            }).catch(function(e) {
                n.checkPointHelperAwaitForResourcesEnd(u.name, o), n.checkPointHelperEnd(u.name, o), o.debugMode && console.error(e), i()
            })
        })
    }
    var t = UserWayWidgetApp.addLib("remediation_processor"),
        n = UserWayWidgetApp.getLib("remediation_stopwatch");
    UserWayWidgetApp.getLib("remediation_utils");
    t.runHelper = function(t, n, r, o) {
        return t.then ? t : e(t, n, r, o)
    }, t.parallel = function(e, t) {
        return Promise.all(e.map(function(e) {
            return t(e)
        }))
    }, t.sequence = function(e, t) {
        return e.reduce(function(e, n) {
            return e.then(function() {
                return t(n)
            })
        }, Promise.resolve())
    }, t.series = function(e, n, r, o) {
        return t.sequence(e, function(e) {
            return t.parallel(e, function(e) {
                return t.runHelper(e, n, r, o)
            })
        }).catch(function(e) {
            o.debugMode && console.error(e)
        })
    }
}();
var __values = this && this.__values || function(e) {
    var t = "function" == typeof Symbol && Symbol.iterator,
        n = t && e[t],
        r = 0;
    if (n) return n.call(e);
    if (e && "number" == typeof e.length) return {
        next: function() {
            return e && r >= e.length && (e = void 0), {
                value: e && e[r++],
                done: !e
            }
        }
    };
    throw new TypeError(t ? "Object is not iterable." : "Symbol.iterator is not defined.")
};
! function() {
    function e(e) {
        var t, n, r = [].slice.call(m.findAllElements(e)),
            o = r.filter(function(e) {
                var t, n, r = Array.from(e.attributes),
                    o = !1;
                try {
                    for (var i = __values(r), a = i.next(); !a.done; a = i.next()) {
                        var u = a.value,
                            l = u.value.toLowerCase();
                        if (-1 !== l.indexOf("close") || -1 !== l.indexOf("dismiss")) {
                            o = !0;
                            break
                        }
                    }
                } catch (e) {
                    t = {
                        error: e
                    }
                } finally {
                    try {
                        a && !a.done && (n = i.return) && n.call(i)
                    } finally {
                        if (t) throw t.error
                    }
                }
                return o
            }),
            i = null,
            a = l().vw,
            u = Math.round(a / 20);
        try {
            for (var s = __values(o), d = s.next(); !d.done; d = s.next()) {
                var c = d.value,
                    f = c.offsetWidth,
                    p = c.offsetHeight;
                if (f && p && f <= 5 * u) {
                    i = c;
                    break
                }
            }
        } catch (e) {
            t = {
                error: e
            }
        } finally {
            try {
                d && !d.done && (n = s.return) && n.call(s)
            } finally {
                if (t) throw t.error
            }
        }
        return i
    }

    function t(e, t) {
        var n, r, o = null;
        try {
            for (var i = __values(e[0]), a = i.next(); !a.done; a = i.next()) {
                var l = a.value,
                    s = new Array(e.length).fill(0);
                s[0] = 1;
                for (var d = 1; d < e.length; d++) {
                    e[d].indexOf(l) > -1 && (s[d] = 1)
                }
                if (s.every(function(e) {
                        return !!e
                    })) {
                    o = l;
                    break
                }
            }
        } catch (e) {
            n = {
                error: e
            }
        } finally {
            try {
                a && !a.done && (r = i.return) && r.call(i)
            } finally {
                if (n) throw n.error
            }
        }
        return o && 0 === e[0].indexOf(o) && u(o.offsetWidth, t) < 5 && (o = null), o
    }

    function n(e, t) {
        return e.classList.contains("tt-dropdown-menu") || /datepicker/.test(e.getAttribute("class")) || !!e.id && "klevuSearchingArea" === e.id || e.hasAttribute("data-uw-rm-ignore") || !!Array.from(document.querySelectorAll("nav")).find(function(t) {
            return e.contains(t)
        }) || !!e.querySelector("[class*='search']")
    }

    function r(e) {
        var t = window.getComputedStyle(e),
            r = "none" === t.display,
            o = "fixed" === t.position,
            i = parseFloat(t.width),
            a = parseFloat(t.height),
            l = u(i, document.body.offsetWidth),
            s = u(a, document.body.offsetHeight);
        return l >= 10 && s >= 10 && o && !r && i && a && !n(e, t)
    }

    function o(e) {
        var t = null;
        if (!e) return t;
        for (; e && "BODY" !== e.tagName;) {
            if (r(e)) {
                t = e;
                break
            }
            e = e.parentElement
        }
        return t
    }

    function i() {
        return /^([^.]+\.)?manage\..*userway\.(dev|org)$/.test(window.location.host)
    }

    function a() {
        if (114355 === f.services.siteId || 990479 === f.services.siteId || i()) return null;
        var e = l(),
            n = e.vw,
            r = e.vh,
            a = Math.round(n / 2),
            u = Math.round(r / 2),
            s = Math.round(3 * n / 4),
            d = Math.round(r / 4),
            c = u + Math.round(r / 4),
            p = Math.round(n / 20),
            m = Math.round(r / 20),
            y = [{
                x: a,
                y: u - m
            }, {
                x: a + p,
                y: u
            }, {
                x: a,
                y: u + m
            }, {
                x: a - p,
                y: u
            }],
            h = [{
                x: s,
                y: u - m
            }, {
                x: s + p,
                y: u
            }, {
                x: s,
                y: u + m
            }, {
                x: s - p,
                y: u
            }],
            g = [{
                x: a,
                y: d
            }, {
                x: a - p,
                y: d + m
            }, {
                x: a + p,
                y: d + m
            }],
            v = [{
                x: a,
                y: c
            }, {
                x: a - p,
                y: c - m
            }, {
                x: a + p,
                y: c - m
            }],
            b = document.elementsFromPoint(y[0].x, y[0].y),
            A = document.elementsFromPoint(y[1].x, y[1].y),
            _ = document.elementsFromPoint(y[2].x, y[2].y),
            E = document.elementsFromPoint(y[3].x, y[3].y),
            w = o(t([b, A, _, E], n));
        if (w) return w;
        var S = document.elementsFromPoint(g[0].x, g[0].y),
            O = document.elementsFromPoint(g[1].x, g[1].y),
            x = document.elementsFromPoint(g[2].x, g[2].y),
            W = o(t([S, O, x], n));
        if (W) return W;
        var C = document.elementsFromPoint(v[0].x, v[0].y),
            N = document.elementsFromPoint(v[1].x, v[1].y),
            L = document.elementsFromPoint(v[2].x, v[2].y),
            R = o(t([C, N, L], n));
        if (R) return R;
        var k = document.elementsFromPoint(h[0].x, h[0].y),
            P = document.elementsFromPoint(h[1].x, h[1].y),
            I = document.elementsFromPoint(h[2].x, h[2].y),
            T = document.elementsFromPoint(h[3].x, h[3].y),
            U = o(t([k, P, I, T], n));
        return U || null
    }

    function u(e, t) {
        return Math.abs(e - t) / ((e + t) / 2) * 100
    }

    function l() {
        return {
            vw: Math.max(document.documentElement.clientWidth || 0, window.innerWidth || 0),
            vh: Math.max(document.documentElement.clientHeight || 0, window.innerHeight || 0)
        }
    }
    var s = UserWayWidgetApp.addLib("cer_observer"),
        d = UserWayWidgetApp.getLib("event_emitter"),
        c = UserWayWidgetApp.getLib("remediation_utils"),
        f = UserWayWidgetApp.ContextHolder.config,
        p = UserWayWidgetApp.getLib("remediationConfig").popups,
        m = UserWayWidgetApp.getLib("util"),
        y = [];
    s.tick = function(t) {
        var n = t.processParameters;
        n.debugMode && console.log("CER observer: tick");
        var r, o = null;
        if (n.debugMode && (r = performance.now()), p.enabled) {
            var i = null;
            try {
                i = a()
            } catch (e) {
                n.debugMode && console.error(e)
            }
            if (i) {
                i.setAttribute(c.PROCESS_ATTRIBUTES.CER.popup.wrapper, "");
                if (-1 === y.indexOf(i)) {
                    d.emitEvent("UW_CER_POPUP_FOUND", [i]), y.push(i);
                    var u = null;
                    try {
                        u = e(i)
                    } catch (e) {
                        n.debugMode && console.error(e)
                    }
                    u && u.setAttribute(c.PROCESS_ATTRIBUTES.CER.popup.close, ""), d.emitEvent("UW_CER_POPUP_ON", [
                        [i, u]
                    ]), n.debugMode && console.log("CER observer: POPUP found", i, u)
                }
            } else y.forEach(function(e) {
                d.emitEvent("UW_CER_POPUP_OFF", [e]), n.debugMode && console.log("CER observer: POPUP closed", e)
            }), y = []
        }
        n.debugMode && (o = performance.now(), console.log("CER observer tick: execution took " + (o - r) + " milliseconds."))
    }
}();
var __read = this && this.__read || function(e, t) {
        var n = "function" == typeof Symbol && e[Symbol.iterator];
        if (!n) return e;
        var r, o, i = n.call(e),
            a = [];
        try {
            for (;
                (void 0 === t || t-- > 0) && !(r = i.next()).done;) a.push(r.value)
        } catch (e) {
            o = {
                error: e
            }
        } finally {
            try {
                r && !r.done && (n = i.return) && n.call(i)
            } finally {
                if (o) throw o.error
            }
        }
        return a
    },
    __spreadArray = this && this.__spreadArray || function(e, t, n) {
        if (n || 2 === arguments.length)
            for (var r, o = 0, i = t.length; o < i; o++) !r && o in t || (r || (r = Array.prototype.slice.call(t, 0, o)), r[o] = t[o]);
        return e.concat(r || Array.prototype.slice.call(t))
    };
! function() {
    function e(e) {
        U && U.time(e)
    }

    function t(e) {
        U && U.timeEnd(e)
    }

    function n() {
        N.getMeasurements && N.getMeasurements("Remediation")
    }

    function r(e) {
        return e ? __spreadArray([q, j, B], __read(Y.map(function(e) {
            return [e]
        })), !1) : __spreadArray([
            ["REMEDIATION_KEYBOARD_NAVIGATION"]
        ], __read(Y.map(function(e) {
            return [e]
        })), !1)
    }

    function o() {
        F.completedEventFired || (F.completedEventFired = !0, E.fireUserWayRemediationCompletedEvent({
            enabled: !0,
            counters: C.getHelpersOutcomeCounters()
        }))
    }

    function i() {
        if (!F.iterationInProgress) {
            var e = x.consolidated && !UserWayWidgetApp.ContextHolder.remediationResources;
            if (x.consolidated || E.fireUserWayRemediationCompletedEvent({
                    enabled: !1
                }), e || H()) return void E.fireUserWayRemediationCompletedEvent({
                enabled: !1
            });
            var t = r(!F.domChangesEnqueued.length);
            F.iterationInProgress = !0, F.domChangesEnqueued = [], F.debugMode && console.log("UserWay Remediation: tick started"), w.series(t, [document.body], v.HelperCallbackAggregator, {
                reset: F.locationChanged,
                debugMode: M
            }).catch(function(e) {
                console.error(e)
            }).finally(function() {
                var e;
                F.debugMode && console.log("UserWay Remediation: tick ended"), o(), D && (S.tick({
                    processParameters: F
                }), null === (e = null === O || void 0 === O ? void 0 : O.tick) || void 0 === e || e.call(O, {
                    processParameters: F
                })), setTimeout(function() {
                    n(), d(), c(), F.iterationInProgress = !1, F.domChangesEnqueued.length && i()
                }, 1e3)
            }), F.locationChanged && f(), F.locationChanged = !1
        }
    }

    function a() {
        var n;
        V.forEach(function(n) {
            var r;
            e(n);
            var o = UserWayWidgetApp.getLib(n);
            F.debugMode && console.log("UserWay Remediation: One-time helper applied %c" + n, "color:Red"), null === (r = null === o || void 0 === o ? void 0 : o.apply) || void 0 === r || r.call(o, F), t(n)
        }), null === (n = null === O || void 0 === O ? void 0 : O.apply) || void 0 === n || n.call(O, {
            processParameters: F
        })
    }

    function u() {
        setTimeout(function() {
            i(), D && a(), F.debugMode && console.log("UserWay Remediation: process started"), b.on(L, function(e, t) {
                if (t && (!t || t.length)) {
                    if (k) return void(F.debugMode && console.log("UserWay Remediation: SKIP_DOM_CHANGES_REMEDIATION"));
                    F.debugMode && console.log("UserWay Remediation: tick resumed; initiator: DOM change"), H() || (F.domChangesEnqueued = F.domChangesEnqueued.concat(t), F.iterationInProgress || i())
                }
            })
        }, R)
    }

    function l(e) {
        var t = e.data.remediationHelperName;
        t && (B.push("REMEDIATION_" + t), G.push("REMEDIATION_" + t), i())
    }

    function s(e) {
        var t = UserWayWidgetApp.getLib("REMEDIATION_NAVIGATION_MENU");
        t && "function" == typeof t.apply && t.apply(F), P && u()
    }

    function d() {
        p("remediation-count", C.getHelpersOutcomeCounters())
    }

    function c() {
        p("all-data", C.get())
    }

    function f() {
        p("get-site-info", {
            origin: location.origin,
            path: location.pathname
        })
    }

    function p(e, t) {
        F.debugMode && (console.log("UserWay Remediation PostMessage: %c[TYPE]: %c" + e, "color:Blue", "color:Red"), console.group("%c[PAYLOAD]:", "color:Blue"), console.log(t), console.groupEnd()), E.postMessage({
            action: "remediation",
            type: e,
            data: t
        })
    }
    var m, y, h, g, v = UserWayWidgetApp.addLib("remediation_manager"),
        b = UserWayWidgetApp.getLib("event_emitter"),
        A = UserWayWidgetApp.getLib("dom_observer"),
        _ = UserWayWidgetApp.getLib("remediation_utils"),
        E = UserWayWidgetApp.getLib("util"),
        w = UserWayWidgetApp.getLib("remediation_processor"),
        S = UserWayWidgetApp.getLib("cer_observer"),
        O = UserWayWidgetApp.getLib("cpr_patterns_observer"),
        x = UserWayWidgetApp.getLib("remediationConfig"),
        W = UserWayWidgetApp.ContextHolder.config,
        C = UserWayWidgetApp.getLib("remediation_results_holder").instance,
        N = UserWayWidgetApp.getLib("performance_logger");
    v.ResultsHolder = C;
    var L = A.DOM_OBSERVER_DOM_CHANGED_EVENT,
        R = (null === (m = null === W || void 0 === W ? void 0 : W.tunings) || void 0 === m ? void 0 : m.tech_rem_in_throttle_ms) ? Number(null === (y = null === W || void 0 === W ? void 0 : W.tunings) || void 0 === y ? void 0 : y.tech_rem_in_throttle_ms) : 1e3,
        k = null === (h = null === W || void 0 === W ? void 0 : W.tunings) || void 0 === h ? void 0 : h.tech_rem_dom,
        P = null === (g = null === W || void 0 === W ? void 0 : W.tunings) || void 0 === g ? void 0 : g.tech_rem_on_tab,
        I = document.querySelector("html"),
        T = E.isMobile(),
        U = N.getInstance ? N.getInstance("Remediation") : null,
        H = function() {
            if (location.pathname && location.pathname.indexOf("wp-admin") > -1) return !0;
            if (!x.commonSettings) return !1;
            var e = x.commonSettings,
                t = e.enabled,
                n = e.config,
                r = n.mobile,
                o = n.disabledPages;
            return !t || (!(!UserWayWidgetApp.ContextHolder.config.isMobile || !r || r.enabled) || !(null === o || void 0 === o || !o.some(function(e) {
                var t;
                return (null === (t = window.location) || void 0 === t ? void 0 : t.href.indexOf(e)) > -1
            })))
        },
        D = !!W.remediation && !H(),
        M = !1;
    try {
        UserWayWidgetApp.setDebugMode = function(e) {
            e ? (window.localStorage.setItem("userway-rm-debug", "1"), console.log("UserWay Remediation: Debug mode enabled")) : window.localStorage.removeItem("userway-rm-debug")
        }, M = window.localStorage.getItem("userway-rm-debug")
    } catch (e) {}
    var F = {
            iterationInProgress: !1,
            locationChanged: !0,
            domChangesEnqueued: [],
            completedEventFired: !1,
            debugMode: M
        },
        q = D ? ["REMEDIATION_SCREEN_READER_BASIC"] : [],
        j = D ? [function(e) {
            return T ? null : e
        }("REMEDIATION_KEYBOARD_NAVIGATION")].filter(Boolean) : [],
        B = [],
        Y = [],
        V = D ? ["REMEDIATION_FOCUS_STYLE", "REMEDIATION_PER_SITE", "REMEDIATION_LABS", "REMEDIATION_POPUP"] : [];
    (function() {
        return [932691].includes(UserWayWidgetApp.ContextHolder.config.services.siteId)
    })() && B.push("REMEDIATION_SOCIAL_SENSITIVITY");
    var G = [].concat(q, j, B, Y),
        K = function() {
            function n() {}
            return n.prototype.onHelperRemediationStarted = function(t) {
                e(t)
            }, n.prototype.onHelperRemediationCompleted = function(e) {
                e.backEndData && e.backEndData.items.length && _.sendBackEnd("/remediation/" + e.backEndData.path, e.backEndData.items, e.backEndData.props), C.put(e), p(e.helperName, C.getHelperPostMessagePayload(e.helperName)), t(e.helperName)
            }, n
        }();
    v.HelperCallbackAggregator = new K, (!P || function() {
        return I.hasAttribute("data-uw-w-kb")
    }() || UserWayWidgetApp.ContextHolder.config.isMobile) && u();
    var X = {
            "get-site-info": f,
            "remediation-count": d,
            "all-data": c,
            "element-is-visible": function(e) {
                var t = JSON.parse(e.data.data),
                    n = t.elements.map(function(e) {
                        return [e, _.isElementVisible(e)]
                    });
                p("element-is-visible", {
                    key: t.key,
                    elements: n
                })
            },
            "element-highlight": function(e) {
                var t = e.data.data.type,
                    n = e.data.data.value ? e.data.data.value.toLowerCase() : "",
                    r = Object.assign({
                        scroll: !0
                    }, e.data.data.options || {});
                _.highlightElements(t, n, r)
            },
            "app-key-nav-enabled": function(e) {
                s(e)
            },
            remediation: function(e) {
                var t = e.data.type;
                C.get()[t] && p(t, C.getHelperPostMessagePayload(t))
            },
            "remediation-check": function() {
                i()
            },
            "add-dynamically": l
        },
        Q = UserWayWidgetApp.getLib("REMEDIATION_FOCUS_STYLE"),
        J = {
            "custom-focus-get": function(e) {
                p("custom-focus-get", Q.getFocusStyle())
            },
            "custom-focus-update": function(e) {
                e.data && e.data.data && Q.updateOutlineStyle(e.data)
            }
        },
        Z = Object.assign({}, X, J),
        z = function(t) {
            var n = t.data || {};
            if (n.isUserWay && ("remediation" === n.action || "aria-editor" === n.action)) {
                var r = t.data.type;
                if (-1 !== Object.keys(Z).indexOf(r)) {
                    e(r);
                    (0, Z[r])(t), e(r)
                } else Z.remediation(t)
            }
        };
    E.registerPostMessageListener(z)
}();