var __values = this && this.__values || function(t) {
    var e = "function" == typeof Symbol && Symbol.iterator,
        r = e && t[e],
        o = 0;
    if (r) return r.call(t);
    if (t && "number" == typeof t.length) return {
        next: function() {
            return t && o >= t.length && (t = void 0), {
                value: t && t[o++],
                done: !t
            }
        }
    };
    throw new TypeError(e ? "Object is not iterable." : "Symbol.iterator is not defined.")
};
! function() {
    var t = UserWayWidgetApp.getLib("remediation_util");
    t.loopThroughElements(".yotpo.yotpo-small", function(e) {
        var r = e.querySelector(".standalone-bottomline");
        r && r.removeAttribute("tabindex");
        var o = e.querySelector(".yotpo-bottomline");
        if (o) {
            o.removeAttribute("tabindex");
            var i = o.querySelector("a");
            i && (t.clickOnEnter(i), i.setAttribute("role", "button"), i.setAttribute("aria-label", "view " + i.textContent))
        }
        var n = e.querySelector(".write-review-btn-hidden");
        n && (n.setAttribute("aria-label", "Write a review"), n.setAttribute("role", "button"))
    }), t.waitUntil(function() {
        return document.querySelector(".yotpo.yotpo-main-widget")
    }, function(t) {
        var e, r, o = t.querySelector(".yotpo-stars-and-sum-reviews");
        o && o.removeAttribute("tabindex");
        var i = t.querySelectorAll(".yotpo-distibutions-sum-reviews > span.yotpo-sum-reviews");
        try {
            for (var n = __values(i), a = n.next(); !a.done; a = n.next()) {
                var l = a.value,
                    u = parseInt(l.getAttribute("data-score-distribution").replace(/^\D+/g, "")),
                    s = l.textContent.replace(/^\D+/g, "");
                l.setAttribute("aria-label", "view " + s + "reviews with " + u + "stars")
            }
        } catch (t) {
            e = {
                error: t
            }
        } finally {
            try {
                a && !a.done && (r = n.return) && r.call(n)
            } finally {
                if (e) throw e.error
            }
        }
    }), t.loopThroughElements(".yotpo-block .reviews-count", function(t) {
        var e = t.textContent.replace(/^\D+/g, "");
        e && t.setAttribute("aria-label", e + " reviews")
    })
}();