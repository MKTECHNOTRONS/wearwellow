var ConvertRootLoader;
(() => {
    "use strict";
    const e = "convert-bundle-loader",
        t = "revenue-addon-bundle",
        n = "shop_name",
        o = "g_cvt_id",
        i = "rev_id";
    var r;
    [{
        name: "rev-script-bundle",
        url: `${(r=function(){let r;const d=document.getElementsByTagName("script");for(let s=0;s<d.length;s++){const a=d[s].getAttribute("src");if(!a)continue;if(d[s].hasAttribute("data-gorgias-loader-convert")&&a.includes(`${n}=`)){if(r=a.split("/").slice(0,3).join("/"),window.CONVERT_SHOP_NAME)break;const e=new URLSearchParams(a.split("?")[1]).get(n);if(e){window.CONVERT_SHOP_NAME=e;break}}const c=d[s].getAttribute("id");if(a.includes(`
        $ {
            o
        } = `)||a.includes(`
        $ {
            i
        } = `)||[e,t].includes(c)){if(r=a.split("/").slice(0,3).join("/"),window.REVENUE_ADDON_ID)break;const e=new URLSearchParams(a.split("?")[1]);[o,i].forEach((t=>{const n=e.get(t);n&&(window.REVENUE_ADDON_ID=n)}))}}return{baseUrl:window.REVENUE_ADDON_CDN||r||"https://bundle.dyn-rev.app",revision:window.REVENUE_ADDON_REVISION||"2ebcbbd"}}()).baseUrl}/script.js?rev=${r.revision}`
    }].map((e => {
            if (window.__CVT_BUNDLE_LOCKER ? .[e.name]) return void console.debug(`\ud83d\udeab Bundle ${e.name} is already loaded`);
            window.__CVT_BUNDLE_LOCKER = { ...window.__CVT_BUNDLE_LOCKER,
                [e.name]: !0
            };
            const t = document.createElement("script");
            t.src = e.url, t.id = e.name;
            const n = () => document.body.appendChild(t);
            "loading" === document.readyState ? document.addEventListener("DOMContentLoaded", n) : n()
        })),
        function() {
            if (window.GorgiasBridge) return;
            const e = {
                get(e, t) {
                    if ("init" !== t && "resolve" !== t && "_isMockFunction" !== t) throw new Error(`You are trying to use the Gorgias Bridge API before its initialization (property or function \\"${t}\\")! Please use \`GorgiasBridge.init()\`. Refer to our documentation https://developers.gorgias.com/docs/how-to-attach-gorgias-tracking-data-to-shopify-cart-and-checkout-attributes for more info.`);
                    const n = e[t];
                    return "function" == typeof n ? n.bind(e) : n
                }
            };
            window.GorgiasBridge = new Proxy({}, e);
            const t = new Promise((function(e, t) {
                window.GorgiasBridge.resolve = e
            }));
            window.GorgiasBridge.init = function() {
                return t
            }
        }(), ConvertRootLoader = {}
})();