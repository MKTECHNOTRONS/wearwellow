(() => {
    "use strict";
    const e = 1,
        t = 2,
        r = 3,
        a = 4,
        o = 5,
        n = e => {
            var t = e.parentNode && e.parentNode.children;
            if (!(t && t.length > 0)) return !1;
            if (e.className !== t[1].className) return !1;
            var r = [{
                element: t[0],
                dimension: "bottom"
            }, {
                element: e,
                dimension: "height"
            }];
            r.forEach((function(e) {
                var t = ((e, t) => {
                    if (!e) return null;
                    var r = e.getAttribute("style");
                    if (!r) return null;
                    var a = new RegExp(t + "[ ]*:[ ]*\\d+\\.{0,1}\\d*px"),
                        o = r.match(a);
                    return o && o[0] ? {
                        regExp: a,
                        style: r,
                        value: Number(o[0].replace(/\D/g, ""))
                    } : null
                })(e.element, e.dimension);
                t && t.value > 0 && (e.newStyle = t.style.replace(t.regExp, e.dimension + ":" + (t.value + 80) + "px"))
            }));
            var a = r.filter((function(e) {
                return !!e.newStyle
            }));
            if (r.length !== a.length) return !1;
            r.forEach((function(e) {
                e.element.setAttribute("style", e.newStyle)
            }))
        },
        i = e => {
            var t = e && e.children && e.children[0];
            t && t.setAttribute("style", "max-height: calc(100vh - 290px)")
        },
        s = (n, i) => {
            let s = n ? n.split("?") : [],
                c = (s.length > 1 ? s[1].split("&") : []).map((e => {
                    let t = e.split("=");
                    return {
                        key: t[0],
                        value: t[1]
                    }
                })).find((e => "utm_campaign" === e.key));
            switch (c && c.value) {
                case "offer_button":
                    return "/cart" === i ? e : t;
                case "cart_drawer":
                    return r;
                case "custom_link":
                    return a;
                case "custom_page":
                    return o;
                default:
                    return null
            }
        },
        c = ({
            className: e,
            dataGovXId: t,
            doc: r,
            innerHTML: a,
            type: o
        }) => {
            var n = r.createElement("i");
            return n.innerHTML = a || "", n.className = e || "", n.setAttribute(t, o), n
        },
        u = (a, o, s, u, l) => {
            var p = s && s.settings && s.settings.find((function(e) {
                return e.widgetType === o.widgetType
            }));
            if (!p) return !1;
            const {
                enabled: d,
                alignment: h
            } = p;
            if (!d) return !1;
            var m = (({
                doc: a,
                selector: o,
                widgetType: n
            }) => {
                if (o) {
                    var i = a.querySelector(o);
                    if (i) return {
                        element: i,
                        selector: o
                    }
                } else {
                    var s = (a => {
                            switch (a) {
                                case e:
                                    return (n = []).push(".cart " + (o = 'form[action="/cart"]') + " .cart__checkoutContainer"), n.push(".cart_top .cart_tbl " + o + " .cart_btn"), n.push(".cart-section " + o + " .offset-by-one"), n.push(".cart-section " + o), n.push(".content-area " + o + " .cart-tools"), n.push("#shopping-cart " + o + " #basket-right .cart-buttons"), n.push("#shopping-cart " + o + " #basket-right"), n.push("#shopping-cart " + o), n.push(o + " .bottompad .cart-options"), n.push("#shopify-section-cart .page-wrapper aside.cart-totals"), n.push("main .cart-wrapper__inner .container .cart-recap .card__section"), n.push(o + "#CartForm .cart-info-container"), n.push(o + " .grid--right div.cart__checkout"), n.push(o + " .cart__meta--desktop div.button-wrapper"), n.push(o + " .cart__meta--mobile div.button-wrapper"), n.push("main " + o), n.push(".main-content " + o + " .cart-footer div.cart-totals"), n.push(".main-content " + o), n.push('[role="main"] ' + o), n.push(".cart " + o), n.push(".main " + o), n.push(".bodyWrap #Cart .checkout-buttons"), n;
                                case t:
                                    return (() => {
                                        var e = [];
                                        return e.push(".ajaxcart .cart"), e.push(".nav-dialog-inner-cart .modal-cart-form"), e.push(".header-minicart-content"), e.push("#ajaxifyCart form"), e.push("#Cart.open .checkout-buttons"), e.push(".cart_menu form"), e
                                    })();
                                case r:
                                    return (() => {
                                        var e = [];
                                        return e.push("form.cart .ajaxcart__footer"), e.push("form.cart .drawer__footer"), e.push(".sticky .header-cart"), e.push(".product__add__drawer .product__add__buttons"), e.push('form[action="/checkout"] .miniCart__details'), e.push(".cart-popover .buttons-wrap"), e.push(".cart-mini-footer"), e.push(".off-canvas--right-sidebar .cart--totals"), e.push(".header-cart .cart-summary"), e.push("#cart-summary .cart-summary-subtotal"), e.push("form.cart.ajaxcart .more"), e.push(".quick-cart footer"), e.push(".cart-popup-wrapper .cart-popup"), e.push(".cart-preview"), e.push(".atc-banner--cart"), e.push(".cart-drawer-form .slide-checkout-buttons"), e.push(".product__buy .product__form-status"), e.push(".header .mini-cart .mini-cart__recap"), e.push(".header .mini-cart"), e.push(".product-menu-slideout"), e.push(".mini-cart__footer form"), e.push(".sidebar__cart form"), e.push("#cart.mm-menu li:last-child"), e.push(".cart-drawer__footer-container"), e.push("form .Drawer__Footer"), e.push(".cart-mini form .cart-footer"), e.push(".cart_notification_content"), e.push("#site-cart-form-sidebar .cart-out"), e.push(".cart-summary-overlay__column-subtotal"), e.push("#shopify-section-header .mini-cart__buttons"), e.push(".ajaxified-cart-feedback.success"), e.push("form.drawer__contents .drawer__footer"), e
                                    })();
                                default:
                                    return []
                            }
                            var o, n
                        })(n),
                        c = ((e, t) => {
                            for (var r = 0; r < t.length; r++) {
                                var a = t[r],
                                    o = e.querySelector(t[r]);
                                if (o) return {
                                    element: o,
                                    selector: a
                                }
                            }
                            return null
                        })(a, s);
                    if (c) return {
                        element: c.element,
                        selector: c.selector
                    }
                }
                return null
            })({
                doc: a,
                selector: p.selector,
                widgetType: o.widgetType
            });
            const {
                element: f,
                selector: g
            } = m || {};
            if (!f || !g) return !1;
            var v = ((e, t, r, a, o, n, i) => {
                if (!o) return !1;
                var s = (e => {
                    switch (e) {
                        case ".header .mini-cart":
                        case "#cart.mm-menu li:last-child":
                            return !1
                    }
                    return !0
                })(a);
                if (s && o.clientWidth < 1) return !1;
                var u = (({
                    button: e,
                    dataGovXId: t
                }) => {
                    var r = [];
                    r.push(`.${e.full.className}`), r.push(`.${e.slim.className}`), r.push(`[${t}]`);
                    for (var a = 'img[src="https://i', o = ".govx.net/images/cdn/govxid-shopify-iapp-icon", n = '.jpg"]', i = 1; i < 6; i++) r.push(`${a}${i}${o}${n}`), r.push(`${a}${i}${o}-50x50${n}`);
                    return r
                })({
                    button: e,
                    dataGovXId: t
                });
                if (u.filter((function(e) {
                        return o.querySelector(e)
                    })).length > 0) return !1;
                var l = n === e.slim.type ? e.slim.innerHTML : e.full.innerHTML,
                    p = c({
                        dataGovXId: t,
                        doc: r,
                        innerHTML: l,
                        type: n
                    }),
                    d = (({
                        alignment: e,
                        button: t,
                        doc: r,
                        checkWidth: a,
                        child: o,
                        parent: n,
                        type: i
                    }) => {
                        var s = [];
                        return s.push(i === t.slim.type ? t.slim.className : t.full.className), s.push(e ? `govx-${e}` : ""), s.push(n.clientWidth < 300 ? "govx-mini" : n.clientWidth < 350 ? "govx-min" : n.clientWidth > 350 ? "govx-max" : ""), s.push(!a || n.clientWidth === r.body.clientWidth && r.body.clientWidth === o.clientWidth ? "govx-sides" : ""), s.filter((e => !!e)).join(" ")
                    })({
                        alignment: i,
                        button: e,
                        doc: r,
                        checkWidth: s,
                        child: p,
                        parent: o,
                        type: n
                    });
                return p.className = d, o.appendChild(p), !0
            })(u, l, a, g, f, o.button, h);
            if (!v) return !1;
            var y = ((e, t) => e === r ? (e => {
                switch (e) {
                    case "form.cart .ajaxcart__footer":
                    case "form.cart .drawer__footer":
                        return n;
                    case ".sticky .header-cart":
                        return i
                }
                return null
            })(t) : null)(o.widgetType, g);
            return "function" == typeof y && y(f), v
        };

    function l(e, t, r, a, o, n) {
        var i = e && e.href || e;
        t = t || 450, r = r || 700, o = o || window;
        var s = (a = a || document).documentElement,
            c = s.clientWidth,
            u = s.clientHeight,
            l = o.innerWidth,
            p = o.innerHeight,
            d = o.screenLeft,
            h = o.screenTop,
            m = null != d ? d : o.screenX,
            f = null != h ? h : o.screenY,
            g = (l || c || screen.width) / 2 - t / 2 + m,
            v = (p || u || screen.height) / 2 - r / 2 + f,
            y = o.open(i, "GovX ID Authorization", "width=" + t + ",height=" + r + ",top=" + v + ",left=" + g);
        return n && (n.pop = y), !1
    }
    const p = e => `a[href^='${e}/shopify/verify']`,
        d = e => `button[data-govx-href^='${e}/shopify/verify']`,
        h = ({
            cta: e,
            ctaPopup: t
        }) => {
            if (!e || !e.dataset) return;
            let r = "time";
            if (Number(e.dataset[r]) > 0);
            else {
                let a = (new Date).getTime();
                e.dataset[r] = a;
                let o = e.href || e.dataset.govxHref;
                e.href && (e.target = "popup", e.href = "#"), e.onclick = () => t(o)
            }
        },
        m = (a, o) => {
            const {
                authorizationBaseUri: n,
                layout: i,
                css: c,
                dataGovXId: m,
                govxId: f,
                widgets: g
            } = o;
            let v = i;
            return (({
                doc: e,
                css: t,
                govxId: r,
                widgets: a
            }) => {
                const o = "style";
                var n = `${r}-${o}`;
                if (!(e.querySelectorAll(`${o}#${n}`).length > 0)) {
                    var i = e.createElement(o);
                    i.id = n, i.innerHTML = (({
                        css: e,
                        widgets: t
                    }) => `${e||""}${t&&t.length?" "+t.map((e=>e.css)).join(" "):""}`)({
                        css: t,
                        widgets: a
                    }), e.getElementsByTagName("head")[0].appendChild(i)
                }
            })({
                doc: a,
                css: c,
                govxId: f,
                widgets: g
            }), (({
                button: a,
                dataGovXId: o,
                doc: n,
                widgets: i
            }) => {
                var s = [];
                s.push({
                    button: a.slim.type,
                    widgetType: r
                }), s.push({
                    button: a.full.type,
                    widgetType: t
                }), s.push({
                    button: a.full.type,
                    widgetType: e
                }), s.map((e => u(n, e, i, a, o)))
            })({
                button: v,
                dataGovXId: m,
                doc: a,
                widgets: g
            }), (({
                layout: e,
                dataGovXId: t,
                doc: r
            }) => {
                for (var a = r.querySelectorAll(`[${t}]`), o = 0, n = a.length; o < n; o++) {
                    var i = a[o];
                    if (!i.innerHTML && i.dataset) {
                        var s = "",
                            c = "";
                        switch (i.dataset.govxId) {
                            case e.slim.abbreviation:
                            case e.slim.type:
                                s = e.slim.className, c = e.slim.innerHTML;
                                break;
                            case e.page.abbreviation:
                            case e.page.type:
                                s = e.page.className, c = e.page.innerHTML
                        }
                        if (!c) {
                            if (i.dataset.govxId && i.dataset.govxId.length) continue;
                            s = e.full.className, c = e.full.innerHTML
                        }
                        i.className = s, i.innerHTML = c
                    }
                }
            })({
                layout: i,
                dataGovXId: m,
                doc: a
            }), (({
                doc: e,
                authorizationBaseUri: t,
                ctaPopup: r
            }) => {
                let a = e.querySelectorAll(p(t));
                for (var o = 0, n = a.length; o < n; o++) h({
                    cta: a[o],
                    ctaPopup: r
                });
                let i = e.querySelectorAll(d(t));
                for (o = 0, n = i.length; o < n; o++) h({
                    cta: i[o],
                    ctaPopup: r
                })
            })({
                doc: a,
                authorizationBaseUri: n,
                ctaPopup: l
            }), (({
                doc: e,
                settings: t,
                authorizationBaseUri: r
            }) => {
                t.reportTimeoutId && (window.clearTimeout(t.reportTimeoutId), t.reportTimeoutId = 0), t.reportTimeoutId = window.setTimeout((() => (({
                    doc: e,
                    settings: t,
                    authorizationBaseUri: r
                }) => {
                    if (t.reported) return;
                    let a = (({
                        doc: e,
                        authorizationBaseUri: t
                    }) => {
                        let r = e && e.location && e.location.pathname,
                            a = {},
                            o = e.querySelectorAll(p(t));
                        for (var n = 0, i = o.length; n < i; n++) a[s(o[n] && o[n].href, r)] = 1;
                        let c = e.querySelectorAll(d(t));
                        for (n = 0, i = c.length; n < i; n++) a[s(c[n] && c[n].dataset && c[n].dataset.govxHref, r)] = 1;
                        let u = [];
                        for (var l in a) l && u.push(Number(l));
                        return u
                    })({
                        doc: e,
                        authorizationBaseUri: r
                    });
                    if ((a && a.length || 0) < 1) return;
                    t.reported = !0;
                    const {
                        live: o,
                        tunnelUri: n,
                        myShopifyDomain: i
                    } = t;
                    o > 0 || (({
                        doc: e,
                        src: t
                    }) => {
                        var r = e.createElement("script");
                        r.src = t, e.getElementsByTagName("head")[0].appendChild(r)
                    })({
                        doc: e,
                        src: `${n}/api/${i}/live.js`
                    })
                })({
                    doc: e,
                    settings: t,
                    authorizationBaseUri: r
                })), 500)
            })({
                doc: a,
                settings: o,
                authorizationBaseUri: n
            }), !1
        },
        f = ({
            layout: e,
            format: t,
            value: r
        }) => {
            if (!r) return e;
            for (const a in e)
                if (e.hasOwnProperty(a)) {
                    let o = "function" == typeof t ? t(a) : t,
                        n = r.length ? r : r[a];
                    const i = new RegExp(o, "g");
                    e[a].innerHTML = e[a].innerHTML.replace(i, n)
                }
            return e
        };
    (() => {
        let e = (e => {
            var t = null;
            try {
                t = JSON.parse(e)
            } catch (e) {
                console.log("error", e)
            }
            if (!t) return;
            const r = "govx-id";
            t.css = "[data-govx-id]{width:100%;}[data-govx-id] .govx-id-text{fill:#231f20;}[data-govx-id] .govx-id-shield{fill:#ee6337;}.govx-id-full-wrapper{font-style:normal;clear:both;display:flex;font-family:sans-serif;padding:20px 0 !important;margin:0 auto;}.govx-id-full-wrapper.govx-mini{padding-left:0 !important;padding-right:0 !important;}.govx-id-full-wrapper.govx-sides{padding:20px 20px !important;}.govx-id-full-wrapper.govx-left{justify-content:flex-start;}.govx-id-full-wrapper.govx-center{justify-content:center;}.govx-id-full-wrapper.govx-right{justify-content:flex-end;}.preview .govx-id-full-wrapper{padding:inherit;height:auto;}.govx-id-full-wrapper a{color:#3d4246;text-decoration:none;}.govx-id-full-wrapper p{font-size:13px;font-family:sans-serif;letter-spacing:0.45px !important;margin:0 0 19.44444px;color:#333;}.govx-id-full-wrapper.govx-mini .govx-id-full,.govx-id-full-wrapper.govx-min .govx-id-full{width:100% !important;min-width:auto !important;}.govx-id-full-wrapper .govx-id-full{width:35%;min-width:325px;max-width:350px;text-align:left;line-height:1.5;font-size:12px;font-family:sans-serif;padding:15px;color:#333 !important;background-color:#fff;border:1px solid #eee;}.preview .govx-id-full-wrapper .govx-id-full{width:auto;}@media only screen and (max-width:749px){.govx-id-full-wrapper .govx-id-full{width:100%;padding:1em;margin-left:0;}}.govx-id-full-wrapper .govx-id-full .govx-id-button{width:100%;font-size:13px;font-family:sans-serif;border:1px solid #ddd;background-color:#eee;padding:1em 0;text-align:center;text-decoration:none;display:inline-block;}.govx-id-full-wrapper .govx-id-full .govx-id-button:hover{background-color:#fff;}.govx-id-full-wrapper .govx-id-full a.govx-id-link{font-size:12px !important;display:block;text-align:right;color:#00a1df;padding-top:5px;border:0;}.govx-id-full-wrapper .govx-id-button-content{display:flex;justify-content:center;}.govx-id-button img{display:block !important;margin:auto;width:114px !important;height:18px !important;}.govx-id-slim-wrapper{font-style:normal;clear:both;display:block !important;width:100%;padding:20px 0 !important;letter-spacing:initial;text-transform:none;}.govx-id-slim-wrapper .govx-id-slim{display:flex !important;}.govx-id-slim-wrapper.govx-sides{width:calc(100% - 40px);padding:20px 20px !important;}.govx-id-slim-wrapper.govx-max .govx-id-slim a{max-width:350px !important;}.govx-id-slim-wrapper.govx-left .govx-id-slim{justify-content:flex-start;}.govx-id-slim-wrapper.govx-center .govx-id-slim{justify-content:center;}.govx-id-slim-wrapper.govx-right .govx-id-slim{justify-content:flex-end;}[data-product-menu-state=\'addtocart\'] .product-menu-slideout [data-govx-id=\'slim\'].govx-id-slim-wrapper{display:none !important;}.header .mini-cart .mini-cart__recap .govx-id-slim-wrapper{padding:20px 0 0 0 !important;}.govx-id-slim-wrapper .govx-id-slim a{display:flex;width:100% !important;border:1px solid #eee;color:#333 !important;background-color:white !important;flex-direction:row;padding:10px;justify-content:flex-start;text-align:left;text-decoration:none;}.govx-id-slim img{width:50px;height:50px;max-width:50px;}.govx-id-slim .govx-icon{display:block;flex-grow:0;align-self:center;width:50px;height:50px;}.govx-id-slim .govx-text{display:block;flex-grow:2;flex-wrap:wrap;align-self:center;padding-left:15px;max-width:400px;}.govx-id-slim .govx-text p{color:#333;line-height:16px;font-size:14px;margin:0px;}.govx-id-slim .govx-text span{font-weight:400;font-size:13px;white-space:normal;font-family:sans-serif;}.govx-id-page li{list-style-type:disc;list-style-position:inside;}.govx-id-page .govx-id-cta-wrapper{padding:0 0 16px 0;}.govx-id-page .govx-id-cta-wrapper,.govx-id-page .govx-id-cta{display:flex;justify-content:center;}.govx-id-page .govx-id-cta a{display:block;text-decoration:none;padding:.2em 2em;}.govx-id-page .govx-id-cta{width:250px !important;}.govx-id-page .govx-id-cta .shopify-product-form,.govx-id-page .govx-id-cta .shopify-payment-button,.govx-id-page .govx-id-cta button,.govx-id-page .govx-id-cta button.shopify-payment-button__button,.govx-id-page .govx-id-cta button.shopify-payment-button__button--unbranded{width:100% !important;}.govx-id-page button.govx-custom{border-radius:2px;padding:8px 16px;border:0;margin:16px 0;background-color:#eeeeee;font-weight:bold;font-size:18px;}.govx-id-page .govx-id svg{background-color:#fff;width:100px !important;height:35px !important;}.govx-widget-footer{display:flex;justify-content:center;flex-wrap:wrap;align-items:center;padding:16px 0;border-top:solid 1px #e3e3e3;border-bottom:solid 1px #e3e3e3;margin:48px 0;text-align:center;}.govx-widget-footer .footer-item{width:100%;}.govx-widget-footer .footer-item.govx-id{margin-top:8px;}.govx-widget-footer .footer-item.govx-id a{border-bottom:none;}.govx-widget-footer .footer-item.learn-more{display:none;}.govx-widget-footer .govx-id img{border-width:0 !important;}@media only screen and (min-width:749px){.govx-widget-footer .footer-item{width:auto;}.govx-widget-footer .footer-item.govx-id{margin-top:0;}.govx-widget-footer .footer-item.govx-id{position:relative;top:5px;}.govx-widget-footer .footer-item.learn-more{display:inline;}}", t.dataGovXId = `data-${r}`, t.govxId = r;
            let {
                discount: a,
                groups: o,
                myShopifyDomain: n,
                page: i
            } = t;
            return t.layout = (({
                discount: e,
                govxId: t,
                groups: r,
                myShopifyDomain: a,
                page: o
            }) => {
                let n = {
                        full: {
                            type: "full",
                            abbreviation: "f",
                            innerHTML: '<div class="govx-id-full"><p> %%GROUPS_FULL%% discount available. Verify with GovX ID to instantly unlock your savings. </p><a aria-label="GOVX ID link opens in a new tab" title="GovX ID Button" target="_blank" data-action="govx-id-pop" class="govx-id-button" href="https://auth.govx.com/shopify/verify?shop=%%MY_SHOPIFY_DOMAIN%%&utm_source=shopify&utm_medium=govxid&utm_campaign=offer_button"><img alt="Logo for GOVX ID, a service used to verify military, first responder, nurse or teachers to qualify them for discounts" loading="lazy" width="114" height="18" src="https://i6.govx.net/images/8189555_govxid_shield_text_landscape.svg?v=wgGqNqf+r21wg7TPtKIPXQ==" /></a><a class="govx-id-link" href="https://www.govx.com/t/govx-id" target="_blank">What is GovX ID?</a></div>',
                            className: `${t}-full-wrapper`
                        },
                        slim: {
                            type: "slim",
                            abbreviation: "s",
                            innerHTML: '<span class="govx-id-slim"><a title="GovX ID Link" target="_blank" data-action="govx-id-pop" href="https://auth.govx.com/shopify/verify?shop=%%MY_SHOPIFY_DOMAIN%%&utm_source=shopify&utm_medium=govxid&utm_campaign=cart_drawer"><img alt="Logo for GOVX ID, a service used to verify military, first responder, nurse or teachers to qualify them for discounts" loading="lazy" width="50" height="50" src="https://i5.govx.net/images/644224_govxid_new_logo_shopify_iapp_icon.svg?v=sQZpXJ91ehIbui8BnZNMVw==" /><span class="govx-text"><p><span>%%GROUPS_SLIM%% discount available</span></p></span></a></span>',
                            className: `${t}-slim-wrapper`
                        },
                        page: {
                            type: "page",
                            abbreviation: "p",
                            innerHTML: '<meta charset="utf-8" /><div class="govx-id-page"><p style="text-align: center;">%%MESSAGE_TEXT%%</p><div class="govx-id-cta-wrapper" %%CUSTOMIZE_0%%><div class="govx-id-cta"><div class="shopify-product-form product_payments_btns smart-wrapper"><div class="shopify-payment-button"><button class="shopify-payment-button__button shopify-payment-button__button--unbranded" aria-label="GOVX ID link opens in a new window" data-govx-href="https://auth.govx.com/shopify/verify?shop=%%MY_SHOPIFY_DOMAIN%%&utm_source=shopify&utm_medium=govxid&utm_campaign=custom_page"> Save up to %%DISCOUNT_TEXT%% </button></div></div></div></div><div class="govx-id-cta-wrapper" %%CUSTOMIZE_1%% ><div class="govx-id-cta"><a class="govx-custom" aria-label="GOVX ID link opens in a new window" %%BUTTON_STYLE%% target="_blank" href="https://auth.govx.com/shopify/verify?shop=%%MY_SHOPIFY_DOMAIN%%&utm_source=shopify&utm_medium=govxid&utm_campaign=custom_page"> Save up to %%DISCOUNT_TEXT%% </a></div></div><p><strong>This offer is eligible for:</strong></p> %%GROUPS_PAGE%% <p><strong>How it works:</strong></p><ul><li>Click the button to claim your discount and you\'ll be asked to verify your affiliation with GovX ID. Verification is real-time and secure. If you already have a GovX ID account, just log in!</li><li>After you verify, you\'ll receive a single-use discount code to apply at checkout. Be sure to copy your code.</li><li>For future purchases, simply log in with your GovX ID to unlock a new discount code.</li><li>There is a limit of one discount code per day.</li></ul><div class="govx-widget-footer"><div class="footer-item">Verification is powered by&nbsp;&nbsp;&nbsp;</div><div class="footer-item govx-id"><a href="https://www.govx.com/t/govx-id" aria-label="GOVX ID link opens in a new tab" target="_blank" rel="noopener noreferrer"><img alt="Logo for GOVX ID, a service used to verify military, first responder, nurse or teachers to qualify them for discounts" loading="lazy" width="114" height="18" src="https://i6.govx.net/images/8189555_govxid_shield_text_landscape.svg?v=wgGqNqf+r21wg7TPtKIPXQ==" /></a></div><div class="footer-item learn-more"> &nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp; <a href="https://www.govx.com/t/govx-id" aria-label="GOVX ID link opens in a new tab" target="_blank" rel="noopener noreferrer">Learn more</a></div></div></div>',
                            className: `${t}-page-wrapper`
                        }
                    },
                    i = e ? "percentage" === e.type ? `${e.value}%` : `$${e.value}` : "",
                    s = (e ? e.message : "").replace(/\n/g, "<br/>"),
                    c = n.page.innerHTML,
                    u = !1;
                if (o) {
                    let {
                        customize: e,
                        buttonColorBackground: t,
                        buttonColorForeground: r
                    } = o;
                    u = e, c = c.replace("%%BUTTON_STYLE%%", u ? `style="background-color:${t};color:${r};"` : "")
                }
                return c = c.replace(`%%CUSTOMIZE_${u?0:1}%%`, 'style="display:none"'), c = c.replace(`%%CUSTOMIZE_${u?1:0}%%`, ""), n.page.innerHTML = c, f({
                    layout: n,
                    format: "%%MESSAGE_TEXT%%",
                    value: s
                }), f({
                    layout: n,
                    format: "%%DISCOUNT_TEXT%%",
                    value: i
                }), f({
                    layout: n,
                    format: "%%MY_SHOPIFY_DOMAIN%%",
                    value: a
                }), f({
                    layout: n,
                    format: e => `%%GROUPS_${e.toUpperCase()}%%`,
                    value: r
                }), n
            })({
                discount: a,
                govxId: r,
                groups: o,
                myShopifyDomain: n,
                page: i
            }), t
        })('{\"discount\":{\"message\":\"To thank you for your service, we\'ve partnered with GovX to offer a discount on our store.\",\"type\":\"percentage\",\"value\":25},\"groups\":{\"page\":\"<ul><li>Current & former U.S. military</li><li>Military spouses & dependents</li><li>First responders including law enforcement, fire, and EMS</li><li>Teachers (K-12 and University teachers/staff)</li></ul>\",\"full\":\"Military, First Responder and Teacher\",\"slim\":\"Military, First Responder and Teacher\"},\"live\":1,\"myShopifyDomain\":\"wearwellow.myshopify.com\",\"page\":null,\"widgets\":{\"settings\":[]},\"authorizationBaseUri\":\"https://auth.govx.com\",\"tunnelUri\":\"https://id-shop.govx.com\"}');
        e && (((e, t) => {
            m(e, t), ((e, t) => {
                "function" == typeof MutationObserver && new MutationObserver((r => {
                    for (var a = !1, o = 0, n = r.length; o < n; o++) switch (r[o].type) {
                        case "attributes":
                        case "childList":
                        case "subtree":
                            a = !0
                    }
                    return !!a && m(e, t)
                })).observe(e.body, {
                    attributes: !0,
                    childList: !0,
                    subtree: !0
                })
            })(e, t)
        })(document, e), window.GovXIdApi = {
            test: function({
                selector: t,
                type: r
            }) {
                return (({
                    dataGovXId: e,
                    doc: t,
                    selector: r,
                    type: a
                }) => {
                    var o = t.querySelector(r);
                    o && o.appendChild(c({
                        dataGovXId: e,
                        doc: t,
                        type: a
                    })), console.log({
                        selector: r,
                        type: a,
                        parent: o
                    })
                })({
                    dataGovXId: e.dataGovXId,
                    doc: document,
                    selector: t,
                    type: r
                })
            },
            popup: function(e) {
                return l(e)
            },
            refresh: function() {
                return m(document, e)
            }
        })
    })()
})();