(function() {
    function bxBootstrap() {
        var re = /bot|crawl|slurp|spider|mediapartners|headlesschrome|snap-prefetch|remotasks|woorank|uptime\.com|facebookexternalhit|facebookcatalog/i;
        if (re.test(navigator.userAgent) || navigator.userAgent == '') {
            return;
        }

        if (!(window.bouncex && bouncex.website)) {
            var pushedData = [];
            if (window.bouncex && bouncex.push && bouncex.length) {
                pushedData = bouncex;
            }
            window.bouncex = {};
            bouncex.pushedData = pushedData;
            bouncex.website = {
                "id": 6265,
                "name": "Wellow",
                "cookie_name": "bounceClientVisit6265",
                "domain": "wearwellow.com",
                "ct": "fp_local_storage",
                "ally": 0,
                "ei": 0,
                "tcjs": "",
                "cjs": "",
                "force_https": false,
                "waypoints": false,
                "content_width": 900,
                "gai": "UA-207319543-1",
                "swids": "",
                "sd": 0,
                "ljq": "auto",
                "campaign_id": 0,
                "is_preview": false,
                "aco": {
                    "first_party_limit": "3500",
                    "local_storage": "1"
                },
                "cmp": {
                    "gdpr": 0,
                    "gmp": 0,
                    "whitelist_check": 0
                },
                "burls": [],
                "ple": false,
                "fbe": true,
                "ffs": "",
                "mas": 2,
                "map": 1,
                "gar": true,
                "ete": 1,
                "ettm": false,
                "etjs": "/* ---------------------------- STANDARD VARIABLES ---------------------------- */\n\nvar CART_COOKIE_KEY = 'cart',\n    CLEAN_URL = bouncex.utils.url.allowParams(),\n    ROOT_DOMAIN = window.location.hostname.replace('www.', '');\n\n/* --------------------------------- CUSTOMIZATION VARIABLES -------------------------------- */\n\nvar soldOutItemsOnSite = true,\n    pdpAtcSelector = 'form[action=\"/cart/add\"] button[type=\"submit\"]',\n    outOfStockSelector = 'button[product-form__submit]:contains(\"Sold Out\")';\n\n/* --------------------------------- HELPERS -------------------------------- */\n\nfunction getPackId(packSize){\n    var itemId;\n\n    jQuery('.pack-variant-options .HorizontalList__Item input').each(function(i,e){\n        var dataProduct = bouncex.parseJSON(jQuery(e).attr('data-product')),\n            title = dataProduct.title;\n\n        if (packSize && title.indexOf(packSize) > -1){\n            itemId = dataProduct.id;\n        }\n\t});\n\treturn itemId;\n}\n\nfunction getGroupId(){\n    var packSize = +jQuery('.ProductForm__SelectedValue.PackTitle').text();\n    if (!!jQuery('#pack-select').length && packSize > 1){\n        return getPackId(packSize);\n    }\n    return jQuery('input[id^=\"color_\"][name^=\"color_group\"]:checked').attr('data-product-id') || bouncex.utils.getNestedProp('ShopifyAnalytics.meta.product.id', '');\n}\n\nfunction getItemId(){\n    // if there is a pack select available get the groupId based on the pack size\n    // var packSize = +jQuery('.ProductForm__SelectedValue.PackTitle').text();\n    // if (!!jQuery('#pack-select').length && packSize > 1){\n    //     return getPackId(packSize);\n    // }\n    return jQuery('input[id^=\"color_\"][name^=\"color_group\"]:checked').attr('data-product-id') || bouncex.utils.getNestedProp('ShopifyAnalytics.meta.product.id', '');\n}\n\n// logic ensures that on multi pack pages we are including the pack size in the item copy\nfunction getItemCopy(){\n    var itemCopy = jQuery('.ProductMeta__Title.Heading').first().text().trim(),\n        title = jQuery('meta[property=\"og:title\"]').attr('content');\n\n    if (title.indexOf(itemCopy) > -1){\n        return title;\n    }\n\n    return itemCopy.split(' - ').shift();\n}\n\nfunction getItemImage(){\n    var imgUrl = jQuery('meta[property=\"og:image:secure_url\"]').attr('content') ||\n        jQuery('.Product__SlideItem[data-image-media-position=\"0\"] img:first').attr('data-original-src') ||\n        jQuery('.Product__SlideItem[data-image-media-position=\"0\"] img:first').attr('srcset');\n\n    if (!imgUrl){\n        return false;\n    }\n\n    imgUrl = bouncex.utils.url.allowParams([], imgUrl.replace(/\\s+/g, ''));\n\n    if (imgUrl.indexOf('http') === -1){\n        return 'https:' + imgUrl;\n    }\n\n    return imgUrl;\n}\n\nfunction getItemInStock(){\n    if (!soldOutItemsOnSite){\n        return true;\n    }\n\n    if (outOfStockSelector && jQuery(outOfStockSelector).length > 0){\n        return false;\n    }\n\n    return jQuery(pdpAtcSelector).length > 0 ? !jQuery(pdpAtcSelector).is(':disabled') && jQuery(pdpAtcSelector).is(':visible') : true;\n}\n\nfunction isExludedProduct(productId) {\n    var EXCLUSIONS = [8207630336215];\n\n    return EXCLUSIONS.indexOf(productId) > -1;\n}\n\n/* ------------------------------ ITEM TRACKING ----------------------------- */\n\n\nfunction getItem() {\n    return {\n        id: getItemId(),\n        copy: getItemCopy(),\n        category: 'Global',\n        url: CLEAN_URL,\n        imageurl: getItemImage(),\n        instock: getItemInStock(),\n        excluded: isExludedProduct(getItemId())\n    };\n}\n\nfunction fireViewItem(id) {\n    bouncex.push(['view item', {\n        'item:id': id,\n        'item:itemgroupid': id\n    }]);\n}\n\nfunction initializeItemEvents() {\n    var item;\n\n    bouncex.et.onTrue(\n        function () {\n            item = getItem();\n            return !!item.id &&\n                !!item.copy &&\n                !!item.category &&\n                !!item.url &&\n                !!item.imageurl;\n        },\n        function () {\n            if (item.url.indexOf('gift-card') > -1) {\n                return;\n            }\n            bouncex.push(['item', item]);\n            fireViewItem(item.id, item.id);\n            initializeSkuEvents(item.id);\n        },\n        10\n    );\n}\n\n/* ------------------------------ SKU TRACKING ------------------------------ */\nfunction getSku(){\n    if (jQuery('select#pack-select option:selected').length){\n        return jQuery('select#pack-select option:selected').val();\n    }\n    return jQuery('select[name=\"id\"][title=\"Variant\"]').first().val();\n}\n\n/* ------------------------------ SKU TRACKING - DO NOT EDIT -  ------------------------------ */\nfunction initializeSkuEvents(itemId) {\n    var allVariantsSelector = '.ProductForm__Variants li input',\n        minVariants = 2, // minimum number of variants required to trigger select_sku on page load\n        lastSkuFired,\n        groupId,\n        skuId;\n\n\n    /*\n        fire select sku on default for items with only one or no variations\n        Update minVariants accordingly\n    */\n    if (jQuery(allVariantsSelector).length <= minVariants){\n        skuId = getSku();\n        if (skuId){\n            fireSelectSku(itemId, itemId, skuId);\n        }\n        return;\n    }\n\n    bouncex.et.on(jQuery(allVariantsSelector),'click.bxsku',function () {\n        var isPack = jQuery(this).hasClass('PackSwatch__Radio') && !!jQuery(this).attr('data-product');\n\n        if (isPack){\n            itemId = bouncex.parseJSON(jQuery(this).attr('data-product')).id;\n        }\n\n        bouncex.setTimeout2(function() {\n            bouncex.et.onTrue(function () {\n                skuId = getSku();\n                groupId = getGroupId();\n                return skuId && groupId && skuId !== lastSkuFired;\n            }, function () {\n                fireSelectSku(itemId, groupId, skuId);\n                lastSkuFired = skuId;\n            }, 5);\n        }, 1000);\n    });\n}\n\nfunction fireSelectSku(itemId, groupId, skuId){\n    bouncex.push([\n        'select_sku',\n        {\n            'item:id': itemId,\n            'item:itemgroupid': groupId,\n            'item:feedid': skuId\n        }\n    ]);\n}\n\n/* ---------------------------- CATEGORY TRACKING --------------------------- */\n\nfunction getItemIdsCat() {\n    var ids = [],\n        $tiles = bouncex.utils.getNestedProp('ShopifyAnalytics.meta.products', []);\n\n    for (var i = 0; i < $tiles.length; i++ ) {\n        var id = $tiles[i].id;\n\n        if (!!id && ids.indexOf(id) === -1){\n            ids.push(id);\n        }\n    }\n\n    return ids.join(',');\n}\n\n\nfunction getItemIdsSearch(){\n    var ids = [],\n        tileSelector = 'div[data-product-id]';\n\n    jQuery(tileSelector).each(function () {\n        var id = jQuery(this).attr('data-product-id');\n\n        if (id && ids.indexOf(id) < 0) {\n            ids.push(id);\n        }\n    });\n\n    return ids.join(',');\n}\n\nfunction getCategoryObject() {\n    var itemIds =  bouncex.website.pts === 'category' ? getItemIdsCat() : getItemIdsSearch();\n\n    return {\n        'page:url': bouncex.utils.url.allowParams('q'),\n        'items:ids': itemIds\n    };\n}\n\nfunction initializeCategoryEvents() {\n    var categoryObj;\n\n    bouncex.et.onTrue(\n        function () {\n            categoryObj = getCategoryObject();\n            return !!categoryObj['items:ids'].length &&\n                !!categoryObj['page:url'];\n        },\n        function () {\n            bouncex.push(['view category', categoryObj]);\n        },\n        10\n    );\n}\n\n/* ------------------------------- CART EVENTS ------------------------------ */\n\nfunction fireAddToCart(itemId) {\n    var token;\n\n    bouncex.et.onTrue(\n        function () {\n            bouncex.co;\n            token = bouncex.getBounceCookie(CART_COOKIE_KEY);\n            return token;\n        },\n        function () {\n            bouncex.push([\n                'add to cart',\n                {\n                    'item:id': itemId,\n                    'cart:token': token\n                }\n            ]);\n\n            if (bouncex.vars.cart) {\n                return;\n            }\n\n            bouncex.setVar('cart', true);\n        },\n        10\n    );\n}\n\nfunction emptyCart() {\n    bouncex.et.onVarChange('cart_qty', function (oldVal, newVal) {\n        if (bouncex.vars.cart && newVal === 0 && oldVal > 0) {\n            bouncex.push(['empty_cart']);\n            bouncex.setVar('cart', false);\n        }\n    });\n}\n\nfunction initializeCartEvents() {\n    bouncex.et.cart.init({\n        replenishmentType: 'cookie',\n        replenish: function (cart) {\n            bouncex.utils.cookies.create({\n                name: CART_COOKIE_KEY,\n                value: cart.token\n            });\n            replenComplete();\n        }\n    });\n\n    function replenComplete() {\n        window.location.href = CLEAN_URL + '?bx_replen=true';\n    }\n\n    emptyCart();\n\n    bouncex.et.onVarChange('cart_qty', function (oldVal, newVal) {\n        if (newVal > oldVal) {\n            var itemId = bouncex.parseJSON(jQuery('.side-cart-data').first().text()).items.pop().product_id;\n            if (itemId) {\n                fireAddToCart(itemId);\n            }\n        }\n    });\n}\n\n/* ------------------------------ USER TRACKING ----------------------------- */\n\nfunction getUserEmail(){\n\tvar pixelScriptText = jQuery('#web-pixels-manager-setup').text(),\n\t\temailPattern = /[\\w.-]+@[\\w.-]+\\.[\\w]+/,\n\t\temailMatch = pixelScriptText.match(emailPattern) || [];\n\n\treturn emailMatch[0];\n}\n\nfunction initializeUserTracking() {\n    if (!bouncex.vars.logged_in || !!bouncex.vars.logged_in_identified) {\n        return;\n    }\n\n    var userEmail;\n\n    bouncex.et.onTrue(\n        function () {\n            userEmail = getUserEmail();\n            return bouncex.utils.validate.email(userEmail);\n        },\n        function () {\n            bouncex.push([\n                'user',\n                {\n                    'email': userEmail,\n                    'source': 'LoggedIn'\n                }\n            ]);\n            bouncex.setVar('logged_in_identified', true);\n        },\n        5\n    );\n}\n\n/* --------------------------- INITIALIZE TRACKING -------------------------- */\n\nfunction isValidDomain() {\n    if (!bouncex.vars.location_path){\n        return ROOT_DOMAIN === bouncex.website.domain;\n    }\n\n    return ROOT_DOMAIN === bouncex.website.domain && window.location.pathname.indexOf(bouncex.vars.location_path) > -1;\n}\n\nfunction isEn() {\n    return bouncex.html.attr('lang') === 'en';\n}\n\nfunction isValidForTracking() {\n    return isValidDomain() && isEn();\n}\n\nfunction init() {\n    if (!isValidForTracking()) {\n        return;\n    }\n\n    initializeUserTracking();\n    initializeCartEvents();\n\n    switch (bouncex.website.pts) {\n        case 'category':\n        case 'search':\n            initializeCategoryEvents();\n            break;\n        case 'product':\n            initializeItemEvents();\n            break;\n        default:\n            break;\n    }\n}\n\n\ninit();",
                "dge": true,
                "bxidLoadFirst": false,
                "pie": true,
                "cme": true,
                "gbi_enabled": 0,
                "bpush": false,
                "pt": {
                    "cart": {
                        "testmode": false,
                        "val": [
                            [{
                                "activation": "current_page_url",
                                "prop": "contains",
                                "prop2": "",
                                "prop3": "",
                                "val": "/cart"
                            }]
                        ]
                    },
                    "category": {
                        "testmode": false,
                        "val": [
                            [{
                                "activation": "js",
                                "prop": "",
                                "prop2": "",
                                "prop3": "",
                                "val": "bouncex.utils.getNestedProp('ShopifyAnalytics.meta.page.pageType') === 'collection';\r\n"
                            }]
                        ]
                    },
                    "checkout": {
                        "testmode": false,
                        "val": [
                            [{
                                "activation": "current_page_url",
                                "prop": "contains",
                                "prop2": "",
                                "prop3": "",
                                "val": "/checkout"
                            }]
                        ]
                    },
                    "home": {
                        "testmode": false,
                        "val": [
                            [{
                                "activation": "js",
                                "prop": "",
                                "prop2": "",
                                "prop3": "",
                                "val": "bouncex.utils.getNestedProp('ShopifyAnalytics.meta.page.pageType') === 'home';"
                            }]
                        ]
                    },
                    "product": {
                        "testmode": false,
                        "val": [
                            [{
                                "activation": "js",
                                "prop": "",
                                "prop2": "",
                                "prop3": "",
                                "val": "bouncex.utils.getNestedProp('ShopifyAnalytics.meta.page.pageType') === 'product';\r\n"
                            }]
                        ]
                    },
                    "search": {
                        "testmode": false,
                        "val": [
                            [{
                                "activation": "current_page_url",
                                "prop": "contains",
                                "prop2": "",
                                "prop3": "",
                                "val": "/search-results?findify_q="
                            }, {
                                "activation": "current_page_url",
                                "prop": "contains",
                                "prop2": "",
                                "prop3": "",
                                "val": "/search-results?"
                            }, {
                                "activation": "current_page_url",
                                "prop": "contains",
                                "prop2": "",
                                "prop3": "",
                                "val": "/search"
                            }]
                        ]
                    }
                },
                "els": {
                    "blank_site_element": ""
                },
                "vars": [{
                    "name": "logged_in",
                    "polling": "all",
                    "persist": "no",
                    "page_types": [],
                    "testmode": false,
                    "default": "false",
                    "code": "!!bouncex.utils.getNestedProp('__st.cid');\r\n",
                    "trigger": ""
                }, {
                    "name": "ever_logged_in",
                    "polling": "all",
                    "persist": "permanent",
                    "page_types": [],
                    "testmode": false,
                    "default": "false",
                    "code": "bouncex.vars.logged_in || null;",
                    "trigger": ""
                }, {
                    "name": "cart_qty",
                    "polling": "all",
                    "persist": "visit",
                    "page_types": [],
                    "testmode": false,
                    "default": "0",
                    "code": "bouncex.website.pts === 'checkout' ? null : Number(jQuery('.Header__CartCount').text());",
                    "trigger": ""
                }, {
                    "name": "cart_value",
                    "polling": "all",
                    "persist": "visit",
                    "page_types": [],
                    "testmode": false,
                    "default": "0",
                    "code": "bouncex.website.pts === 'checkout' ? null : Number(jQuery('span[data-id=\"cart-total\"]').text().replace(/[^0-9.]/g, ''));",
                    "trigger": ""
                }, {
                    "name": "submitted_onsite",
                    "polling": "all",
                    "persist": "permanent",
                    "page_types": [],
                    "testmode": false,
                    "default": "false",
                    "code": "jQuery('span').text().indexOf('Thanks for subscribing!') > -1 || null;",
                    "trigger": ""
                }, {
                    "name": "page_url",
                    "polling": "none",
                    "persist": "no",
                    "page_types": ["category", "search"],
                    "testmode": true,
                    "default": "false",
                    "code": "",
                    "trigger": ""
                }, {
                    "name": "cart_token",
                    "polling": "none",
                    "persist": "no",
                    "page_types": [],
                    "testmode": false,
                    "default": "false",
                    "code": "null;",
                    "trigger": "pageload"
                }, {
                    "name": "cart",
                    "polling": "none",
                    "persist": "permanent",
                    "page_types": [],
                    "testmode": false,
                    "default": "false",
                    "code": "null;",
                    "trigger": "pageload"
                }, {
                    "name": "cookie_modal_present",
                    "polling": "all",
                    "persist": "no",
                    "page_types": [],
                    "testmode": false,
                    "default": "false",
                    "code": "jQuery('#onetrust-banner-sdk:visible').length > 0;",
                    "trigger": "pageload"
                }, {
                    "name": "page_type",
                    "polling": "none",
                    "persist": "no",
                    "page_types": [],
                    "testmode": false,
                    "default": "false",
                    "code": "bouncex.website.pts;",
                    "trigger": "pageload"
                }, {
                    "name": "attentive_visible",
                    "polling": "all",
                    "persist": "no",
                    "page_types": [],
                    "testmode": false,
                    "default": "false",
                    "code": "jQuery('#attentive_overlay').length > 0;",
                    "trigger": "pageload"
                }, {
                    "name": "logged_in_identified",
                    "polling": "none",
                    "persist": "visit",
                    "page_types": [],
                    "testmode": false,
                    "default": "false",
                    "code": "null;",
                    "trigger": "pageload"
                }, {
                    "name": "sizing_modal_visible",
                    "polling": "all",
                    "persist": "no",
                    "page_types": [],
                    "testmode": false,
                    "default": "false",
                    "code": "jQuery('#modal-sizing-chart[aria-hidden=\"false\"]').length > 0;",
                    "trigger": "pageload"
                }],
                "dgu": "pixel.cdnwidget.com",
                "dgp": false,
                "ba": {
                    "enabled": 0,
                    "fbte": 0
                },
                "biu": "assets.bounceexchange.com",
                "bau": "api.bounceexchange.com",
                "beu": "events.bouncex.net",
                "ibx": {
                    "tjs": "",
                    "cjs": "",
                    "miw": 0,
                    "mibcx": 1,
                    "te": 1,
                    "cart_rep": {
                        "get": "",
                        "set": ""
                    },
                    "ulpj": {
                        "bxid": "espemailid"
                    },
                    "cus": "",
                    "miw_exclude": "",
                    "enabled": 1
                },
                "etjson": null,
                "osre": true,
                "osru": "osr.bounceexchange.com/v1/osr/items",
                "checkDfp": false,
                "gamNetwork": "",
                "spa": 1,
                "spatm": 0,
                "preinit_cjs": "",
                "crs": {
                    "integrations": null,
                    "pageCount": null
                },
                "mat": 0,
                "math": 0,
                "cpnu": "coupons.bounceexchange.com",
                "dfpcms": 0,
                "sms": {
                    "optm": "",
                    "eventSharing": false,
                    "shqId": "",
                    "enabled": 0
                },
                "pde": true,
                "fmc": ["US"],
                "fme": true,
                "fmx": "",
                "uid2": false,
                "sdk": {
                    "android": {
                        "enabled": false,
                        "enabledVersions": [],
                        "eventModifications": null
                    },
                    "ios": {
                        "enabled": false,
                        "enabledVersions": [],
                        "eventModifications": null
                    }
                },
                "onsite": {
                    "enabled": 1
                },
                "ads": {
                    "enabled": 0
                },
                "pubs": {
                    "enabled": 0
                },
                "websdk": {
                    "enabled": 0,
                    "devMode": 0
                },
                "ga4_property_id": "285995344",
                "ga4_measurement_id": "G-RJFJGM7P5E",
                "tag_state_domain": "api.bounceexchange.com",
                "tag_state_domain_enabled": false
            };

            bouncex.tag = 'tag3';
            bouncex.$ = window.jQuery;
            bouncex.env = 'production';
            bouncex.restrictedTlds = {
                "casl": {
                    "ca": 1
                },
                "gdpr": {
                    "ad": 1,
                    "al": 1,
                    "at": 1,
                    "ax": 1,
                    "ba": 1,
                    "be": 1,
                    "bg": 1,
                    "by": 1,
                    "xn--90ais": 1,
                    "ch": 1,
                    "cy": 1,
                    "cz": 1,
                    "de": 1,
                    "dk": 1,
                    "ee": 1,
                    "es": 1,
                    "eu": 1,
                    "fi": 1,
                    "fo": 1,
                    "fr": 1,
                    "uk": 1,
                    "gb": 1,
                    "gg": 1,
                    "gi": 1,
                    "gr": 1,
                    "hr": 1,
                    "hu": 1,
                    "ie": 1,
                    "im": 1,
                    "is": 1,
                    "it": 1,
                    "je": 1,
                    "li": 1,
                    "lt": 1,
                    "lu": 1,
                    "lv": 1,
                    "mc": 1,
                    "md": 1,
                    "me": 1,
                    "mk": 1,
                    "xn--d1al": 1,
                    "mt": 1,
                    "nl": 1,
                    "no": 1,
                    "pl": 1,
                    "pt": 1,
                    "ro": 1,
                    "rs": 1,
                    "xn--90a3ac": 1,
                    "ru": 1,
                    "su": 1,
                    "xn--p1ai": 1,
                    "se": 1,
                    "si": 1,
                    "sj": 1,
                    "sk": 1,
                    "sm": 1,
                    "ua": 1,
                    "xn--j1amh": 1,
                    "va": 1,
                    "tr": 1
                }
            };
            bouncex.client = {
                supportsBrotli: 1
            };
            bouncex.assets = {
                "ads": "646cf096aae730e1484b6de87539a9af",
                "creativesBaseStyles": "a53944a2",
                "gpsAuction": "bbb80866120d17013073bb6d284cbd6b",
                "inbox": "a17aab65d5ec0e7dbba07712663f933e",
                "onsite": "c05f8c5551fa6b964660ad61916291c1",
                "sms": "e39203556bab2366e56296ce42e974a7",
                "websdk": "9c2817e65e803cb8c86d0410c88f20c1",
                "website_campaigns_6265": "4bb001d7541fffd7548fb7eeaf1d88d3"
            };
            bouncex.push = function(pushData) {
                bouncex.pushedData.push(pushData);
            }

            var runtime = document.createElement('script');
            runtime.setAttribute('src', '//assets.bounceexchange.com/assets/smart-tag/versioned/runtime_c81e76ee00d795b1eebf8d27949f8dc5.br.js');
            runtime.setAttribute('async', 'async');

            bouncex.initializeTag = function() {
                var script = document.createElement('script');
                script.setAttribute('src', '//assets.bounceexchange.com/assets/smart-tag/versioned/main-v2_0cd81115cd0e8b6360bb6ba2359ae191.br.js');
                script.setAttribute('async', 'async');
                document.body.appendChild(script);


                var deviceGraphScript = document.createElement('script');
                deviceGraphScript.setAttribute('src', '//assets.bounceexchange.com/assets/smart-tag/versioned/cjs_min_23e9fb6eac44d2bdee89ffde48eb6611.js');
                deviceGraphScript.setAttribute('async', 'async');
                var dgAttrs = [{
                    "Key": "id",
                    "Value": "c.js"
                }, {
                    "Key": "async",
                    "Value": "true"
                }, {
                    "Key": "data-apikey",
                    "Value": "2^HIykD"
                }, {
                    "Key": "data-cb",
                    "Value": "bouncex.dg.initPostDeviceGraph"
                }, {
                    "Key": "data-bx",
                    "Value": "1"
                }, {
                    "Key": "data-gm",
                    "Value": "1"
                }, {
                    "Key": "data-fire",
                    "Value": "1"
                }];
                if (dgAttrs) {
                    for (var i = 0; i < dgAttrs.length; i++) {
                        deviceGraphScript.setAttribute(dgAttrs[i].Key, dgAttrs[i].Value);
                    }
                }
                document.body.appendChild(deviceGraphScript);

                bouncex.initializeTag = function() {};
            };

            runtime.onload = bouncex.initializeTag;
            document.body.appendChild(runtime);

        }


    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", bxBootstrap);
    } else {
        bxBootstrap();
    }
})();